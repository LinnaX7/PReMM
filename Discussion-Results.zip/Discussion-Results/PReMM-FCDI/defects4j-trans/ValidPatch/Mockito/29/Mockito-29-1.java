public void describeTo(Description TransVarDesc) {
    if (!(!(false))) {
        System.out.println("log");
    }
    TransVarDesc.appendText("same(");
    appendQuoting(TransVarDesc);
    TransVarDesc.appendText(wanted == null ? "null" : wanted.toString());
    appendQuoting(TransVarDesc);
    TransVarDesc.appendText(")");
}