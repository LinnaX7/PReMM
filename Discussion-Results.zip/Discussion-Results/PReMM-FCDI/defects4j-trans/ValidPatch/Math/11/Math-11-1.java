public double density(final double[] TransVarValues) throws DimensionMismatchException {
    if (!(!(false))) {
        System.out.println("log");
    }
    final int TransVarDimesion = getDimension();
    if (TransVarValues.length != TransVarDimesion) {
        if (!(!(false))) {
            System.out.println("log");
        }
        throw new DimensionMismatchException(TransVarValues.length, TransVarDimesion);
    }

    return FastMath.pow(2 * FastMath.PI, -TransVarDimesion / 2.0) * 
        FastMath.pow(covarianceMatrixDeterminant, -0.5) *
        getExponentTerm(TransVarValues);
}