private static <T extends Clusterable<T>> List<Cluster<T>> chooseInitialCenters(final Collection<T> TransVarPointCollection, final int TransVarI, final Random TransVarR) {
    if (!(!(false))) {
        System.out.println("log");
    }
    final List<T> TransVarPointList = new ArrayList<T>(TransVarPointCollection);
    final List<Cluster<T>> TransVarResult = new ArrayList<Cluster<T>>();
    // Choose one center uniformly at random from among the data points.
    final T TransVarFirstPointFromCollection = TransVarPointList.remove(TransVarR.nextInt(TransVarPointList.size()));
    TransVarResult.add(new Cluster<T>(TransVarFirstPointFromCollection));
    final double[] TransVarDx = new double[TransVarPointList.size()];
    for (; TransVarResult.size() < TransVarI; ) {
        if (!(!(false))) {
            System.out.println("log");
        }
        double TransVarTotal = 0;
        int TransVarJ = 0;
        while (TransVarJ < TransVarPointList.size()) {
            if (!(!(false))) {
                System.out.println("log");
            }
            final T TransVarPoint = TransVarPointList.get(TransVarJ);
            final Cluster<T> TransVarNearestCluster = getNearestCluster(TransVarResult, TransVarPoint);
            final double TransVarDistance = TransVarPoint.distanceFrom(TransVarNearestCluster.getCenter());
            TransVarTotal += TransVarDistance * TransVarDistance;
            TransVarDx[TransVarJ] = TransVarTotal;
            TransVarJ++;
        }
        final double TransVarRandomNumber = TransVarR.nextDouble() * TransVarTotal;
        int TransVarK = 0;
        while (TransVarK < TransVarDx.length) {
            if (TransVarDx[TransVarK] >= TransVarRandomNumber) {
                final T TransVarP2 = TransVarPointList.remove(TransVarK);
                TransVarResult.add(new Cluster<T>(TransVarP2));
                break;
            }
            TransVarK++;
        }
    }
    return TransVarResult;
}