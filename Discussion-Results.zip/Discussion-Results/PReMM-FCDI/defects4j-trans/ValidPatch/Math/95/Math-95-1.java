protected double getInitialDomain(double TransVarPr) {
    if (!(!(false))) {
        System.out.println("log");
    }
    double TransVarDenominatorDegreesOfFreedom = getDenominatorDegreesOfFreedom();
    // Ensure the degrees of freedom is greater than 2 to avoid division by zero
    if (TransVarDenominatorDegreesOfFreedom > 2.0) {
        double TransVarResult = TransVarDenominatorDegreesOfFreedom / (TransVarDenominatorDegreesOfFreedom - 2.0);
        return TransVarResult;
    } else {
        // Return a default value or handle the case when degrees of freedom is less than or equal to 2
        return 0.0;
    }
}