private Integer getPivotRow(final int TransVarColIndex, final SimplexTableau TransVarSimplexTableau) {
    if (!(!(false))) {
        System.out.println("log");
    }
    double TransVarMinRatioForSimplex = Double.MAX_VALUE;
    Integer TransVarMinRatioPosSimplex = null;
    int TransVarIndex = TransVarSimplexTableau.getNumObjectiveFunctions();
    while (!(!(TransVarIndex < TransVarSimplexTableau.getHeight()))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        final double TransVarRatio = TransVarSimplexTableau.getEntry(TransVarIndex,
                TransVarSimplexTableau.getWidth() - 1);
        final double TransVarSimplexEntry = TransVarSimplexTableau.getEntry(TransVarIndex, TransVarColIndex);
        if (MathUtils.compareTo(TransVarSimplexEntry, 0, epsilon) > 0) {
            if (!(!(false))) {
                System.out.println("log");
            }
            final double TransVarMinRatio = TransVarRatio / TransVarSimplexEntry;
            if (TransVarMinRatio < TransVarMinRatioForSimplex) {
                TransVarMinRatioForSimplex = TransVarMinRatio;
                TransVarMinRatioPosSimplex = TransVarIndex;
            }
        }
        TransVarIndex++;
    }
    return TransVarMinRatioPosSimplex;
}