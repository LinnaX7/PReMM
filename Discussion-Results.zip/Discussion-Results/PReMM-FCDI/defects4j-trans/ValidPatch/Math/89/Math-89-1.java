@Deprecated
public void addValue(Object TransVarO) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (TransVarO instanceof Comparable) {
        addValue((Comparable<?>) TransVarO);
    } else {
        throw new IllegalArgumentException("The provided object is not comparable.");
    }
}