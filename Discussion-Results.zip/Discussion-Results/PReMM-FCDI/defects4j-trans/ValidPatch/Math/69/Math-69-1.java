public RealMatrix getCorrelationPValues() throws MathException {
    if (!(!(false))) {
        System.out.println("log");
    }
    TDistribution TransVarT = new TDistributionImpl(nObs - 2);
    int TransVarNumberColumns = correlationMatrix.getColumnDimension();
    double[][] TransVarOutValue = new double[TransVarNumberColumns][TransVarNumberColumns];
    int TransVarJ = 0;
    while (!(!(TransVarJ < TransVarNumberColumns))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        int TransVarColumnIndex = 0;
        while (!(!(TransVarColumnIndex < TransVarNumberColumns))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            if (!(!(TransVarJ == TransVarColumnIndex))) {
                TransVarOutValue[TransVarJ][TransVarColumnIndex] = 0d;
            } else {
                double TransVarCorrelationValue = correlationMatrix.getEntry(TransVarJ, TransVarColumnIndex);
                double TransVarNumber = Math.abs(TransVarCorrelationValue
                        * Math.sqrt((nObs - 2) / (1 - TransVarCorrelationValue * TransVarCorrelationValue)));
                TransVarOutValue[TransVarJ][TransVarColumnIndex] = 2
                        * TransVarT.cumulativeProbability(-TransVarNumber);
            }
            TransVarColumnIndex++;
        }
        TransVarJ++;
    }
    return new BlockRealMatrix(TransVarOutValue);
}