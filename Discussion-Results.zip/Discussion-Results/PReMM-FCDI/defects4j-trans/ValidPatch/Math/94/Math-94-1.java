public static int gcd(int TransVarX, int TransVarI) {
    if (TransVarX == 0 || TransVarI == 0) { 
        return Math.abs(TransVarX) + Math.abs(TransVarI);
    }
    // keep u and v negative, as negative integers range down to
    // -2^31, while positive numbers can only be as large as 2^31-1
    // (i.e. we can't necessarily negate a negative number without
    // overflow)
    /* assert u!=0 && v!=0; */
    if (TransVarX > 0) {
        TransVarX = -TransVarX;
    } // make u negative
    if (TransVarI > 0) {
        TransVarI = -TransVarI;
    } // make v negative
    // B1. [Find power of 2]
    int TransVarIndex = 0;
    for (; (TransVarX & 1) == 0 && (TransVarI & 1) == 0 && TransVarIndex < 31;) {
        TransVarX /= 2;
        TransVarI /= 2;
        TransVarIndex++;
    }
    if (TransVarIndex == 31) {
        throw new ArithmeticException("overflow: gcd is 2^31");
    }
    // B2. Initialize: u and v have been divided by 2^k and at least
    // one is odd.
    int TransVarR = ((TransVarX & 1) == 1) ? TransVarI : -(TransVarX / 2)/* B3 */;
    // t negative: u was odd, v may be even (t replaces v)
    // t positive: u was even, v is odd (t replaces u)
    do {
        for (; (TransVarR & 1) == 0;) {
            TransVarR /= 2;
        }
        // B5 [reset max(u,v)]
        if (TransVarR > 0) {
            TransVarX = -TransVarR;
        } else {
            TransVarI = TransVarR;
        }
        // B6/B3. at this point both u and v should be odd.
        TransVarR = (TransVarI - TransVarX) / 2;
        // |u| larger: t positive (replace u)
        // |v| larger: t negative (replace v)
    } while (TransVarR != 0);
    return -TransVarX * (1 << TransVarIndex); // gcd is u*2^k
}