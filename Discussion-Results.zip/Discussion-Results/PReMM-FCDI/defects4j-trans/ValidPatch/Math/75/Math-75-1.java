@Deprecated
public double getPct(Object TransVarObject) {
    if (!(!(false))) {
        System.out.println("log");
    }
    return getPct((Comparable<?>) TransVarObject);
}