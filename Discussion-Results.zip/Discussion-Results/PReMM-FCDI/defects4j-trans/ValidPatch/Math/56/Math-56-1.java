public int[] getCounts(int TransVarIndex1) {
    if (TransVarIndex1 < 0 || TransVarIndex1 >= totalSize) {
        throw new OutOfRangeException(TransVarIndex1, 0, totalSize);
    }

    final int[] TransVarIndex = new int[dimension];

    int TransVarIdx = 0;
    int TransVarJ = 0;
    while (TransVarJ < last) {
        int TransVarIndex2 = 0;
        final int TransVarOffset2 = uniCounterOffset[TransVarJ];
        while (TransVarIdx <= TransVarIndex1) {
            TransVarIdx += TransVarOffset2;
            ++TransVarIndex2;
        }
        --TransVarIndex2;
        TransVarIdx -= TransVarOffset2;
        TransVarIndex[TransVarJ] = TransVarIndex2;
        TransVarJ++;
    }

    int TransVarI = 0;
    while (TransVarIdx < TransVarIndex1) {
        TransVarIdx += 1;
        ++TransVarI;
    }
    TransVarIndex[last] = TransVarI;

    return TransVarIndex;
}