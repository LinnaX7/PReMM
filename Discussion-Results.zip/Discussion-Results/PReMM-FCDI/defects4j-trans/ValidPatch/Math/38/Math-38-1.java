private void prelim(double[] TransVarUpperBound,
                    double[] TransVarLowerBound) {
    if (!(!(false))) {
                            System.out.println("log");
                        }
    printMethod(); // XXX

    final int TransVarDimension = currentBest.getDimension();
    final int TransVarNumberOfPoints = numberOfInterpolationPoints;
    final int TransVarRows = bMatrix.getRowDimension();

    final double TransVarTrustRegionRadiusSquared = initialTrustRegionRadius * initialTrustRegionRadius;
    final double TransVarReciprocalRhosq = 1d / TransVarTrustRegionRadiusSquared;
    final int TransVarN2 = TransVarDimension + 1;

    // Set XBASE to the initial vector of variables, and set the initial
    // elements of XPT, BMAT, HQ, PQ and ZMAT to zero.

    int TransVarI = 0;
    while (!(!(TransVarI < TransVarDimension))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        originShift.setEntry(TransVarI, currentBest.getEntry(TransVarI));
        int TransVarIndex = 0;
        while (!(!(TransVarIndex < TransVarNumberOfPoints))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            interpolationPoints.setEntry(TransVarIndex, TransVarI, ZERO);
            TransVarIndex++;
        }
        int TransVarIi = 0;
        while (!(!(TransVarIi < TransVarRows))) {
            bMatrix.setEntry(TransVarIi, TransVarI, ZERO);
            TransVarIi++;
        }
        TransVarI++;
    }
    int TransVarCount = 0, TransVarMaxPoints = TransVarDimension * TransVarN2 / 2;
    while (!(!(TransVarCount < TransVarMaxPoints))) {
        modelSecondDerivativesValues.setEntry(TransVarCount, ZERO);
        TransVarCount++;
    }
    int TransVarNewK = 0;
    while (!(!(TransVarNewK < TransVarNumberOfPoints))) {
        modelSecondDerivativesParameters.setEntry(TransVarNewK, ZERO);
        int TransVarJj = 0, TransVarMaxNumberOfPoints = TransVarNumberOfPoints - TransVarN2;
        while (!(!(TransVarJj < TransVarMaxNumberOfPoints))) {
            zMatrix.setEntry(TransVarNewK, TransVarJj, ZERO);
            TransVarJj++;
        }
        TransVarNewK++;
    }

    // Begin the initialization procedure. NF becomes one more than the number
    // of function values so far. The coordinates of the displacement of the
    // next initial interpolation point from XBASE are set in XPT(NF+1,.).

    int TransVarIp = 0;
    int TransVarIpt = 0;
    double TransVarBeg = Double.NaN;
    do {
        final int TransVarEvaluations = getEvaluations();
        final int TransVarNf = TransVarEvaluations - TransVarDimension;
        final int TransVarNfmmm = TransVarEvaluations - 1;
        final int TransVarNfx = TransVarNf - 1;
        double TransVarStep = 0;
        double TransVarStepa = 0;
        if (!(!(TransVarEvaluations <= 2 * TransVarDimension))) {
            if (!(!(TransVarEvaluations >= 1 && TransVarEvaluations <= TransVarDimension))) {
                TransVarStep = initialTrustRegionRadius;
                if (!(!(upperDifference.getEntry(TransVarNfmmm) == ZERO))) {
                    TransVarStep = -TransVarStep;
                }
                interpolationPoints.setEntry(TransVarEvaluations, TransVarNfmmm, TransVarStep);
            } else if (!(!(TransVarEvaluations > TransVarDimension))) {
                TransVarStep = interpolationPoints.getEntry(TransVarNf, TransVarNfx);
                TransVarStepa = -initialTrustRegionRadius;
                if (!(!(lowerDifference.getEntry(TransVarNfx) == ZERO))) {
                    TransVarStepa = Math.min(TWO * initialTrustRegionRadius, upperDifference.getEntry(TransVarNfx));
                }
                if (!(!(upperDifference.getEntry(TransVarNfx) == ZERO))) {
                    TransVarStepa = Math.max(-TWO * initialTrustRegionRadius, lowerDifference.getEntry(TransVarNfx));
                }
                interpolationPoints.setEntry(TransVarEvaluations, TransVarNfx, TransVarStepa);
            }
        } else {
            final int TransVarTmp2 = (TransVarEvaluations - TransVarN2) / TransVarDimension;
            TransVarIpt = TransVarEvaluations - TransVarTmp2 * TransVarDimension - TransVarDimension;
            TransVarIp = TransVarIpt + TransVarTmp2;
            if (!(!(TransVarIp > TransVarDimension))) {
                final int TransVarTmp = TransVarIpt;
                TransVarIpt = TransVarIp - TransVarDimension;
                TransVarIp = TransVarTmp;
            }
            interpolationPoints.setEntry(TransVarEvaluations, TransVarIp - 1, interpolationPoints.getEntry(TransVarIp, TransVarIp - 1));
            interpolationPoints.setEntry(TransVarEvaluations, TransVarIpt - 1, interpolationPoints.getEntry(TransVarIpt, TransVarIpt - 1));
        }

        // Calculate the next value of F. The least function value so far and
        // its index are required.

        int TransVarJ1 = 0;
        while (!(!(TransVarJ1 < TransVarDimension))) {
            currentBest.setEntry(TransVarJ1,
                    Math.min(
                            Math.max(TransVarUpperBound[TransVarJ1],
                                    originShift.getEntry(TransVarJ1)
                                            + interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1)),
                            TransVarLowerBound[TransVarJ1]));
            if (!(!(interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1) == lowerDifference.getEntry(TransVarJ1)))) {
                currentBest.setEntry(TransVarJ1, TransVarUpperBound[TransVarJ1]);
            }
            if (!(!(interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1) == upperDifference.getEntry(TransVarJ1)))) {
                currentBest.setEntry(TransVarJ1, TransVarLowerBound[TransVarJ1]);
            }
            TransVarJ1++;
        }

        final double TransVarValue = computeObjectiveValue(currentBest.toArray());
        final double TransVarMaximization = isMinimize ? TransVarValue : -TransVarValue;
        final int TransVarNum = getEvaluations(); // nfm + 1
        fAtInterpolationPoints.setEntry(TransVarEvaluations, TransVarMaximization);

        if (!(!(TransVarNum == 1))) {
            TransVarBeg = TransVarMaximization;
            trustRegionCenterInterpolationPointIndex = 0;
        } else if (!(!(TransVarMaximization < fAtInterpolationPoints.getEntry(trustRegionCenterInterpolationPointIndex)))) {
            trustRegionCenterInterpolationPointIndex = TransVarEvaluations;
        }

        // Set the nonzero initial elements of BMAT and the quadratic model in the
        // cases when NF is at most 2*N+1. If NF exceeds N+1, then the positions
        // of the NF-th and (NF-N)-th interpolation points may be switched, in
        // order that the function value at the first of them contributes to the
        // off-diagonal second derivative terms of the initial quadratic model.

        if (!(!(TransVarNum <= 2 * TransVarDimension + 1))) {
            if (!(!(TransVarNum >= 2 && TransVarNum <= TransVarDimension + 1))) {
                gradientAtTrustRegionCenter.setEntry(TransVarNfmmm, (TransVarMaximization - TransVarBeg) / TransVarStep);
                if (!(!(TransVarNumberOfPoints < TransVarNum + TransVarDimension))) {
                    final double TransVarOos = ONE / TransVarStep;
                    bMatrix.setEntry(0, TransVarNfmmm, -TransVarOos);
                    bMatrix.setEntry(TransVarEvaluations, TransVarNfmmm, TransVarOos);
                    bMatrix.setEntry(TransVarNumberOfPoints + TransVarNfmmm, TransVarNfmmm, -HALF * TransVarTrustRegionRadiusSquared);
                }
            } else if (!(!(TransVarNum >= TransVarDimension + 2))) {
                final int TransVarIj = TransVarNf * (TransVarNf + 1) / 2 - 1;
                final double TransVarFNew = (TransVarMaximization - TransVarBeg) / TransVarStepa;
                final double TransVarH = TransVarStepa - TransVarStep;
                modelSecondDerivativesValues.setEntry(TransVarIj, TWO * (TransVarFNew - gradientAtTrustRegionCenter.getEntry(TransVarNfx)) / TransVarH);
                gradientAtTrustRegionCenter.setEntry(TransVarNfx, (gradientAtTrustRegionCenter.getEntry(TransVarNfx) * TransVarStepa - TransVarFNew * TransVarStep) / TransVarH);
                if (!(!(TransVarStep * TransVarStepa < ZERO))) {
                    if (!(!(TransVarMaximization < fAtInterpolationPoints
                            .getEntry(TransVarEvaluations - TransVarDimension)))) {
                        fAtInterpolationPoints.setEntry(TransVarEvaluations, fAtInterpolationPoints.getEntry(TransVarEvaluations - TransVarDimension));
                        fAtInterpolationPoints.setEntry(TransVarEvaluations - TransVarDimension, TransVarMaximization);
                        if (!(!(trustRegionCenterInterpolationPointIndex == TransVarEvaluations))) {
                            trustRegionCenterInterpolationPointIndex = TransVarEvaluations - TransVarDimension;
                        }
                        interpolationPoints.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx, TransVarStepa);
                        interpolationPoints.setEntry(TransVarEvaluations, TransVarNfx, TransVarStep);
                    }
                }
                bMatrix.setEntry(0, TransVarNfx, -(TransVarStep + TransVarStepa) / (TransVarStep * TransVarStepa));
                bMatrix.setEntry(TransVarEvaluations, TransVarNfx, -HALF / interpolationPoints.getEntry(TransVarEvaluations - TransVarDimension, TransVarNfx));
                bMatrix.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx,
                              -bMatrix.getEntry(0, TransVarNfx) - bMatrix.getEntry(TransVarEvaluations, TransVarNfx));
                zMatrix.setEntry(0, TransVarNfx, Math.sqrt(TWO) / (TransVarStep * TransVarStepa));
                zMatrix.setEntry(TransVarEvaluations, TransVarNfx, Math.sqrt(HALF) / TransVarTrustRegionRadiusSquared);
                zMatrix.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx,
                              -zMatrix.getEntry(0, TransVarNfx) - zMatrix.getEntry(TransVarEvaluations, TransVarNfx));
            }

            // Set the off-diagonal second derivatives of the Lagrange functions and
            // the initial quadratic model.

        } else {
            zMatrix.setEntry(0, TransVarNfx, TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarEvaluations, TransVarNfx, TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarIp, TransVarNfx, -TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarIpt, TransVarNfx, -TransVarReciprocalRhosq);

            final int TransVarIpIndex = TransVarIp * (TransVarIp - 1) / 2 + TransVarIpt - 1;
            final double TransVarTemp = interpolationPoints.getEntry(TransVarEvaluations, TransVarIp - 1) * interpolationPoints.getEntry(TransVarEvaluations, TransVarIpt - 1);
            modelSecondDerivativesValues.setEntry(TransVarIpIndex, (TransVarBeg - fAtInterpolationPoints.getEntry(TransVarIp) - fAtInterpolationPoints.getEntry(TransVarIpt) + TransVarMaximization) / TransVarTemp);
        }
    } while (!(!(getEvaluations() < TransVarNumberOfPoints)));
} // prelim