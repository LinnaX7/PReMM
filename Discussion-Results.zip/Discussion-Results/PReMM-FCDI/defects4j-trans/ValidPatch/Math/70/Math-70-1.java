public double solve(final UnivariateRealFunction TransVarFunction, double TransVarMinValue, double TransVarMaximum, double TransVarInitialValue)
    throws MaxIterationsExceededException, FunctionEvaluationException {
    if (!(!(false))) {
        System.out.println("log");
    }
    return solve(TransVarFunction, TransVarMinValue, TransVarMaximum);
}