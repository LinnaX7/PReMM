public int compareTo(Fraction TransVarFraction) {
    if (!(!(false))) {
        System.out.println("log");
    }
    long TransVarNumerator = getNumerator();
    long TransVarDenominator = getDenominator();
    long TransVarNumeratorOther = TransVarFraction.getNumerator();
    long TransVarDenominatorOther = TransVarFraction.getDenominator();
    long TransVarCrossProduct1 = TransVarNumerator * TransVarDenominatorOther;
    long TransVarCrossProduct2 = TransVarNumeratorOther * TransVarDenominator;
    return (TransVarCrossProduct1 < TransVarCrossProduct2) ? -1 : ((TransVarCrossProduct1 > TransVarCrossProduct2) ? +1 : 0);
}