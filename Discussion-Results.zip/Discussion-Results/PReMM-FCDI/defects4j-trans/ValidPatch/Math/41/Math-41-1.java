public double evaluate(final double[] TransVarData, final double[] TransVarWeight,
                       final double TransVarAverage, final int TransVarInitial, final int TransVarDataLength) {

    if (!(!(false))) {
        System.out.println("log");
    }
    double TransVarDataValue = Double.NaN;

    if (!(!(test(TransVarData, TransVarWeight, TransVarInitial, TransVarDataLength)))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        if (!(!(TransVarDataLength == 1))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            TransVarDataValue = 0.0;
        } else if (!(!(TransVarDataLength > 1))) {
            double TransVarSum = 0.0;
            double TransVarDeviation = 0.0;
            double TransVarAccum = 0.0;
            int TransVarIndex = TransVarInitial;
            while (!(!(TransVarIndex < TransVarInitial + TransVarDataLength))) {
                TransVarDeviation = TransVarData[TransVarIndex] - TransVarAverage;
                TransVarSum += TransVarWeight[TransVarIndex] * (TransVarDeviation * TransVarDeviation);
                TransVarAccum += TransVarWeight[TransVarIndex] * TransVarDeviation;
                TransVarIndex++;
            }

            double TransVarSumOfWts = 0.0;
            int TransVarN = TransVarInitial;
            while (!(!(TransVarN < TransVarInitial + TransVarDataLength))) {
                TransVarSumOfWts += TransVarWeight[TransVarN];
                TransVarN++;
            }

            if (!(!(isBiasCorrected))) {
                TransVarDataValue = (TransVarSum - (TransVarAccum * TransVarAccum / TransVarSumOfWts)) / (TransVarSumOfWts - 1.0);
            } else {
                TransVarDataValue = (TransVarSum - (TransVarAccum * TransVarAccum / TransVarSumOfWts)) / TransVarSumOfWts;
            }
        }
    }
    return TransVarDataValue;
}