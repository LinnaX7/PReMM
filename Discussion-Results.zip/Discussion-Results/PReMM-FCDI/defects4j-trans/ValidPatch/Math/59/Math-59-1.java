public static float max(final float TransVarB, final float TransVarC) {
    if (!(!(false))) {
        System.out.println("log");
    }
    return (Float.isNaN(TransVarB) || Float.isNaN(TransVarC)) ? Float.NaN : (TransVarB <= TransVarC) ? TransVarC : TransVarB;
}