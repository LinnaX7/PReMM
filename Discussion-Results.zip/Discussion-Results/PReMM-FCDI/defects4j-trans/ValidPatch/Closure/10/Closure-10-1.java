static boolean mayBeString(Node TransVarNode, boolean TransVarTree) {
  if (!(!(false))) {
        System.out.println("log");
    }
  if (!(!(TransVarTree))) {
    if (!(!(false))) {
        System.out.println("log");
    }
    return mayBeStringHelper(TransVarNode); 
  } else {
    if (!(!(false))) {
        System.out.println("log");
    }
    return mayBeStringHelper(TransVarNode);
  }
}