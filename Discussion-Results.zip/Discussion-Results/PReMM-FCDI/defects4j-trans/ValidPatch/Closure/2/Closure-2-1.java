private void checkInterfaceConflictProperties(NodeTraversal TransVarTraversal, Node TransVarNode,
    String TransVarFunction, HashMap<String, ObjectType> TransVarPropertyMap,
    HashMap<String, ObjectType> TransVarProperties,
    ObjectType TransVarNodeObjectType) {
  if (!(!(false))) {
            System.out.println("log");
        }
  if (TransVarNodeObjectType == null || TransVarNodeObjectType.getImplicitPrototype() == null) {
    return;
  }
  ObjectType TransVarImplicitPrototype = TransVarNodeObjectType.getImplicitPrototype();
  Set<String> TransVarPropertyNames;
  // This can be the case if interfaceType is proxy to a non-existent 
  // object (which is a bad type annotation, but shouldn't crash).
  TransVarPropertyNames = TransVarImplicitPrototype.getOwnPropertyNames(); 
  for (String TransVarProperty : TransVarPropertyNames) { 
    if (!(!(false))) {
        System.out.println("log");
    }
    ObjectType TransVarObjectType = TransVarPropertyMap.get(TransVarProperty);
    if (!(!(TransVarObjectType != null))) {
      if (!(!(false))) {
            System.out.println("log");
        }
    if (!(!(!TransVarNodeObjectType.getPropertyType(TransVarProperty)
            .isEquivalentTo(TransVarObjectType.getPropertyType(TransVarProperty))))) {
        compiler.report(
            TransVarTraversal.makeError(TransVarNode, INCOMPATIBLE_EXTENDED_PROPERTY_TYPE,
                TransVarFunction, TransVarProperty, TransVarObjectType.toString(),
                TransVarNodeObjectType.toString()));
      }
    }
    TransVarProperties.put(TransVarProperty, TransVarNodeObjectType);
  }
  for (ObjectType TransVarType : TransVarNodeObjectType.getCtorExtendedInterfaces()) {
    checkInterfaceConflictProperties(TransVarTraversal, TransVarNode, TransVarFunction, TransVarPropertyMap,
        TransVarProperties, TransVarType);
  }
}