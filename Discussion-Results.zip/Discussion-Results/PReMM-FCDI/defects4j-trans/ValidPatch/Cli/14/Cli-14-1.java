public void validate(final WriteableCommandLine TransVarCmd)
    throws OptionException {
    // number of options found
    int TransVarIsPresent = 0;

    // reference to first unexpected option
    Option TransVarUnknown = null;

    final Iterator TransVarOptionIterator = options.iterator();
    while (TransVarOptionIterator.hasNext()) {
        final Option TransVarO = (Option) TransVarOptionIterator.next();
        boolean TransVarIsValidate = TransVarO.isRequired() || TransVarO instanceof Group;
        if (TransVarIsValidate) {
            TransVarO.validate(TransVarCmd);
        }
        if (TransVarCmd.hasOption(TransVarO)) {
            ++TransVarIsPresent;
            if (TransVarIsPresent > maximum) {
                TransVarUnknown = TransVarO;
                break;
            }
        }
    }

    // too many options
    if (TransVarUnknown != null) {
        throw new OptionException(this, ResourceConstants.UNEXPECTED_TOKEN,
                                  TransVarUnknown.getPreferredName());
    }

    // too few options
    if (TransVarIsPresent < minimum) {
        throw new OptionException(this, ResourceConstants.MISSING_OPTION);
    }

    final Iterator TransVarIterator = anonymous.iterator();
    while (TransVarIterator.hasNext()) {
        final Option TransVarOption1 = (Option) TransVarIterator.next();
        TransVarOption1.validate(TransVarCmd);
    }
}