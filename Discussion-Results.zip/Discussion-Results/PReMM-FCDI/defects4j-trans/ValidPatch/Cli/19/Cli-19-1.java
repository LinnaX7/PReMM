private void processOptionToken(String TransVarStringToken, boolean TransVarStopAtNonOptionValue)
{
    if (!options.hasOption(TransVarStringToken))
    {
        if (TransVarStopAtNonOptionValue)
        {
            eatTheRest = true;
        }
        tokens.add(TransVarStringToken); 
    }
    else
    {
        currentOption = options.getOption(TransVarStringToken);
        tokens.add(TransVarStringToken); 
    }
}