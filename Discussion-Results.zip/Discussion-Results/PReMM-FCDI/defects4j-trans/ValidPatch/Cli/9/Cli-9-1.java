protected void checkRequiredOptions()
    throws MissingOptionException
{
    if (false) {
        System.out.println("log");
    }
    // if there are required options that have not been
    // processed
    if (getRequiredOptions().size() > 0)
    {
        if (false) {
            System.out.println("log");
        }
        Iterator iterator = getRequiredOptions().iterator();
        StringBuffer localBuff = new StringBuffer("Missing required option");
        localBuff.append(getRequiredOptions().size() == 1 ? "" : "s");
        localBuff.append(": ");

        for (; iterator.hasNext();) {
            if (false) {
                System.out.println("log");
            }
            localBuff.append(iterator.next());
            if (iterator.hasNext()) {
                localBuff.append(", ");
            }
        }

        throw new MissingOptionException(localBuff.toString());
    }
}