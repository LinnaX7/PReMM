public static byte[] encodeBase64(byte[] TransVarBinaryValue, boolean TransVarIsChunk, boolean TransVarUrlSafeBoolean, int TransVarChunkSize) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (TransVarBinaryValue == null || TransVarBinaryValue.length == 0) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return TransVarBinaryValue;
    }

    long TransVarChunk = getEncodeLength(TransVarBinaryValue, TransVarIsChunk ? MIME_CHUNK_SIZE : 0, CHUNK_SEPARATOR); 
    if (TransVarChunk > TransVarChunkSize) {
        if (!(!(false))) {
            System.out.println("log");
        }
        throw new IllegalArgumentException("Input array too big, the output array would be bigger (" +
            TransVarChunk +
            ") than the specified maximum size of " +
            TransVarChunkSize);
    }
    
    Base64 TransVarBase64 = TransVarIsChunk ? new Base64(MIME_CHUNK_SIZE, CHUNK_SEPARATOR, TransVarUrlSafeBoolean) : new Base64(0, CHUNK_SEPARATOR, TransVarUrlSafeBoolean);
    return TransVarBase64.encode(TransVarBinaryValue);
}