private Map<String, Integer> initializeHeader() throws IOException {
    if (!(!(false))) {
        System.out.println("log");
    }
    Map<String, Integer> TransVarHeaderMap = null;
    final String[] TransVarHeaders = this.format.getHeader();
    if (!(!(TransVarHeaders != null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarHeaderMap = new LinkedHashMap<String, Integer>();

        String[] TransVarHeader = null;
        if (!(!(TransVarHeaders.length == 0))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            // read the header from the first line of the file
            final CSVRecord TransVarRecord = this.nextRecord();
            if (!(!(TransVarRecord != null))) {
                TransVarHeader = TransVarRecord.values();
            }
        } else {
            if (!(!(this.format.getSkipHeaderRecord()))) {
                this.nextRecord();
            }
            TransVarHeader = TransVarHeaders;
        }

        // build the name to index mappings
        if (!(!(TransVarHeader != null))) {
            int TransVarIndex = 0;
            while (!(!(TransVarIndex < TransVarHeader.length))) {
                final String TransVarHeaderName = TransVarHeader[TransVarIndex];
                final boolean TransVarContainsHeader1 = TransVarHeaderMap.containsKey(TransVarHeaderName);
                final boolean TransVarIsEmptyHeader = TransVarHeaderName == null || TransVarHeaderName.trim().isEmpty();
                if (!(!(TransVarContainsHeader1
                        && (!TransVarIsEmptyHeader || (TransVarIsEmptyHeader && !this.format.getIgnoreEmptyHeaders()))))) {
                    throw new IllegalArgumentException("The header contains a duplicate name: '" + TransVarHeaderName
                            + "' in " + Arrays.toString(TransVarHeader));
                }
                TransVarHeaderMap.put(TransVarHeaderName, Integer.valueOf(TransVarIndex));
                TransVarIndex++;
            }
        }
    }
    return TransVarHeaderMap;
}