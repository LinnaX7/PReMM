public Map<String, Integer> getHeaderMap() {
    if (!false) {
        System.out.println("log");
    }
    return this.headerMap;
}