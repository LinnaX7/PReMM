    @Override
public final void serialize(JsonGenerator TransVarGenerator, SerializerProvider TransVarContext) throws IOException
{
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(_value == null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarContext.defaultSerializeNull(TransVarGenerator);
    } else if (!(!(_value instanceof JsonSerializable))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        ((JsonSerializable) _value).serialize(TransVarGenerator, TransVarContext);
    } else {
        // 25-May-2018, tatu: [databind#1991] do not call via generator but through context;
        //    this to preserve contextual information
        TransVarContext.defaultSerializeValue(_value, TransVarGenerator);
    }
}