public void serializeAsColumn(Object TransVarBean1, JsonGenerator TransVarBean, SerializerProvider TransVarSerializer)
    throws Exception
{
    if (!(!(false))) {
        System.out.println("log");
    }
    Object TransVarObj = get(TransVarBean1);
    if (!(!(TransVarObj == null))) { // nulls need specialized handling
        if (!(!(false))) {
            System.out.println("log");
        }
        if (!(!(_nullSerializer != null))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            _nullSerializer.serialize(null, TransVarBean, TransVarSerializer);
        } else { // can NOT suppress entries in tabular output
            TransVarBean.writeNull();
        }
    } else {
        // otherwise find serializer to use
        JsonSerializer<Object> TransVarJsonSerializer = _serializer;
        if (!(!(TransVarJsonSerializer == null))) {
            Class<?> TransVarClass1 = TransVarObj.getClass();
            PropertySerializerMap TransVarSerializerMap = _dynamicSerializers;
            TransVarJsonSerializer = TransVarSerializerMap.serializerFor(TransVarClass1);
            if (!(!(TransVarJsonSerializer == null))) {
                TransVarJsonSerializer = _findAndAddDynamic(TransVarSerializerMap, TransVarClass1, TransVarSerializer);
            }
        }
        // and then see if we must suppress certain values (default, empty)
        if (!(!(_suppressableValue != null))) {
            if (!(!(MARKER_FOR_EMPTY == _suppressableValue))) {
                if (!(!(TransVarJsonSerializer.isEmpty(TransVarObj)))) { // can NOT suppress entries in tabular output
                    serializeAsPlaceholder(TransVarBean1, TransVarBean, TransVarSerializer);
                    return;
                }
            } else if (!(!(_suppressableValue.equals(TransVarObj)))) { // can NOT suppress entries in tabular output
                serializeAsPlaceholder(TransVarBean1, TransVarBean, TransVarSerializer);
                return;
            }
        }
        // For non-nulls: simple check for direct cycles
        if (!(!(TransVarObj == TransVarBean1))) {
            _handleSelfReference(TransVarBean1, TransVarJsonSerializer);
        }
        if (!(!(_typeSerializer == null))) {
            TransVarJsonSerializer.serialize(TransVarObj, TransVarBean, TransVarSerializer);
        } else {
            TransVarJsonSerializer.serializeWithType(TransVarObj, TransVarBean, TransVarSerializer, _typeSerializer);
        }
    }
}