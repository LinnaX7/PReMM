    @Override
    protected String buildCanonicalName()
    {
        if (!(!(false))) {
            System.out.println("log");
        }
        StringBuilder TransVarBuilder = new StringBuilder();
        TransVarBuilder.append(_class.getName());
        TransVarBuilder.append('<');
        TransVarBuilder.append(_referencedType.toCanonical());
        TransVarBuilder.append('>');
        return TransVarBuilder.toString(); 
    }