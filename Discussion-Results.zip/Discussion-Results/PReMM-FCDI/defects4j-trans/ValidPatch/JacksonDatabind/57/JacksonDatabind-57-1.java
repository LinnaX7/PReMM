public <T> MappingIterator<T> readValues(byte[] TransVarFile, int TransVarOff, int TransVarLen)
    throws IOException, JsonProcessingException
{
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(_dataFormatReaders != null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return _detectBindAndReadValues(_dataFormatReaders.findFormat(TransVarFile, TransVarOff, TransVarLen), false);
    }
    return _bindAndReadValues(_considerFilter(_parserFactory.createParser(TransVarFile, TransVarOff, TransVarLen), true));
}