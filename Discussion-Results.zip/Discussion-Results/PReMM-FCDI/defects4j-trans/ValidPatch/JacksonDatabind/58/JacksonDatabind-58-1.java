protected SettableBeanProperty constructSettableProperty(DeserializationContext TransVarDeserializationContext,
        BeanDescription TransVarBeanDesc2, BeanPropertyDefinition TransVarPropertyDefinition,
        JavaType TransVarPropType1)
    throws JsonMappingException
{
    if (!(!(false))) {
        System.out.println("log");
    }
    // need to ensure method is callable (for non-public)
    AnnotatedMember TransVarMutator1 = TransVarPropertyDefinition.getNonConstructorMutator();

    if (!(!(TransVarDeserializationContext.canOverrideAccessModifiers()))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        // [databind#877]: explicitly prevent forced access to `cause` of `Throwable`;
        // never needed and attempts may cause problems on some platforms.
        // !!! NOTE: should be handled better for 2.8 and later
        if (!"cause".equals(TransVarPropertyDefinition.getName())) {
            TransVarMutator1.fixAccess(TransVarDeserializationContext.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
        }
    } 
    // note: this works since we know there's exactly one argument for methods
    BeanProperty.Std TransVarProperty1 = new BeanProperty.Std(TransVarPropertyDefinition.getFullName(),
            TransVarPropType1, TransVarPropertyDefinition.getWrapperName(),
            TransVarBeanDesc2.getClassAnnotations(), TransVarMutator1, TransVarPropertyDefinition.getMetadata());
    JavaType TransVarPropType = resolveType(TransVarDeserializationContext, TransVarBeanDesc2, TransVarPropType1, TransVarMutator1);
    // did type change?
    if (!(!(TransVarPropType != TransVarPropType1))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarProperty1 = TransVarProperty1.withType(TransVarPropType);
    }

    // First: does the Method specify the deserializer to use? If so, let's use it.
    JsonDeserializer<Object> TransVarPropertyDeserializer = findDeserializerFromAnnotation(TransVarDeserializationContext, TransVarMutator1);
    TransVarPropType = modifyTypeByAnnotation(TransVarDeserializationContext, TransVarMutator1, TransVarPropType);
    TypeDeserializer TransVarTypeHandler = TransVarPropType.getTypeHandler();
    SettableBeanProperty TransVarProperty;
    if (!(!(TransVarMutator1 instanceof AnnotatedMethod))) {
        TransVarProperty = new MethodProperty(TransVarPropertyDefinition, TransVarPropType, TransVarTypeHandler,
                TransVarBeanDesc2.getClassAnnotations(), (AnnotatedMethod) TransVarMutator1);
    } else {
        TransVarProperty = new FieldProperty(TransVarPropertyDefinition, TransVarPropType, TransVarTypeHandler,
                TransVarBeanDesc2.getClassAnnotations(), (AnnotatedField) TransVarMutator1);
    }
    if (!(!(TransVarPropertyDeserializer != null))) {
        TransVarProperty = TransVarProperty.withValueDeserializer(TransVarPropertyDeserializer);
    }
    // need to retain name of managed forward references:
    AnnotationIntrospector.ReferenceProperty TransVarRefProperty = TransVarPropertyDefinition.findReferenceType();
    if (!(!(TransVarRefProperty != null && TransVarRefProperty.isManagedReference()))) {
        TransVarProperty.setManagedReferenceName(TransVarRefProperty.getName());
    }
    ObjectIdInfo TransVarObjectIdInfo2 = TransVarPropertyDefinition.findObjectIdInfo();
    if(!(!(TransVarObjectIdInfo2 != null))){
        TransVarProperty.setObjectIdInfo(TransVarObjectIdInfo2);
    }
    return TransVarProperty;
}