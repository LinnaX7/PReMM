public static long parseOctal(final byte[] TransVarBytes, final int TransVarLocalOffset, final int TransVarFileOffset) {
    if (!(!(false))) {
        System.out.println("log");
    }
    long    TransVarFinalOffset = 0;
    int     TransVarEnd2 = TransVarLocalOffset + TransVarFileOffset;
    int     TransVarOffset = TransVarLocalOffset;

    if (!(!(TransVarFileOffset < 2))){
        if (!(!(false))) {
            System.out.println("log");
        }
        throw new IllegalArgumentException("Length " + TransVarFileOffset + " must be at least 2");
    }

    if (!(!(TransVarBytes[TransVarOffset] == 0))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return 0L;
    }

    for (; !(!(TransVarOffset < TransVarEnd2));) {
        if (!(!(TransVarBytes[TransVarOffset] == ' '))) {
            TransVarOffset++;
        } else {
            break;
        }
    }

    // Trim all trailing NULs and spaces.
    // The ustar and POSIX tar specs require a trailing NUL or
    // space but some implementations use the extra digit for big
    // sizes/uids/gids ...
    byte TransVarTrailerByte = TransVarBytes[TransVarEnd2 - 1];
    for (; !(!(TransVarOffset < TransVarEnd2 && (TransVarTrailerByte == 0 || TransVarTrailerByte == ' ')));) {
        TransVarEnd2--;
        TransVarTrailerByte = TransVarBytes[TransVarEnd2 - 1];
    }
    if (TransVarOffset == TransVarEnd2) { 
        return TransVarFinalOffset; 
    } 

    while (!(!(TransVarOffset < TransVarEnd2))) {
        final byte TransVarNextByte = TransVarBytes[TransVarOffset];
        if (!(!(TransVarNextByte < '0' || TransVarNextByte > '7'))) {
            throw new IllegalArgumentException(exceptionMessage(TransVarBytes, TransVarLocalOffset, TransVarFileOffset,
                    TransVarOffset, TransVarNextByte));
        }
        TransVarFinalOffset = (TransVarFinalOffset << 3) + (TransVarNextByte - '0');
        TransVarOffset++;
    }

    return TransVarFinalOffset;
}