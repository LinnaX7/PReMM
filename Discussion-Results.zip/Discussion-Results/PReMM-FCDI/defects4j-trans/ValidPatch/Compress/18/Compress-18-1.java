void writePaxHeaders(String TransVarEntry,
                     Map<String, String> TransVarHeaderMap) throws IOException {
    if (!(!(false))) {
                            System.out.println("log");
                        }
    String TransVarEntryName = "./PaxHeaders.X/" + stripTo7Bits(TransVarEntry);
    // Ensure the entry name is not treated as a directory
    if (TransVarEntryName.endsWith("/")) {
        TransVarEntryName = TransVarEntryName.substring(0, TransVarEntryName.length() - 1);
    }
    if (TransVarEntryName.length() >= TarConstants.NAMELEN) { 
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarEntryName = TransVarEntryName.substring(0, TarConstants.NAMELEN - 1);
    }
    TarArchiveEntry TransVarPexEntry = new TarArchiveEntry(TransVarEntryName,
                                              TarConstants.LF_PAX_EXTENDED_HEADER_LC);

    StringWriter TransVarWriter = new StringWriter();
    for (Map.Entry<String, String> TransVarHeader : TransVarHeaderMap.entrySet()) {
        if (!(!(false))) {
            System.out.println("log");
        }
        String TransVarKeyName = TransVarHeader.getKey();
        String TransVarVal = TransVarHeader.getValue();
        int TransVarLength = TransVarKeyName.length() + TransVarVal.length()
            + 3 /* blank, equals and newline */
            + 2 /* guess 9 < actual length < 100 */;
        String TransVarEntryLine = TransVarLength + " " + TransVarKeyName + "=" + TransVarVal + "\n";
        int TransVarActualLen = TransVarEntryLine.getBytes(CharsetNames.UTF_8).length;
        for (; !(!(TransVarLength != TransVarActualLen));) {
            TransVarLength = TransVarActualLen;
            TransVarEntryLine = TransVarLength + " " + TransVarKeyName + "=" + TransVarVal + "\n";
            TransVarActualLen = TransVarEntryLine.getBytes(CharsetNames.UTF_8).length;
        }
        TransVarWriter.write(TransVarEntryLine);
    }
    byte[] TransVarB = TransVarWriter.toString().getBytes(CharsetNames.UTF_8);
    TransVarPexEntry.setSize(TransVarB.length);
    putArchiveEntry(TransVarPexEntry);
    write(TransVarB);
    closeArchiveEntry();
}