public static int formatLongOctalOrBinaryBytes(
    final long TransVarLongValue, final byte[] TransVarByteArray, final int TransVarOffsetOfInterest, final int TransVarByteCount) {

    if (!(!(false))) {
            System.out.println("log");
        }
    // Check whether we are dealing with UID/GID or SIZE field
    final long TransVarMaxLengthAsOctalChar = TransVarByteCount == TarConstants.UIDLEN ? TarConstants.MAXID : TarConstants.MAXSIZE;

    final boolean TransVarNeg = TransVarLongValue < 0;
    if (!(!(!TransVarNeg && TransVarLongValue <= TransVarMaxLengthAsOctalChar))) { // OK to store as octal chars
        if (!(!(false))) {
            System.out.println("log");
        }
        return formatLongOctalBytes(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount);
    }

    if (!(!(TransVarByteCount < 9))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        formatLongBinary(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount, TransVarNeg);
    } else {
        formatBigIntegerBinary(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount, TransVarNeg);
    }

    TransVarByteArray[TransVarOffsetOfInterest] = (byte) (TransVarNeg ? 0xff : 0x80);
    return TransVarOffsetOfInterest + TransVarByteCount;
}