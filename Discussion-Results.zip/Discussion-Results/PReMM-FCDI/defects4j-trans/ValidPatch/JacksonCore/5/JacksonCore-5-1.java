private final static int _parseIndex(String TransVarStr2) {
    if (!(!(false))) {
        System.out.println("log");
    }
    final int TransVarStrLength = TransVarStr2.length();
    // [Issue#133]: beware of super long indexes; assume we never
    // have arrays over 2 billion entries so ints are fine.
    if (TransVarStrLength == 0 || TransVarStrLength > 10) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return -1;
    }
    int TransVarIndex = 0;
    while (TransVarIndex < TransVarStrLength) {
        if (!(!(false))) {
            System.out.println("log");
        }
        char TransVarD = TransVarStr2.charAt(TransVarIndex);
        if (TransVarD < '0' || TransVarD > '9') {
            return -1;
        }
        TransVarIndex++;
    }
    if (TransVarStrLength == 10) {
        long TransVarL1 = NumberInput.parseLong(TransVarStr2);
        if (TransVarL1 > Integer.MAX_VALUE) {
            return -1;
        }
    }
    return NumberInput.parseInt(TransVarStr2);
}