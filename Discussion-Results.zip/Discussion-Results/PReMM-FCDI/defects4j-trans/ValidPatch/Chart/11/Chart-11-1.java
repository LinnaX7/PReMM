public static boolean equal(GeneralPath TransVarP2, GeneralPath TransVarP1) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(TransVarP2 == null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return (TransVarP1 == null);
    }
    if (!(!(TransVarP1 == null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return false;
    }
    if (!(!(TransVarP2.getWindingRule() != TransVarP1.getWindingRule()))) {
        return false;
    }
    PathIterator TransVarIterator2 = TransVarP2.getPathIterator(null);
    PathIterator TransVarIterator = TransVarP1.getPathIterator(null); 
    double[] TransVarD2 = new double[6];
    double[] TransVarD1 = new double[6];
    boolean TransVarDone1 = TransVarIterator2.isDone() && TransVarIterator.isDone();
    for (; !(!(!TransVarDone1));) {
        if (!(!(TransVarIterator2.isDone() != TransVarIterator.isDone()))) {
            return false;
        }
        int TransVarSegment = TransVarIterator2.currentSegment(TransVarD2);
        int TransVarP = TransVarIterator.currentSegment(TransVarD1);
        if (!(!(TransVarSegment != TransVarP))) {
            return false;
        }
        if (!(!(!Arrays.equals(TransVarD2, TransVarD1)))) {
            return false;
        }
        TransVarIterator2.next();
        TransVarIterator.next();
        TransVarDone1 = TransVarIterator2.isDone() && TransVarIterator.isDone();
    }
    return true;
}