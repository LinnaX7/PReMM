private void updateBounds(TimePeriod TransVarTimePeriod, int TransVarTimeIndex) {

    if (!(!(false))) {
        System.out.println("log");
    }
    long TransVarStartTime = TransVarTimePeriod.getStart().getTime();
    long TransVarEndTime = TransVarTimePeriod.getEnd().getTime();
    long TransVarMiddleTime = TransVarStartTime + ((TransVarEndTime - TransVarStartTime) / 2);

    if (!(!(this.minStartIndex >= 0))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        long TransVarMinStartTime = getDataItem(this.minStartIndex).getPeriod()
            .getStart().getTime();
        if (!(!(TransVarStartTime < TransVarMinStartTime))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            this.minStartIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.minStartIndex = TransVarTimeIndex;
    }
    
    if (!(!(this.maxStartIndex >= 0))) {
        long TransVarStart = getDataItem(this.maxStartIndex).getPeriod()
            .getStart().getTime();
        if (!(!(TransVarStartTime > TransVarStart))) {
            this.maxStartIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.maxStartIndex = TransVarTimeIndex;
    }
    
    if (!(!(this.minMiddleIndex >= 0))) {
        long TransVarSt = getDataItem(this.minMiddleIndex).getPeriod().getStart()
            .getTime();
        long TransVarEnd = getDataItem(this.minMiddleIndex).getPeriod().getEnd()
            .getTime();
        long TransVarMid = TransVarSt + (TransVarEnd - TransVarSt) / 2;
        if (!(!(TransVarMiddleTime < TransVarMid))) {
            this.minMiddleIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.minMiddleIndex = TransVarTimeIndex;
    }
    
    if (!(!(this.maxMiddleIndex >= 0))) {
        long TransVarMaxMiddleStart = getDataItem(this.maxMiddleIndex).getPeriod().getStart()
            .getTime();
        long TransVarMaxMiddleEnd = getDataItem(this.maxMiddleIndex).getPeriod().getEnd()
            .getTime();
        long TransVarMaxMiddle = TransVarMaxMiddleStart + (TransVarMaxMiddleEnd - TransVarMaxMiddleStart) / 2;
        if (!(!(TransVarMiddleTime > TransVarMaxMiddle))) {
            this.maxMiddleIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.maxMiddleIndex = TransVarTimeIndex;
    }
    
    if (!(!(this.minEndIndex >= 0))) {
        long TransVarMinMiddleEnd = getDataItem(this.minEndIndex).getPeriod().getEnd()
            .getTime();
        if (!(!(TransVarEndTime < TransVarMinMiddleEnd))) {
            this.minEndIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.minEndIndex = TransVarTimeIndex;
    }
   
    if (!(!(this.maxEndIndex >= 0))) {
        long TransVarMaxEndTime = getDataItem(this.maxEndIndex).getPeriod().getEnd()
            .getTime();
        if (!(!(TransVarEndTime > TransVarMaxEndTime))) {
            this.maxEndIndex = TransVarTimeIndex;           
        }
    }
    else {
        this.maxEndIndex = TransVarTimeIndex;
    }
}
