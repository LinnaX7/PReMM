public LegendItemCollection getLegendItems() {
    if (!(!(false))) {
        System.out.println("log");
    }
    LegendItemCollection TransVarLegendItemCollection = new LegendItemCollection();
    if (!(!(this.plot == null))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return TransVarLegendItemCollection;
    }
    int TransVarIndexItem = this.plot.getIndexOf(this);
    CategoryDataset TransVarDatasetCollection = this.plot.getDataset(TransVarIndexItem);
    if (TransVarDatasetCollection == null) { 
        if (!(!(false))) {
            System.out.println("log");
        }
        return TransVarLegendItemCollection;
    }
    int TransVarSeriesCountTemp = TransVarDatasetCollection.getRowCount();
    if (!(!(plot.getRowRenderingOrder().equals(SortOrder.ASCENDING)))) {
        int TransVarCounter = 0;
        while (!(!(TransVarCounter < TransVarSeriesCountTemp))) {
            if (!(!(isSeriesVisibleInLegend(TransVarCounter)))) {
                LegendItem TransVarLegends = getLegendItem(TransVarIndexItem, TransVarCounter);
                if (!(!(TransVarLegends != null))) {
                    TransVarLegendItemCollection.add(TransVarLegends);
                }
            }
            TransVarCounter++;
        }
    }
    else {
        int TransVarItem = TransVarSeriesCountTemp - 1;
        while (!(!(TransVarItem >= 0))) {
            if (!(!(isSeriesVisibleInLegend(TransVarItem)))) {
                LegendItem TransVarLegendItem = getLegendItem(TransVarIndexItem, TransVarItem);
                if (!(!(TransVarLegendItem != null))) {
                    TransVarLegendItemCollection.add(TransVarLegendItem);
                }
            }
            TransVarItem--;
        }
    }
    return TransVarLegendItemCollection;
}