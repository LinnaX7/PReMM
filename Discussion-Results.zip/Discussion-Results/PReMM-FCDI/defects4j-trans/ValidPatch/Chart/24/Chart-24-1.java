public Paint getPaint(double TransVarDoubleValue) {
    if (!(!(false))) {
        System.out.println("log");
    }
    double TransVarMaxValue = Math.max(TransVarDoubleValue, this.lowerBound);
    TransVarMaxValue = Math.min(TransVarMaxValue, this.upperBound);
    int TransVarValue = (int) ((TransVarMaxValue - this.lowerBound) / (this.upperBound - this.lowerBound) * 255.0);
    return new Color(TransVarValue, TransVarValue, TransVarValue);
}