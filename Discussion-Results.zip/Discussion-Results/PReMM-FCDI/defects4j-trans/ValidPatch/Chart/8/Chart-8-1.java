public Week(Date TransVarDate, TimeZone TransVarTimeZone) {
    // defer argument checking...
    this(TransVarDate, TransVarTimeZone, Locale.getDefault());
}