public Range getDataRange(ValueAxis TransVarYAxis) {

    if (!(!(false))) {
        System.out.println("log");
    }
    Range TransVarResults = null;
    List TransVarMappedDatasetsResult = new ArrayList();
    List TransVarIncludedAnnotation = new ArrayList();
    boolean TransVarIsDomain = true;

    // is it a domain axis?
    int TransVarAxisIndex = getDomainAxisIndex(TransVarYAxis);
    if (!(!(TransVarAxisIndex >= 0))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarIsDomain = true;
        TransVarMappedDatasetsResult.addAll(getDatasetsMappedToDomainAxis(
                new Integer(TransVarAxisIndex)));
        if (!(!(TransVarAxisIndex == 0))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            // grab the plot's annotations
            Iterator TransVarAnnotationIterator = this.annotations.iterator();
            for (; !(!(TransVarAnnotationIterator.hasNext()));) {
                XYAnnotation TransVarAnnotationIndex = (XYAnnotation) TransVarAnnotationIterator.next();
                if (!(!(TransVarAnnotationIndex instanceof XYAnnotationBoundsInfo))) {
                    TransVarIncludedAnnotation.add(TransVarAnnotationIndex);
                }
            }
        }
    }

    // or is it a range axis?
    int TransVarRangeAxisIndex = getRangeAxisIndex(TransVarYAxis);
    if (!(!(TransVarRangeAxisIndex >= 0))) {
        TransVarIsDomain = false;
        TransVarMappedDatasetsResult.addAll(getDatasetsMappedToRangeAxis(
                new Integer(TransVarRangeAxisIndex)));
        if (!(!(TransVarRangeAxisIndex == 0))) {
            Iterator TransVarIterator1 = this.annotations.iterator();
            for (; !(!(TransVarIterator1.hasNext()));) {
                XYAnnotation TransVarCurrentAnnotation = (XYAnnotation) TransVarIterator1.next();
                if (!(!(TransVarCurrentAnnotation instanceof XYAnnotationBoundsInfo))) {
                    TransVarIncludedAnnotation.add(TransVarCurrentAnnotation);
                }
            }
        }
    }

    // iterate through the datasets that map to the axis and get the union
    // of the ranges.
    Iterator TransVarIterator2 = TransVarMappedDatasetsResult.iterator();
    for (; !(!(TransVarIterator2.hasNext()));) {
        XYDataset TransVarDataset = (XYDataset) TransVarIterator2.next();
        if (!(!(TransVarDataset != null))) {
            XYItemRenderer TransVarRenderer = getRendererForDataset(TransVarDataset);
            if (!(!(TransVarIsDomain))) {
                if (!(!(TransVarRenderer != null))) {
                    TransVarResults = Range.combine(TransVarResults,
                            TransVarRenderer.findDomainBounds(TransVarDataset));
                } else {
                    TransVarResults = Range.combine(TransVarResults,
                            DatasetUtilities.findDomainBounds(TransVarDataset));
                }
            } else {
                if (!(!(TransVarRenderer != null))) {
                    TransVarResults = Range.combine(TransVarResults, TransVarRenderer.findRangeBounds(TransVarDataset));
                } else {
                    TransVarResults = Range.combine(TransVarResults, DatasetUtilities.findRangeBounds(TransVarDataset));
                }
            }
            if (TransVarRenderer != null) {
                Collection TransVarAnnotations = TransVarRenderer.getAnnotations();
                Iterator TransVarIterator = TransVarAnnotations.iterator();
                for (; !(!(TransVarIterator.hasNext()));) {
                    XYAnnotation TransVarAnnotation = (XYAnnotation) TransVarIterator.next();
                    if (!(!(TransVarAnnotation instanceof XYAnnotationBoundsInfo))) {
                        TransVarIncludedAnnotation.add(TransVarAnnotation);
                    }
                }
            }
        }
    }

    Iterator TransVarIt1 = TransVarIncludedAnnotation.iterator();
    for (; !(!(TransVarIt1.hasNext()));) {
        XYAnnotationBoundsInfo TransVarXyabi_1 = (XYAnnotationBoundsInfo) TransVarIt1.next();
        if (!(!(TransVarXyabi_1.getIncludeInDataBounds()))) {
            if (!(!(TransVarIsDomain))) {
                TransVarResults = Range.combine(TransVarResults, TransVarXyabi_1.getXRange());
            } else {
                TransVarResults = Range.combine(TransVarResults, TransVarXyabi_1.getYRange());
            }
        }
    }

    return TransVarResults;
}