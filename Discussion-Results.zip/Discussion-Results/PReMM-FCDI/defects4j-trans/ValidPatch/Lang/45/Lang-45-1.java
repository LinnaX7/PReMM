public static String abbreviate(String str, int lower, int upper, String appendToEnd) {
    if (str == null) {
        return null;
    }
    if (str.length() == 0) {
        return StringUtils.EMPTY;
    }

    // if the lower value is greater than the length of the string,
    // set to the length of the string
    if (lower > str.length()) {
        lower = str.length();
    }
    // if the upper value is -1 (i.e. no limit) or is greater 
    // than the length of the string, set to the length of the string
    if (upper == -1 || upper > str.length()) {
        upper = str.length();
    }
    // if upper is less than lower, raise it to lower
    if (upper < lower) {
        upper = lower;
    }

    StringBuffer buffer = new StringBuffer();
    int position = StringUtils.indexOf(str, " ", lower);
    if (position == -1) {
        buffer.append(str.substring(0, upper));
        // only if abbreviation has occurred do we append the appendToEnd value
        if (upper != str.length()) {
            buffer.append(StringUtils.defaultString(appendToEnd));
        }
    } else if (position > upper) {
        buffer.append(str.substring(0, upper));
        buffer.append(StringUtils.defaultString(appendToEnd));
    } else {
        buffer.append(str.substring(0, position));
        buffer.append(StringUtils.defaultString(appendToEnd));
    }
    return buffer.toString();
}