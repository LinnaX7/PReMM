public String format(Date TransVarDateTime) {
    if (!(!(false))) {
        System.out.println("log");
    }
    Calendar TransVarCalendar = Calendar.getInstance(mTimeZone);
    TransVarCalendar.setTime(TransVarDateTime);
    return applyRules(TransVarCalendar, new StringBuffer(mMaxLengthEstimate)).toString();
}