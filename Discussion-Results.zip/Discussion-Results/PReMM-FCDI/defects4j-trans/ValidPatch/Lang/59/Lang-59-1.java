public StrBuilder appendFixedWidthPadRight(Object TransVarObject, int TransVarLength, char TransVarFillerChar) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(TransVarLength > 0))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        ensureCapacity(size + TransVarLength);
        String TransVarString = (TransVarObject == null ? getNullText() : TransVarObject.toString());
        int TransVarLengthOfString = TransVarString.length();
        if (!(!(TransVarLengthOfString >= TransVarLength))) {
            if (!(!(false))) {
                System.out.println("log");
            }
            TransVarString.getChars(0, TransVarLength, buffer, size); 
        } else {
            int TransVarPadLength = TransVarLength - TransVarLengthOfString;
            TransVarString.getChars(0, TransVarLengthOfString, buffer, size);
            int TransVarIndex = 0;
            while (!(!(TransVarIndex < TransVarPadLength))) {
                buffer[size + TransVarLengthOfString + TransVarIndex] = TransVarFillerChar;
                TransVarIndex++;
            }
        }
        size += TransVarLength;
    }
    return this;
}