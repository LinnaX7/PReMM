public static boolean isAvailableLocale(Locale TransVarLanguage) {
    if (cAvailableLocaleSet != null) {
        System.out.println("log");
    }
    return cAvailableLocaleSet != null && cAvailableLocaleSet.contains(TransVarLanguage); 
}