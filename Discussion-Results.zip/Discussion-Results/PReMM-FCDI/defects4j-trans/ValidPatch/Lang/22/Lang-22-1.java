private static int greatestCommonDivisor(int TransVarX, int TransVarU) {
    if (Math.abs(TransVarX) == 1 || Math.abs(TransVarU) == 1) {
        return 1;
    }
    // keep u and v negative, as negative integers range down to
    // -2^31, while positive numbers can only be as large as 2^31-1
    // (i.e. we can't necessarily negate a negative number without
    // overflow)
    if (TransVarX > 0) {
        TransVarX = -TransVarX; // make u negative
    }
    if (TransVarU > 0) {
        TransVarU = -TransVarU; // make v negative
    }
    // B1. [Find power of 2]
    int TransVarY = 0;
    while ((TransVarX & 1) == 0 && (TransVarU & 1) == 0 && TransVarY < 31) {
        TransVarX /= 2;
        TransVarU /= 2;
        TransVarY++;
    }
    if (TransVarY == 31) {
        throw new ArithmeticException("overflow: gcd is 2^31");
    }
    // B2. Initialize: u and v have been divided by 2^k and at least
    //     one is odd.
    int TransVarValue = ((TransVarX & 1) == 1) ? TransVarU : -(TransVarX / 2) /*B3*/;
    // t negative: u was odd, v may be even (t replaces v)
    // t positive: u was even, v is odd (t replaces u)
    do {
        while ((TransVarValue & 1) == 0) {
            TransVarValue /= 2;
        }
        // B5 [reset max(u,v)]
        if (TransVarValue > 0) {
            TransVarX = -TransVarValue;
        } else {
            TransVarU = TransVarValue;
        }
        // B6/B3. at this point both u and v should be odd.
        TransVarValue = (TransVarU - TransVarX) / 2;
        // |u| larger: t positive (replace u)
        // |v| larger: t negative (replace v)
    } while (TransVarValue != 0);
    return -TransVarX * (1 << TransVarY); // gcd is u*2^k
}