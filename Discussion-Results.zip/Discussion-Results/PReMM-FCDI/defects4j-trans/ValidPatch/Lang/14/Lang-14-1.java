public static boolean equals(CharSequence TransVarCs, CharSequence TransVarCs1) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (TransVarCs == TransVarCs1) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return true;
    }
    if (TransVarCs == null || TransVarCs1 == null) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return false;
    }
    return TransVarCs.toString().equals(TransVarCs1.toString());
}