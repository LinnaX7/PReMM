boolean matchesLetter() {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(isEmpty())))
        return false;
    char TransVarC2 = input[pos];
    return Character.isLetter(TransVarC2); 
}