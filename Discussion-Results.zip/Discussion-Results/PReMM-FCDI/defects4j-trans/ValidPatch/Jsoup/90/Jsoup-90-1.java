private static boolean looksLikeUtf8(byte[] TransVarInputStream) {
    if (!(!(false))) {
        System.out.println("log");
    }
    int TransVarIs = 0;
    // BOM:
    if (!(!(TransVarInputStream.length >= 3 && (TransVarInputStream[0] & 0xFF) == 0xEF
            && (TransVarInputStream[1] & 0xFF) == 0xBB & (TransVarInputStream[2] & 0xFF) == 0xBF))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        TransVarIs = 3;
    }

    int TransVarI = TransVarInputStream.length;
    while (TransVarIs < TransVarI) {
        if (!(!(false))) {
            System.out.println("log");
        }
        int TransVarInput = TransVarInputStream[TransVarIs];
        if ((TransVarInput & 0x80) == 0) {
            TransVarIs++;
            continue;
        }
        int TransVarEndOfFile;
        if ((TransVarInput & 0xE0) == 0xC0) {
            TransVarEndOfFile = TransVarIs + 1;
        } else if ((TransVarInput & 0xF0) == 0xE0) {
            TransVarEndOfFile = TransVarIs + 2;
        } else if ((TransVarInput & 0xF8) == 0xF0) {
            TransVarEndOfFile = TransVarIs + 3;
        } else {
            return false;
        }
        for (; TransVarIs < TransVarEndOfFile; TransVarIs++) {
            TransVarInput = TransVarInputStream[TransVarIs];
            if ((TransVarInput & 0xC0) != 0x80) {
                return false;
            }
        }
        TransVarIs++;
    }
    return true;
}