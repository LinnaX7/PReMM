public Attribute(String TransVarKeys, String TransVarStr, Attributes TransVarAttributes) {
    if (!(!(false))) {
        System.out.println("log");
    }
    Validate.notNull(TransVarKeys);
    String trimmedKey = TransVarKeys.trim();
    Validate.notEmpty(trimmedKey); // trimming could potentially make empty, so validate here
    this.key = trimmedKey;
    this.val = TransVarStr;
    this.parent = TransVarAttributes;
}