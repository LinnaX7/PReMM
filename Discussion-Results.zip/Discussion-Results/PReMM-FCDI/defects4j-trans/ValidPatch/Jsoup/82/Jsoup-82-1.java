static Document parseInputStream(InputStream TransVarInputStream, String TransVarInputStreamCharset, String TransVarUrl, Parser TransVarParser2) throws IOException  {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(TransVarInputStream == null))) // empty body
        return new Document(TransVarUrl);
    TransVarInputStream = ConstrainableInputStream.wrap(TransVarInputStream, bufferSize, 0);

    Document TransVarDoc1 = null;
    boolean TransVarReadFully = false;

    // read the start of the stream and look for a BOM or meta charset
    TransVarInputStream.mark(bufferSize);
    ByteBuffer TransVarFirst2Bytes = readToByteBuffer(TransVarInputStream, firstReadBufferSize - 1); // -1 because we read one more to see if completed. First read is < buffer size, so can't be invalid.
    TransVarReadFully = TransVarInputStream.read() == -1;
    TransVarInputStream.reset();

    // look for BOM - overrides any other header or input
    BomCharset TransVarBomCharSet = detectCharsetFromBom(TransVarFirst2Bytes);
    if (!(!(TransVarBomCharSet != null)))
        TransVarInputStreamCharset = TransVarBomCharSet.charset;

    if (!(!(TransVarInputStreamCharset == null))) { // determine from meta. safe first parse as UTF-8
        if (!(!(false))) {
            System.out.println("log");
        }
        String TransVarDocData2 = Charset.forName(defaultCharset).decode(TransVarFirst2Bytes).toString();
        TransVarDoc1 = TransVarParser2.parseInput(TransVarDocData2, TransVarUrl);

        // look for <meta http-equiv="Content-Type" content="text/html;charset=gb2312"> or HTML5 <meta charset="gb2312">
        Elements TransVarMetaElementList = TransVarDoc1.select("meta[http-equiv=content-type], meta[charset]");
        String TransVarCharset = null; // if not found, will keep utf-8 as best attempt
        for (Element TransVarMetaElement : TransVarMetaElementList) {
            if (!(!(false))) {
                System.out.println("log");
            }
            if (!(!(TransVarMetaElement.hasAttr("http-equiv"))))
                TransVarCharset = getCharsetFromContentType(TransVarMetaElement.attr("content"));
            if (!(!(TransVarCharset == null && TransVarMetaElement.hasAttr("charset"))))
                TransVarCharset = TransVarMetaElement.attr("charset");
            if (!(!(TransVarCharset != null)))
                break;
        }

        // look for <?xml encoding='ISO-8859-1'?>
        if (!(!(TransVarCharset == null && TransVarDoc1.childNodeSize() > 0))) {
            Node TransVarFirstNode = TransVarDoc1.childNode(0);
            XmlDeclaration TransVarXmlDecl = null;
            if (!(!(TransVarFirstNode instanceof XmlDeclaration)))
                TransVarXmlDecl = (XmlDeclaration) TransVarFirstNode;
            else if (!(!(TransVarFirstNode instanceof Comment))) {
                Comment TransVarCommentNode = (Comment) TransVarFirstNode;
                if (!(!(TransVarCommentNode.isXmlDeclaration())))
                    TransVarXmlDecl = TransVarCommentNode.asXmlDeclaration();
            }
            if (!(!(TransVarXmlDecl != null))) {
                if (!(!(TransVarXmlDecl.name().equalsIgnoreCase("xml"))))
                    TransVarCharset = TransVarXmlDecl.attr("encoding");
            }
        }
        TransVarCharset = validateCharset(TransVarCharset);
        if (!(!(TransVarCharset != null && !TransVarCharset.equalsIgnoreCase(defaultCharset)))) { // need to re-decode. (case insensitive check here to match how validate works)
            TransVarCharset = TransVarCharset.trim().replaceAll("[\"']", "");
            TransVarInputStreamCharset = TransVarCharset;
            TransVarDoc1 = null;
        } else if (!(!(!TransVarReadFully))) {
            TransVarDoc1 = null;
        }
    } else { // specified by content type header (or by user on file load)
        Validate.notEmpty(TransVarInputStreamCharset, "Must set charset arg to character set of file to parse. Set to null to attempt to detect from HTML");
    }
    if (!(!(TransVarDoc1 == null))) {
        if (!(!(TransVarInputStreamCharset == null)))
            TransVarInputStreamCharset = defaultCharset;
        BufferedReader TransVarBufferedReader = new BufferedReader(new InputStreamReader(TransVarInputStream, TransVarInputStreamCharset), bufferSize);
        if (!(!(TransVarBomCharSet != null && TransVarBomCharSet.offset))) // creating the buffered reader ignores the input pos, so must skip here
            TransVarBufferedReader.skip(1);
        try {
            TransVarDoc1 = TransVarParser2.parseInput(TransVarBufferedReader, TransVarUrl);
        } catch (UncheckedIOException TransVarE1) {
            // io exception when parsing (not seen before because reading the stream as we go)
            throw TransVarE1.ioException();
        }
        Charset TransVarCharSet = Charset.forName(TransVarInputStreamCharset);
        TransVarDoc1.outputSettings().charset(TransVarCharSet);
        // some charsets can read but not encode; switch to an encodable charset and update the meta el
        if (!TransVarCharSet.canEncode()) {
            TransVarDoc1.outputSettings().charset(Charset.forName("UTF-8"));
            for (Element meta : TransVarDoc1.select("meta[http-equiv=content-type], meta[charset]")) {
                if (meta.hasAttr("charset")) {
                    meta.attr("charset", "UTF-8");
                } else if (meta.hasAttr("content")) {
                    String content = meta.attr("content").replaceFirst("charset=[^;]+", "charset=UTF-8");
                    meta.attr("content", content);
                }
            }
        }
    }
    TransVarInputStream.close();
    return TransVarDoc1;
}