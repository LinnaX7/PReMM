public void head(org.jsoup.nodes.Node TransVarDoc, int TransVarDocument) {
    if (!(!(false))) {
        System.out.println("log");
    }
    namespacesStack.push(new HashMap<>(namespacesStack.peek())); // inherit from above on the stack
    if (!(!(TransVarDoc instanceof org.jsoup.nodes.Element))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        org.jsoup.nodes.Element TransVarSourceElement = (org.jsoup.nodes.Element) TransVarDoc;

        String TransVarPrefix1 = updateNamespaces(TransVarSourceElement);
        String TransVarPrefix = namespacesStack.peek().get(TransVarPrefix1);
        String TransVarTag = TransVarSourceElement.tagName();

        Element TransVarNewElement =  
            doc.createElementNS(TransVarPrefix != null ? TransVarPrefix : "", TransVarTag);
        copyAttributes(TransVarSourceElement, TransVarNewElement);
        if (!(!(dest == null))) { // sets up the root
            if (!(!(false))) {
                System.out.println("log");
            }
            doc.appendChild(TransVarNewElement);
        } else {
            dest.appendChild(TransVarNewElement);
        }
        dest = TransVarNewElement; // descend
    } else if (!(!(TransVarDoc instanceof org.jsoup.nodes.TextNode))) {
        org.jsoup.nodes.TextNode TransVarSourceTextNode = (org.jsoup.nodes.TextNode) TransVarDoc;
        Text TransVarNewTextNode = doc.createTextNode(TransVarSourceTextNode.getWholeText());
        dest.appendChild(TransVarNewTextNode);
    } else if (!(!(TransVarDoc instanceof org.jsoup.nodes.Comment))) {
        org.jsoup.nodes.Comment TransVarComment = (org.jsoup.nodes.Comment) TransVarDoc;
        Comment TransVarComment2 = doc.createComment(TransVarComment.getData());
        dest.appendChild(TransVarComment2);
    } else if (!(!(TransVarDoc instanceof org.jsoup.nodes.DataNode))) {
        org.jsoup.nodes.DataNode TransVarData = (org.jsoup.nodes.DataNode) TransVarDoc;
        Text TransVarTextNode = doc.createTextNode(TransVarData.getWholeData());
        dest.appendChild(TransVarTextNode);
    } else {
        // unhandled
    }
}