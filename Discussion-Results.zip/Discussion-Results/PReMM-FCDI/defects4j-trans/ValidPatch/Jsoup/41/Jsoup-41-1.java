    @Override
public boolean equals(Object TransVarObj) {
    if (this == TransVarObj) return true;
    if (TransVarObj == null || getClass() != TransVarObj.getClass()) return false;
    if (!super.equals(TransVarObj)) return false;

    Element element = (Element) TransVarObj;

    // Add your specific equality checks here
    return true; // or return the result of your specific equality checks
}