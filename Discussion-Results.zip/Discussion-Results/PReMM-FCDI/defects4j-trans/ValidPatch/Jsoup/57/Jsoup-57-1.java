public void removeIgnoreCase(String TransVarKeyValue) {
    Validate.notEmpty(TransVarKeyValue);
    if (attributes == null) {
        return;
    }
    Iterator<String> TransVarIterator = attributes.keySet().iterator();
    while (TransVarIterator.hasNext()) {
        String TransVarKey = TransVarIterator.next();
        if (TransVarKey.equalsIgnoreCase(TransVarKeyValue)) {
            TransVarIterator.remove();
        }
    }
}