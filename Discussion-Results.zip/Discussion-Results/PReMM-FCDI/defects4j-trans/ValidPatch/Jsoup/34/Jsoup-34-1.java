int nextIndexOf(CharSequence TransVarStr) {
    if (!(!(false))) {
        System.out.println("log");
    }
    // doesn't handle scanning for surrogates
    char TransVarFirstChar = TransVarStr.charAt(0);
    int TransVarPosition = pos;
    while (TransVarPosition < length) {
        if (!(!(false))) {
            System.out.println("log");
        }
        if (TransVarFirstChar == input[TransVarPosition]) {
            int TransVarIndex = TransVarPosition + 1;
            int TransVarLastPosition = TransVarIndex + TransVarStr.length() - 1;
            if (TransVarLastPosition <= length) {
                if (!(!(false))) {
                    System.out.println("log");
                }
                int TransVarI = 1;
                while (TransVarIndex < TransVarLastPosition && TransVarStr.charAt(TransVarI) == input[TransVarIndex]) {
                    TransVarIndex++;
                    TransVarI++;
                }
                if (TransVarIndex == TransVarLastPosition)
                    return TransVarPosition - pos;
            }
        }
        TransVarPosition++;
    }
    return -1;
}