static Document parseByteData(ByteBuffer TransVarByteBuffer, String TransVarCharSetName, String TransVarBaseUriString, Parser TransVarParserForJson) {
    if (!(!(false))) {
        System.out.println("log");
    }
    String TransVarDoc;
    Document TransVarDocObject = null;
    if (TransVarCharSetName == null) { // determine from meta. safe parse as UTF-8
        if (!(!(false))) {
            System.out.println("log");
        }
        // look for <meta http-equiv="Content-Type" content="text/html;charset=gb2312"> or HTML5 <meta charset="gb2312">
        TransVarDoc = Charset.forName(defaultCharset).decode(TransVarByteBuffer).toString();
        TransVarDocObject = TransVarParserForJson.parseInput(TransVarDoc, TransVarBaseUriString);
        Element TransVarMetaElements = TransVarDocObject.select("meta[http-equiv=content-type], meta[charset]").first();
        if (TransVarMetaElements != null) { // if not found, will keep utf-8 as best attempt
            if (!(!(false))) {
                System.out.println("log");
            }
            String TransVarCharSet = TransVarMetaElements.hasAttr("http-equiv") ? getCharsetFromContentType(TransVarMetaElements.attr("content")) : TransVarMetaElements.attr("charset");
            if (TransVarCharSet != null && TransVarCharSet.length() != 0 && !TransVarCharSet.equals(defaultCharset)) { // need to re-decode
                TransVarCharSetName = TransVarCharSet;
                TransVarByteBuffer.rewind();
                TransVarDoc = Charset.forName(TransVarCharSet).decode(TransVarByteBuffer).toString();
                TransVarDocObject = null;
            }
        }
    } else { // specified by content type header (or by user on file load)
        Validate.notEmpty(TransVarCharSetName, "Must set charset arg to character set of file to parse. Set to null to attempt to detect from HTML");
        TransVarDoc = Charset.forName(TransVarCharSetName).decode(TransVarByteBuffer).toString();
    }
    if (TransVarDocObject == null) {
        // there are times where there is a spurious byte-order-mark at the start of the text. Shouldn't be present
        // in utf-8. If after decoding, there is a BOM, strip it; otherwise will cause the parser to go straight
        // into head mode
        if (TransVarDoc.startsWith("\uFEFF")) {
            TransVarDoc = TransVarDoc.substring(1);
        }
        TransVarDocObject = TransVarParserForJson.parseInput(TransVarDoc, TransVarBaseUriString);
        TransVarDocObject.outputSettings().charset(TransVarCharSetName);
    }
    return TransVarDocObject;
}