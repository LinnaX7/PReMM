public boolean isArmstrong(int number) {
    if (number < 0) {
        return false; // Armstrong numbers are non-negative
    }
    
    long sum = 0;
    long number2 = number;
    int numDigits = String.valueOf(number).length();
    
    while (number2 > 0) {
        long mod = number2 % 10;
        sum += Math.pow(mod, numDigits);
        number2 /= 10;
    }
    
    return sum == number;
}