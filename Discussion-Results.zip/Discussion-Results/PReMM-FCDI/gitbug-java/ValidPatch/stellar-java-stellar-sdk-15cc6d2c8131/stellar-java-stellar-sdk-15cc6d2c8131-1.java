    @Override
    public boolean equals(Object object) {
        if (!(object instanceof KeyPair)) {
            return false;
        }

        KeyPair other = (KeyPair) object;
        if (this.mPrivateKey == null) {
            if (other.mPrivateKey != null) {
                return false;
            }
        } else if (!this.mPrivateKey.equals(other.mPrivateKey)) {
            return false;
        }

        if (this.mPublicKey == null) {
            if (other.mPublicKey != null) {
                return false;
            }
        } else if (!this.mPublicKey.equals(other.mPublicKey)) {
            return false;
        }

        return true;
    }