private String consumeSubQuery() {
    StringBuilder sq = StringUtil.borrowBuilder();
    while (!tq.isEmpty()) {
        if (tq.matches("(")) {
            sq.append("(").append(tq.chompBalanced('(', ')')).append(")");
        } else if (tq.matches("[")) {
            sq.append("[").append(tq.chompBalanced('[', ']')).append("]");
        } else if (tq.matchesAny(Combinators)) {
            if (sq.length() > 0) {
                break;
            } else {
                sq.append(tq.consume()); // Append the combinator token
            }
        } else {
            sq.append(tq.consume());
        }
    }
    return StringUtil.releaseBuilder(sq);
}