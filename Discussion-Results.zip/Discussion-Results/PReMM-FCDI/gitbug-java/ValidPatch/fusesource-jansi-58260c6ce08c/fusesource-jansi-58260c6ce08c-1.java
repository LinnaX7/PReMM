public static Appendable render(final String input, Appendable target) throws IOException {
    int i = 0;
    int j, k;

    while (true) {
        j = input.indexOf(BEGIN_TOKEN, i);
        if (j == -1) {
            if (i == 0) {
                target.append(input);
                return target;
            }
            target.append(input.substring(i));
            return target;
        }
        target.append(input.substring(i, j));
        k = input.indexOf(END_TOKEN, j);

        if (k == -1) {
            target.append(input.substring(j));
            return target;
        }
        j += BEGIN_TOKEN_LEN;
        String spec = input.substring(j, k);

        String[] items = spec.split(CODE_TEXT_SEPARATOR, 2);
        if (items.length == 1) {
            target.append(spec);
            continue;
        }
        String code = items[0];
        String text = items[1];

        applyAnsiCode(code, target);
        target.append(text);
        resetAnsiCode(target);

        i = k + END_TOKEN_LEN;
    }
}

private static void applyAnsiCode(String code, Appendable target) throws IOException {
    // Implement the logic to apply the ANSI code to the target
    // For example, if code is "31", it means red color
    // This is a placeholder for the actual implementation
    target.append("\u001B[").append(code).append("m");
}

private static void resetAnsiCode(Appendable target) throws IOException {
    // Reset the ANSI code to default
    target.append("\u001B[0m");
}