private void parseCommand() throws SnowflakeSQLException {
    // For AWS and Azure, this command returns enough info for us to get creds
    // we can use for each of the GETs/PUTs. For GCS, we need to issue a separate
    // call to GS to get creds (in the form of a presigned URL) for each file
    // we're uploading or downloading. This call gets our src_location and
    // encryption material, which we'll use for all the subsequent calls to GS
    // for creds for each file. Those calls are made from pushFileToRemoteStore
    // and pullFileFromRemoteStore if the storage client requires a presigned
    // URL.
    JsonNode jsonNode = parseCommandInGS(statement, command);

    // get command type
    if (!jsonNode.path("data").path("command").isMissingNode()) {
      commandType = CommandType.valueOf(jsonNode.path("data").path("command").asText());
    }

    // get source file locations as array (apply to both upload and download)
    JsonNode locationsNode = jsonNode.path("data").path("src_locations");

    queryID = jsonNode.path("data").path("queryId").asText();

    assert locationsNode.isArray();

    String[] src_locations;

    try {
      // Normal flow will never hit here. This is only for testing purposes
      if (isInjectedFileTransferExceptionEnabled()
          && injectedFileTransferException instanceof SnowflakeSQLException) {
        throw (SnowflakeSQLException) SnowflakeFileTransferAgent.injectedFileTransferException;
      }

      src_locations = mapper.readValue(locationsNode.toString(), String[].class);
      initEncryptionMaterial(commandType, jsonNode);
      initPresignedUrls(commandType, jsonNode);
    } catch (Exception ex) {
      throw new SnowflakeSQLException(
          ex,
          SqlState.INTERNAL_ERROR,
          ErrorCode.INTERNAL_ERROR.getMessageCode(),
          "Failed to parse the locations due to: " + ex.getMessage());
    }

    showEncryptionParameter =
        jsonNode.path("data").path("clientShowEncryptionParameter").asBoolean();

    JsonNode thresholdNode = jsonNode.path("data").path("threshold");
    int threshold = thresholdNode.asInt();
    // if value is <= 0, this means an error was made in parsing the threshold or the threshold is
    // invalid.
    // Only use the threshold value if it is valid.
    if (threshold > 0) {
      bigFileThreshold = threshold;
    }

    String localFilePathFromGS = null;

    // do upload command specific parsing
    if (commandType == CommandType.UPLOAD) {
      if (src_locations.length > 0) {
        localFilePathFromGS = src_locations[0];
      }

      sourceFiles = expandFileNames(src_locations);

      autoCompress = jsonNode.path("data").path("autoCompress").asBoolean(true);

      if (!jsonNode.path("data").path("sourceCompression").isMissingNode()) {
        sourceCompression = jsonNode.path("data").path("sourceCompression").asText();
      }

    } else {
      // do download command specific parsing
      srcFileToEncMat = new HashMap<>();

      // create mapping from source file to encryption materials
      if (src_locations.length == encryptionMaterial.size()) {
        for (int srcFileIdx = 0; srcFileIdx < src_locations.length; srcFileIdx++) {
          srcFileToEncMat.put(src_locations[srcFileIdx], encryptionMaterial.get(srcFileIdx));
        }
      }

      // create mapping from source file to presigned URLs
      srcFileToPresignedUrl = new HashMap<>();
      if (src_locations.length == presignedUrls.size()) {
        for (int srcFileIdx = 0; srcFileIdx < src_locations.length; srcFileIdx++) {
          srcFileToPresignedUrl.put(src_locations[srcFileIdx], presignedUrls.get(srcFileIdx));
        }
      }

      sourceFiles = new HashSet<String>(Arrays.asList(src_locations));

      localLocation = jsonNode.path("data").path("localLocation").asText();

      localFilePathFromGS = localLocation;

      if (localLocation.startsWith("~")) {
        // replace ~ with user home
        localLocation = System.getProperty("user.home") + localLocation.substring(1);
      }

      // it should not contain any ~ after the above replacement
      if (localLocation.contains("~")) {
        throw new SnowflakeSQLLoggedException(
            session,
            ErrorCode.PATH_NOT_DIRECTORY.getMessageCode(),
            SqlState.IO_ERROR,
            localLocation);
      }

      // todo: replace ~userid with the home directory of a given userid
      // one idea is to get the home directory for current user and replace
      // the last user id with the given user id.

      // user may also specify files relative to current directory
      // add the current path if that is the case
      if (!(new File(localLocation)).isAbsolute()) {
        String cwd = System.getProperty("user.dir");

        logger.debug("Adding current working dir to relative file path.", false);

        localLocation = cwd + localFSFileSep + localLocation;
      }

      // local location should be a directory
      if ((new File(localLocation)).isFile()) {
        throw new SnowflakeSQLLoggedException(
            session,
            ErrorCode.PATH_NOT_DIRECTORY.getMessageCode(),
            SqlState.IO_ERROR,
            localLocation);
      }
    }

    // SNOW-15153: verify that the value after file:// is not changed by GS
    verifyLocalFilePath(localFilePathFromGS);

    parallel = jsonNode.path("data").path("parallel").asInt();

    overwrite = jsonNode.path("data").path("overwrite").asBoolean(false);

    stageInfo = getStageInfo(jsonNode, this.session);

    if (logger.isDebugEnabled()) {
      logger.debug("Command type: {}", commandType);

      if (commandType == CommandType.UPLOAD) {
        logger.debug("autoCompress: {}, source compression: {}", autoCompress, sourceCompression);
      } else {
        logger.debug("local download location: {}", localLocation);
      }

      logger.debug("Source files: {}", String.join(",", sourceFiles));
      logger.debug(
          "stageLocation: {}, parallel: {}, overwrite: {}, destLocationType: {}, stageRegion: {}," +
              " endPoint: {}, storageAccount: {}",
          stageInfo.getLocation(),
          parallel,
          overwrite,
          stageInfo.getStageType(),
          stageInfo.getRegion(),
          stageInfo.getEndPoint(),
          stageInfo.getStorageAccount());
    }
  }static Set<String> expandFileNames(String[] filePathList) throws SnowflakeSQLException {
    Set<String> result = new HashSet<String>();

    // a location to file pattern map so that we only need to list the
    // same directory once when they appear in multiple times.
    Map<String, List<String>> locationToFilePatterns;

    locationToFilePatterns = new HashMap<String, List<String>>();

    String cwd = System.getProperty("user.dir");

    for (String path : filePathList) {
      // replace ~ with user home
      path = path.replaceFirst("^~", System.getProperty("user.home"));

      // user may also specify files relative to current directory
      // add the current path if that is the case
      if (!(new File(path)).isAbsolute()) {
        logger.debug("Adding current working dir to relative file path.");

        path = cwd + localFSFileSep + path;
      }

      // check if the path contains any wildcards
      if (!path.contains("*")
          && !path.contains("?")
          && !(path.contains("[") && path.contains("]"))) {
        /* this file path doesn't have any wildcard, so we don't need to
         * expand it
         */
        result.add(path);
      } else {
        // get the directory path
        int lastFileSepIndex = path.lastIndexOf(localFSFileSep);

        // SNOW-15203: if we don't find a default file sep, try "/" if it is not
        // the default file sep.
        if (lastFileSepIndex < 0 && !"/".equals(localFSFileSep)) {
          lastFileSepIndex = path.lastIndexOf("/");
        }

        String loc = path.substring(0, lastFileSepIndex + 1);

        String filePattern = path.substring(lastFileSepIndex + 1);

        List<String> filePatterns = locationToFilePatterns.get(loc);

        if (filePatterns == null) {
          filePatterns = new ArrayList<String>();
          locationToFilePatterns.put(loc, filePatterns);
        }

        filePatterns.add(filePattern);
      }
    }

    // For each location, list files and match against the patterns
    for (Map.Entry<String, List<String>> entry : locationToFilePatterns.entrySet()) {
      try {
        java.io.File dir = new java.io.File(entry.getKey());

        logger.debug(
            "Listing files under: {} with patterns: {}",
            entry.getKey(),
            entry.getValue().toString());

        // Normal flow will never hit here. This is only for testing purposes
        if (isInjectedFileTransferExceptionEnabled()
            && injectedFileTransferException instanceof Exception) {
          throw (Exception) SnowflakeFileTransferAgent.injectedFileTransferException;
        }

        // The following currently ignore sub directories
        for (Object file :
            FileUtils.listFiles(dir, new WildcardFileFilter(entry.getValue()), null)) {
          result.add(((java.io.File) file).getCanonicalPath());
        }
      } catch (Exception ex) {
        throw new SnowflakeSQLException(
            ex,
            SqlState.DATA_EXCEPTION,
            ErrorCode.FAIL_LIST_FILES.getMessageCode(),
            "Exception: "
                + ex.getMessage()
                + ", Dir="
                + entry.getKey()
                + ", Patterns="
                + entry.getValue().toString());
      }
    }

    logger.debug("Expanded file paths: ");

    for (String filePath : result) {
      logger.debug("file: {}", filePath);
    }

    return result;
  }