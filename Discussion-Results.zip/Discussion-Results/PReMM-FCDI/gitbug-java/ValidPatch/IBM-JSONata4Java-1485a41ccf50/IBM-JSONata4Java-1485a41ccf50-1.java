private ArrayNode orderBy(final ArrayNode in, final List<OrderByField> sortFields) {
    final List<JsonNode> jsonNodes = new ArrayList<>();
    final Iterator<JsonNode> iter = in.elements();
    while (iter.hasNext()) {
        jsonNodes.add(iter.next());
    }
    Collections.sort(jsonNodes, new Comparator<JsonNode>() {

        @Override
        public int compare(JsonNode o1, JsonNode o2) {
            for (final OrderByField sortField : sortFields) {
                JsonNode n1 = o1.get(sortField.name);
                JsonNode n2 = o2.get(sortField.name);

                if (n1 == null && n2 == null) {
                    continue; // Both are null, move to next field
                } else if (n1 == null) {
                    return sortField.order == OrderByOrder.DESC ? 1 : -1; // Nulls last for ASC, first for DESC
                } else if (n2 == null) {
                    return sortField.order == OrderByOrder.DESC ? -1 : 1; // Nulls first for ASC, last for DESC
                }

                if (n1.isTextual() && n2.isTextual()) {
                    final int comp = n1.asText().compareTo(n2.asText());
                    if (comp != 0) {
                        return sortField.order == OrderByOrder.DESC ? comp * (-1) : comp;
                    }
                } else if (n1.isNumber() && n2.isNumber()) {
                    final int comp = Double.compare(n1.doubleValue(), n2.doubleValue());
                    if (comp != 0) {
                        return sortField.order == OrderByOrder.DESC ? comp * (-1) : comp;
                    }
                } else if (n1.isBoolean() && n2.isBoolean()) {
                    final int comp = Boolean.compare(n1.booleanValue(), n2.booleanValue());
                    if (comp != 0) {
                        return sortField.order == OrderByOrder.DESC ? comp * (-1) : comp;
                    }
                } else {
                    // Fallback to string comparison for mixed types
                    final int comp = n1.toString().compareTo(n2.toString());
                    if (comp != 0) {
                        return sortField.order == OrderByOrder.DESC ? comp * (-1) : comp;
                    }
                }
            }
            return 0;
        }
    });
    return new ArrayNode(factory, jsonNodes);
}