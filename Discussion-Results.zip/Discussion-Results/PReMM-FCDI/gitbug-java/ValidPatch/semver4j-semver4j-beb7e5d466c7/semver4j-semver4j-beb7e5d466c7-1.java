@Override
public String process(String range) {
    String[] rangeVersions = range.split("\\s+");

    List<String> objects = new ArrayList<>();
    for (String rangeVersion : rangeVersions) {
        Matcher matcher = pattern.matcher(rangeVersion);

        if (matcher.matches()) {
            // Left unused variables for brevity.

            String fullRange = matcher.group(0);

            String compareSign = matcher.group(1);

            int major = parseIntWithXSupport(matcher.group(2));
            int minor = parseIntWithXSupport(matcher.group(3));
            int patch = parseIntWithXSupport(matcher.group(4));
            String preRelease = matcher.group(5);
            String build = matcher.group(6);

            if (compareSign.equals(EQ.asString()) && isX(patch)) {
                compareSign = EMPTY;
            }

            if (!compareSign.isEmpty() && isX(patch)) {
                if (isX(minor)) {
                    minor = 0;
                    patch = 0;
                    if (compareSign.equals(GT.asString())) {
                        compareSign = GTE.asString();
                        major = major + 1;
                    } else if (compareSign.equals(LTE.asString())) {
                        compareSign = LT.asString();
                        major = major + 1;
                    }
                } else {
                    patch = 0;
                    if (compareSign.equals(GT.asString())) {
                        compareSign = GTE.asString();
                        minor = minor + 1;
                    } else if (compareSign.equals(LTE.asString())) {
                        compareSign = LT.asString();
                        minor = minor + 1;
                    }
                }

                String from = format(Locale.ROOT, "%s%d.%d.%d", compareSign, major, minor, patch);
                objects.add(from);
            } else if (isX(minor)) {
                String from = format(Locale.ROOT, "%s%d.0.0", GTE.asString(), major);
                String to = format(Locale.ROOT, "%s%d.0.0", LT.asString(), (major + 1));
                objects.add(from);
                objects.add(to);
            } else if (isX(patch)) {
                String from = format(Locale.ROOT, "%s%d.%d.0", GTE.asString(), major, minor);
                String to = format(Locale.ROOT, "%s%d.%d.0", LT.asString(), major, (minor + 1));
                objects.add(from);
                objects.add(to);
            } else {
                objects.add(fullRange);
            }
        }
    }

    if (objects.isEmpty()) {
        return range;
    }

    return join(SPACE, objects);
}