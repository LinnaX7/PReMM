private String initialToString() {
    StringBuilder sb = new StringBuilder();
    if (!resolutionParameters.isEmpty()) {
        sb.append("?+");
        boolean first = true;
        for (Map.Entry<String, String> kv : resolutionParameters.entrySet()) {
            if (!first) {
                sb.append('&');
            }
            sb.append(kv.getKey()).append('=').append(kv.getValue());
            first = false;
        }
    }
    if (!queryParameters.isEmpty()) {
        sb.append("?=");
        boolean first = true;
        for (Map.Entry<String, String> kv : queryParameters.entrySet()) {
            if (!first) {
                sb.append('&');
            }
            sb.append(kv.getKey()).append('=').append(kv.getValue());
            first = false;
        }
    }
    if (!fragment.isEmpty()) {
        sb.append('#').append(fragment);
    }
    return sb.toString();
}