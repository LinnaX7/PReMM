public static ParticipantAction from(MemberStatus memberStatus, boolean disabled) {
    return switch (memberStatus) {
        case UNKNOWN, DECLINED -> new ParticipantAction(
                "/member/accept",
                "Participate in Rotation &#x2328;",
                disabled);
        case PARTICIPANT -> new ParticipantAction(
                "/member/decline",
                "Leave Rotation &#x1f44b;",
                false); // can always leave
        case SPECTATOR -> new ParticipantAction(
                "/member/accept",
                "Switch to Participant &#x2328;",
                disabled);
    };
}