public OutputSettings() {
    // Initialize any necessary fields here
}public OutputSettings charset(Charset charset) {
    this.charset = charset;
    // Ensure the charset is set correctly
    coreCharset = Entities.CoreCharset.byName(charset.name());
    return this;
}CharsetEncoder prepareEncoder() {
    // created at start of OuterHtmlVisitor so each pass has own encoder, so OutputSettings can be shared among threads
    CharsetEncoder encoder = charset.newEncoder();
    encoderThreadLocal.set(encoder);
    // Ensure coreCharset is set correctly
    coreCharset = Entities.CoreCharset.byName(charset.name());
    return encoder;
}