@Override
public Iterable<Path> getRootDirectories() {
    return Collections.singletonList(S3Path.getPath(this, "/"));
}