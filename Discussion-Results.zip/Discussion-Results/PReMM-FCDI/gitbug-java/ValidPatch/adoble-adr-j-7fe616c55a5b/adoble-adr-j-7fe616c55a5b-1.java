private int highestIndex() throws ADRException {
    OptionalInt highestIndex;

    Path docPath = env.fileSystem.getPath(properties.getProperty("docPath"));
    Path rootPath = ADR.getRootPath(env);
    Path adrPath = rootPath.resolve(docPath);

    try {
        highestIndex = Files.list(adrPath)
                            .filter(p -> p.getFileName().toString().matches("\\d{4}.*")) // Filter out invalid file names
                            .mapToInt(p -> {
                                try {
                                    return CommandNew.toInt(p);
                                } catch (NumberFormatException e) {
                                    return -1; // Return -1 for invalid file names
                                }
                            })
                            .filter(i -> i >= 0) // Filter out -1 values
                            .max();
    } catch (IOException e) {
        throw new ADRException("FATAL: Unable to determine the indexes of the ADRs.", e);
    }

    return (highestIndex.isPresent() ? highestIndex.getAsInt() : 0);
}private static int toInt(Path p) {
    String name = p.getFileName().toString();

    if (name.length() >= 4 && name.matches("^\\d{4}.*")) {
        String id = name.substring(0, 4);
        return Integer.parseInt(id);
    } else {
        throw new IllegalArgumentException("Invalid file name: " + name);
    }
}