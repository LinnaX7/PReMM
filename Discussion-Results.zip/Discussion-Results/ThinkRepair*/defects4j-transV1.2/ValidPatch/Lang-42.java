
public void escape(Writer TransVarMyWriter, String TransVarMyString) throws IOException {
    int TransVarStrLen = TransVarMyString.length();
    int TransVarJ = 0;
    while (TransVarJ < TransVarStrLen) {
        int codePoint = TransVarMyString.codePointAt(TransVarJ);
        String TransVarEntityName1 = this.entityName(codePoint);
        if (TransVarEntityName1 == null) {
            if (codePoint > 0x7F) {
                TransVarMyWriter.write("&#");
                TransVarMyWriter.write(Integer.toString(codePoint, 10));
                TransVarMyWriter.write(';');
            } else {
                TransVarMyWriter.write(Character.toChars(codePoint));
            }
        } else {
            TransVarMyWriter.write('&');
            TransVarMyWriter.write(TransVarEntityName1);
            TransVarMyWriter.write(';');
        }
        TransVarJ += Character.charCount(codePoint);
    }
}