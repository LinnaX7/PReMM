
private void prelim(double[] TransVarUpperBound,
                    double[] TransVarLowerBound) {
    if (false) {
        System.out.println("log");
    }
    printMethod(); // XXX

    final int TransVarDimension = currentBest.getDimension();
    final int TransVarNumberOfPoints = numberOfInterpolationPoints;
    final int TransVarRows = bMatrix.getRowDimension();

    final double TransVarTrustRegionRadiusSquared = initialTrustRegionRadius * initialTrustRegionRadius;
    final double TransVarReciprocalRhosq = 1d / TransVarTrustRegionRadiusSquared;
    final int TransVarN2 = TransVarDimension + 1;

    // Set XBASE to the initial vector of variables, and set the initial
    // elements of XPT, BMAT, HQ, PQ and ZMAT to zero.

    for (int TransVarI = 0; TransVarI < TransVarDimension; TransVarI++) {
        if (false) {
            System.out.println("log");
        }
        originShift.setEntry(TransVarI, currentBest.getEntry(TransVarI));
        for (int TransVarIndex = 0; TransVarIndex < TransVarNumberOfPoints; TransVarIndex++) {
            if (false) {
                System.out.println("log");
            }
            interpolationPoints.setEntry(TransVarIndex, TransVarI, 0.0);
        }
        for (int TransVarIi = 0; TransVarIi < TransVarRows; TransVarIi++) {
            bMatrix.setEntry(TransVarIi, TransVarI, 0.0);
        }
    }
    for (int TransVarCount = 0; TransVarCount < TransVarDimension * TransVarN2 / 2; TransVarCount++) {
        modelSecondDerivativesValues.setEntry(TransVarCount, 0.0);
    }
    for (int TransVarNewK = 0; TransVarNewK < TransVarNumberOfPoints; TransVarNewK++) {
        modelSecondDerivativesParameters.setEntry(TransVarNewK, 0.0);
        for (int TransVarJj = 0; TransVarJj < TransVarNumberOfPoints - TransVarN2; TransVarJj++) {
            zMatrix.setEntry(TransVarNewK, TransVarJj, 0.0);
        }
    }

    // Begin the initialization procedure. NF becomes one more than the number
    // of function values so far. The coordinates of the displacement of the
    // next initial interpolation point from XBASE are set in XPT(NF+1,.).

    int TransVarIp = 0;
    int TransVarIpt = 0;
    double TransVarBeg = Double.NaN;
    do {
        final int TransVarEvaluations = getEvaluations();
        final int TransVarNf = TransVarEvaluations - TransVarDimension;
        final int TransVarNfmmm = TransVarEvaluations - 1;
        final int TransVarNfx = TransVarNf - 1;
        double TransVarStep = 0;
        double TransVarStepa = 0;
        if (TransVarEvaluations <= 2 * TransVarDimension) {
            if (TransVarEvaluations >= 1 && TransVarEvaluations <= TransVarDimension) {
                TransVarStep = initialTrustRegionRadius;
                if (upperDifference.getEntry(TransVarNfmmm) == 0.0) {
                    TransVarStep = -TransVarStep;
                }
                interpolationPoints.setEntry(TransVarEvaluations, TransVarNfmmm, TransVarStep);
            } else if (TransVarEvaluations > TransVarDimension) {
                TransVarStep = interpolationPoints.getEntry(TransVarNf, TransVarNfx);
                TransVarStepa = -initialTrustRegionRadius;
                if (lowerDifference.getEntry(TransVarNfx) == 0.0) {
                    TransVarStepa = Math.min(2 * initialTrustRegionRadius, upperDifference.getEntry(TransVarNfx));
                }
                if (upperDifference.getEntry(TransVarNfx) == 0.0) {
                    TransVarStepa = Math.max(-2 * initialTrustRegionRadius, lowerDifference.getEntry(TransVarNfx));
                }
                interpolationPoints.setEntry(TransVarEvaluations, TransVarNfx, TransVarStepa);
            }
        } else {
            final int TransVarTmp2 = (TransVarEvaluations - TransVarN2) / TransVarDimension;
            TransVarIpt = TransVarEvaluations - TransVarTmp2 * TransVarDimension - TransVarDimension;
            TransVarIp = TransVarIpt + TransVarTmp2;
            if (TransVarIp > TransVarDimension) {
                final int TransVarTmp = TransVarIpt;
                TransVarIpt = TransVarIp - TransVarDimension;
                TransVarIp = TransVarTmp;
            }
            final int TransVarIMinus1 = TransVarIp - 1;
            final int TransVarJpt = TransVarIpt - 1;
            interpolationPoints.setEntry(TransVarEvaluations, TransVarIMinus1, interpolationPoints.getEntry(TransVarIp, TransVarIMinus1));
            interpolationPoints.setEntry(TransVarEvaluations, TransVarJpt, interpolationPoints.getEntry(TransVarIpt, TransVarJpt));
        }

        // Calculate the next value of F. The least function value so far and
        // its index are required.

        for (int TransVarJ1 = 0; TransVarJ1 < TransVarDimension; TransVarJ1++) {
            currentBest.setEntry(TransVarJ1,
                    Math.min(
                            Math.max(TransVarUpperBound[TransVarJ1],
                                    originShift.getEntry(TransVarJ1)
                                            + interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1)),
                            TransVarLowerBound[TransVarJ1]));
            if (interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1) == lowerDifference.getEntry(TransVarJ1)) {
                currentBest.setEntry(TransVarJ1, TransVarUpperBound[TransVarJ1]);
            }
            if (interpolationPoints.getEntry(TransVarEvaluations, TransVarJ1) == upperDifference.getEntry(TransVarJ1)) {
                currentBest.setEntry(TransVarJ1, TransVarLowerBound[TransVarJ1]);
            }
        }

        final double TransVarValue = computeObjectiveValue(currentBest.toArray());
        final double TransVarMaximization = isMinimize ? TransVarValue : -TransVarValue;
        final int TransVarNum = getEvaluations(); // nfm + 1
        fAtInterpolationPoints.setEntry(TransVarEvaluations, TransVarMaximization);

        if (TransVarNum == 1) {
            TransVarBeg = TransVarMaximization;
            trustRegionCenterInterpolationPointIndex = 0;
        } else if (TransVarMaximization < fAtInterpolationPoints.getEntry(trustRegionCenterInterpolationPointIndex)) {
            trustRegionCenterInterpolationPointIndex = TransVarEvaluations;
        }

        // Set the nonzero initial elements of BMAT and the quadratic model in the
        // cases when NF is at most 2*N+1. If NF exceeds N+1, then the positions
        // of the NF-th and (NF-N)-th interpolation points may be switched, in
        // order that the function value at the first of them contributes to the
        // off-diagonal second derivative terms of the initial quadratic model.

        if (TransVarNum <= 2 * TransVarDimension + 1) {
            if (TransVarNum >= 2 && TransVarNum <= TransVarDimension + 1) {
                gradientAtTrustRegionCenter.setEntry(TransVarNfmmm, (TransVarMaximization - TransVarBeg) / TransVarStep);
                if (TransVarNumberOfPoints < TransVarNum + TransVarDimension) {
                    final double TransVarOos = 1.0 / TransVarStep;
                    bMatrix.setEntry(0, TransVarNfmmm, -TransVarOos);
                    bMatrix.setEntry(TransVarEvaluations, TransVarNfmmm, TransVarOos);
                    bMatrix.setEntry(TransVarNumberOfPoints + TransVarNfmmm, TransVarNfmmm, -0.5 * TransVarTrustRegionRadiusSquared);
                }
            } else if (TransVarNum >= TransVarDimension + 2) {
                final int TransVarIj = TransVarNf * (TransVarNf + 1) / 2 - 1;
                final double TransVarFNew = (TransVarMaximization - TransVarBeg) / TransVarStepa;
                final double TransVarH = TransVarStepa - TransVarStep;
                modelSecondDerivativesValues.setEntry(TransVarIj, 2.0 * (TransVarFNew - gradientAtTrustRegionCenter.getEntry(TransVarNfx)) / TransVarH);
                gradientAtTrustRegionCenter.setEntry(TransVarNfx, (gradientAtTrustRegionCenter.getEntry(TransVarNfx) * TransVarStepa - TransVarFNew * TransVarStep) / TransVarH);
                if (TransVarStep * TransVarStepa < 0.0) {
                    if (TransVarMaximization < fAtInterpolationPoints.getEntry(TransVarEvaluations - TransVarDimension)) {
                        fAtInterpolationPoints.setEntry(TransVarEvaluations, fAtInterpolationPoints.getEntry(TransVarEvaluations - TransVarDimension));
                        fAtInterpolationPoints.setEntry(TransVarEvaluations - TransVarDimension, TransVarMaximization);
                        if (trustRegionCenterInterpolationPointIndex == TransVarEvaluations) {
                            trustRegionCenterInterpolationPointIndex = TransVarEvaluations - TransVarDimension;
                        }
                        interpolationPoints.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx, TransVarStepa);
                        interpolationPoints.setEntry(TransVarEvaluations, TransVarNfx, TransVarStep);
                    }
                }
                bMatrix.setEntry(0, TransVarNfx, -(TransVarStep + TransVarStepa) / (TransVarStep * TransVarStepa));
                bMatrix.setEntry(TransVarEvaluations, TransVarNfx, -0.5 / interpolationPoints.getEntry(TransVarEvaluations - TransVarDimension, TransVarNfx));
                bMatrix.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx,
                              -bMatrix.getEntry(0, TransVarNfx) - bMatrix.getEntry(TransVarEvaluations, TransVarNfx));
                zMatrix.setEntry(0, TransVarNfx, Math.sqrt(2.0) / (TransVarStep * TransVarStepa));
                zMatrix.setEntry(TransVarEvaluations, TransVarNfx, Math.sqrt(0.5) / TransVarTrustRegionRadiusSquared);
                zMatrix.setEntry(TransVarEvaluations - TransVarDimension, TransVarNfx,
                              -zMatrix.getEntry(0, TransVarNfx) - zMatrix.getEntry(TransVarEvaluations, TransVarNfx));
            }
        } else {
            zMatrix.setEntry(0, TransVarNfx, TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarEvaluations, TransVarNfx, TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarIp, TransVarNfx, -TransVarReciprocalRhosq);
            zMatrix.setEntry(TransVarIpt, TransVarNfx, -TransVarReciprocalRhosq);

            final int TransVarIpIndex = TransVarIp * (TransVarIp - 1) / 2 + TransVarIpt - 1;
            final double TransVarTemp = interpolationPoints.getEntry(TransVarEvaluations, TransVarIp - 1) * interpolationPoints.getEntry(TransVarEvaluations, TransVarIpt - 1);
            modelSecondDerivativesValues.setEntry(TransVarIpIndex, (TransVarBeg - fAtInterpolationPoints.getEntry(TransVarIp) - fAtInterpolationPoints.getEntry(TransVarIpt) + TransVarMaximization) / TransVarTemp);
        }
    } while (getEvaluations() < TransVarNumberOfPoints);
}