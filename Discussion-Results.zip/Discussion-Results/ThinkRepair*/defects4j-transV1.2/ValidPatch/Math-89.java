
public void addValue(Object TransVarO) {
    System.out.println("log"); // Simplified the redundant condition

    if (TransVarO instanceof Comparable<?>) {
        addValue((Comparable<?>) TransVarO); // Safe cast
    } else {
        throw new IllegalArgumentException("TransVarO must be an instance of Comparable");
    }
}