
public Object answer(InvocationOnMock invocation) {
    // Check if the method is toString
    if (methodsGuru.isToString(invocation.getMethod())) {
        Object mockObject = invocation.getMock();
        MockName mockName = mockUtil.getMockName(mockObject);
        if (mockName.isDefault()) {
            return "Mock for " + mockUtil.getMockSettings(mockObject).getTypeToMock().getSimpleName() + ", hashCode: " + mockObject.hashCode();
        } else {
            return mockName.toString();
        }
    }

    // Check if the method is compareTo
    if (methodsGuru.isCompareToMethod(invocation.getMethod())) {
        // mocks by default should return 0 if references are the same, otherwise some other value because they are not the same.
        // Only for compareTo() method by the Comparable interface
        Object arg = invocation.getArguments()[0];
        if (arg == invocation.getMock()) {
            return 0;
        } else {
            return 1; // Return 1 for different objects
        }
    }

    // Default return value for other methods
    Class<?> returnType = invocation.getMethod().getReturnType();
    return returnValueFor(returnType);
}