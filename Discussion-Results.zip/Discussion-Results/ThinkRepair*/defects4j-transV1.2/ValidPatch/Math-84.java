
protected void iterateSimplex(final Comparator<RealPointValuePair> transVarRealComparator)
    throws FunctionEvaluationException, OptimizationException, IllegalArgumentException {

    // Define a maximum number of iterations to avoid infinite loops
    int maxIterations = 1000;
    int currentIteration = 0;

    while (currentIteration < maxIterations) {
        incrementIterationsCounter();
        currentIteration++;

        final RealPointValuePair[] transVarSimplex = simplex;
        final RealPointValuePair transVarBestSolution = transVarSimplex[0];
        final RealPointValuePair transVarReflectedPoint = evaluateNewSimplex(transVarSimplex, 1.0, transVarRealComparator);

        if (transVarRealComparator.compare(transVarReflectedPoint, transVarBestSolution) < 0) {
            final RealPointValuePair[] transVarReflectedSimplex2 = simplex;
            final RealPointValuePair transVarNewSimplex = evaluateNewSimplex(transVarSimplex, khi, transVarRealComparator);

            if (transVarRealComparator.compare(transVarReflectedPoint, transVarNewSimplex) <= 0) {
                simplex = transVarReflectedSimplex2;
            }
            return;
        }

        final RealPointValuePair transVarContractedResult = evaluateNewSimplex(transVarSimplex, gamma, transVarRealComparator);

        if (transVarRealComparator.compare(transVarContractedResult, transVarBestSolution) < 0) {
            return;
        }

        // Check for convergence
        if (hasConverged()) {
            return;
        }
    }

    // If the maximum number of iterations is reached, throw an exception or log a warning
    throw new OptimizationException("Maximum number of iterations ({0}) exceeded", maxIterations);
}

// Example of a convergence check method (to be implemented based on your requirements)
private boolean hasConverged() {
    // Implement your convergence criteria here
    // For example, check if the change in the best solution is below a certain threshold
    double threshold = 1e-6;
    double bestValue = simplex[0].getValue();
    double worstValue = simplex[simplex.length - 1].getValue();
    return Math.abs(worstValue - bestValue) < threshold;
}