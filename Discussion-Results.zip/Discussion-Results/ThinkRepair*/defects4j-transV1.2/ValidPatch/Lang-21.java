
public static boolean isSameLocalTime(Calendar TransVarCal, Calendar TransVarCal3) {
    // Check if either calendar is null
    if (TransVarCal == null || TransVarCal3 == null) {
        throw new IllegalArgumentException("The date must not be null");
    }

    // Compare the relevant fields to determine if they represent the same local time
    return (TransVarCal.get(Calendar.MILLISECOND) == TransVarCal3.get(Calendar.MILLISECOND) &&
            TransVarCal.get(Calendar.SECOND) == TransVarCal3.get(Calendar.SECOND) &&
            TransVarCal.get(Calendar.MINUTE) == TransVarCal3.get(Calendar.MINUTE) &&
            TransVarCal.get(Calendar.HOUR_OF_DAY) == TransVarCal3.get(Calendar.HOUR_OF_DAY) &&
            TransVarCal.get(Calendar.DAY_OF_MONTH) == TransVarCal3.get(Calendar.DAY_OF_MONTH) &&
            TransVarCal.get(Calendar.MONTH) == TransVarCal3.get(Calendar.MONTH) &&
            TransVarCal.get(Calendar.YEAR) == TransVarCal3.get(Calendar.YEAR) &&
            TransVarCal.get(Calendar.ERA) == TransVarCal3.get(Calendar.ERA));
}