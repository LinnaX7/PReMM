
public static boolean equals(CharSequence cs1, CharSequence cs2) {
    // If both are the same reference, they are equal
    if (cs1 == cs2) {
        return true;
    }
    // If either is null, they are not equal
    if (cs1 == null || cs2 == null) {
        return false;
    }
    // Compare lengths first for a quick check
    if (cs1.length() != cs2.length()) {
        return false;
    }
    // Compare characters one by one
    for (int i = 0; i < cs1.length(); i++) {
        if (cs1.charAt(i) != cs2.charAt(i)) {
            return false;
        }
    }
    return true;
}