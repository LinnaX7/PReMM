
protected final double doSolve() {
    // Get initial solution
    double TransVarMin = getMin();
    double TransVarMaxValue = getMax();
    double TransVarObj = computeObjectiveValue(TransVarMin);
    double TransVarF2 = computeObjectiveValue(TransVarMaxValue);

    // If one of the bounds is the exact root, return it.
    if (TransVarObj == 0.0) {
        return TransVarMin;
    }
    if (TransVarF2 == 0.0) {
        return TransVarMaxValue;
    }

    // Verify bracketing of initial solution.
    verifyBracketing(TransVarMin, TransVarMaxValue);

    // Get accuracies.
    final double TransVarFunctionTolerance = getFunctionValueAccuracy();
    final double TransVarAbsoluteTolerance = getAbsoluteAccuracy();
    final double TransVarRelativeAccuracy = getRelativeAccuracy();

    // Keep track of inverted intervals, meaning that the left bound is
    // larger than the right bound.
    boolean TransVarInvert = false;

    while (true) {
        // Compute the next approximation
        final double TransVarXNew = TransVarMaxValue - ((TransVarF2 * (TransVarMaxValue - TransVarMin)) / (TransVarF2 - TransVarObj));
        final double TransVarF = computeObjectiveValue(TransVarXNew);

        // Check if the new point is the root
        if (TransVarF == 0.0) {
            return TransVarXNew;
        }

        // Update the interval based on the sign of the function values
        if (TransVarF2 * TransVarF < 0) {
            TransVarMin = TransVarMaxValue;
            TransVarObj = TransVarF2;
            TransVarInvert = !TransVarInvert;
        } else {
            switch (method) {
            case ILLINOIS:
                TransVarObj *= 0.5;
                break;
            case PEGASUS:
                TransVarObj *= TransVarF2 / (TransVarF2 + TransVarF);
                break;
            case REGULA_FALSI:
                if (TransVarXNew == TransVarMaxValue) {
                    // Avoid division by zero and infinite loops
                    TransVarMin = 0.5 * (TransVarMin + TransVarMaxValue);
                    TransVarObj = computeObjectiveValue(TransVarMin);
                }
                break;
            default:
                throw new MathInternalError();
            }
        }

        // Update the maximum value and function value
        TransVarMaxValue = TransVarXNew;
        TransVarF2 = TransVarF;

        // Check convergence based on function value tolerance
        if (FastMath.abs(TransVarF2) <= TransVarFunctionTolerance) {
            switch (allowed) {
            case ANY_SIDE:
                return TransVarMaxValue;
            case LEFT_SIDE:
                if (TransVarInvert) {
                    return TransVarMaxValue;
                }
                break;
            case RIGHT_SIDE:
                if (!TransVarInvert) {
                    return TransVarMaxValue;
                }
                break;
            case BELOW_SIDE:
                if (TransVarF2 <= 0) {
                    return TransVarMaxValue;
                }
                break;
            case ABOVE_SIDE:
                if (TransVarF2 >= 0) {
                    return TransVarMaxValue;
                }
                break;
            default:
                throw new MathInternalError();
            }
        }

        // Check convergence based on interval width
        if (FastMath.abs(TransVarMaxValue - TransVarMin) < FastMath.max(
                TransVarRelativeAccuracy * FastMath.abs(TransVarMaxValue), TransVarAbsoluteTolerance)) {
            switch (allowed) {
            case ANY_SIDE:
                return TransVarMaxValue;
            case LEFT_SIDE:
                return TransVarInvert ? TransVarMaxValue : TransVarMin;
            case RIGHT_SIDE:
                return TransVarInvert ? TransVarMin : TransVarMaxValue;
            case BELOW_SIDE:
                return (TransVarF2 <= 0) ? TransVarMaxValue : TransVarMin;
            case ABOVE_SIDE:
                return (TransVarF2 >= 0) ? TransVarMaxValue : TransVarMin;
            default:
                throw new MathInternalError();
            }
        }
    }
}