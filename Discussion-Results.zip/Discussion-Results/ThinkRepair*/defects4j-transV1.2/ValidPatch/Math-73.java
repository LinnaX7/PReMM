
public double solve(final UnivariateRealFunction TransVarFunction,
                    final double TransVarMinimum, final double TransVarMaximum, final double TransVarInitialValue)
    throws MaxIterationsExceededException, FunctionEvaluationException {

    clearResult();
    verifySequence(TransVarMinimum, TransVarInitialValue, TransVarMaximum);

    // Evaluate the initial guess
    double TransVarInitial = TransVarFunction.value(TransVarInitialValue);
    if (Math.abs(TransVarInitial) <= functionValueAccuracy) {
        setResult(TransVarInitialValue, 0);
        return result;
    }

    // Evaluate the minimum value
    double TransVarYMinValue = TransVarFunction.value(TransVarMinimum);
    if (Math.abs(TransVarYMinValue) <= functionValueAccuracy) {
        setResult(TransVarMinimum, 0);
        return result;
    }

    // Evaluate the maximum value
    double TransVarMaxOfFunction = TransVarFunction.value(TransVarMaximum);
    if (Math.abs(TransVarMaxOfFunction) <= functionValueAccuracy) {
        setResult(TransVarMaximum, 0);
        return result;
    }

    // Check if the initial guess and minimum value bracket the root
    if (TransVarInitial * TransVarYMinValue < 0) {
        return solve(TransVarFunction, TransVarMinimum, TransVarYMinValue, TransVarInitialValue, TransVarInitial, TransVarMinimum, TransVarYMinValue);
    }

    // Check if the initial guess and maximum value bracket the root
    if (TransVarInitial * TransVarMaxOfFunction < 0) {
        return solve(TransVarFunction, TransVarInitialValue, TransVarInitial, TransVarMaximum, TransVarMaxOfFunction, TransVarInitialValue, TransVarInitial);
    }

    // If none of the above conditions are met, the initial guess does not bracket the root
    // This should be an error condition
    throw new IllegalArgumentException("The initial guess does not bracket the root.");
}