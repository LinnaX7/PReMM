
public static double linearCombination(final double[] TransVarA2, final double[] TransVarC)
    throws DimensionMismatchException {
    final int TransVarB = TransVarA2.length;
    if (TransVarB != TransVarC.length) {
        throw new DimensionMismatchException(TransVarB, TransVarC.length);
    }

    if (TransVarB == 0) {
        return 0; // Handle empty arrays
    }

    final double[] TransVarProdHigh1 = new double[TransVarB];
    double TransVarSumOfTwo = 0;

    for (int TransVarI2 = 0; TransVarI2 < TransVarB; TransVarI2++) {
        final double TransVarAii = TransVarA2[TransVarI2];
        final double TransVarC1 = SPLIT_FACTOR * TransVarAii;
        final double TransVarAHigh1 = TransVarC1 - (TransVarC1 - TransVarAii);
        final double TransVarA = TransVarAii - TransVarAHigh1;
        final double TransVarBi2 = TransVarC[TransVarI2];
        final double TransVarC2 = SPLIT_FACTOR * TransVarBi2;
        final double TransVarB1 = TransVarC2 - (TransVarC2 - TransVarBi2);
        final double TransVarBLow1 = TransVarBi2 - TransVarB1;
        TransVarProdHigh1[TransVarI2] = TransVarAii * TransVarBi2;
        final double TransVarProdLow1 = TransVarA * TransVarBLow1
                - (((TransVarProdHigh1[TransVarI2] - TransVarAHigh1 * TransVarB1) - TransVarA * TransVarB1)
                        - TransVarAHigh1 * TransVarBLow1);
        TransVarSumOfTwo += TransVarProdLow1;
    }

    double TransVarResultOfAddition;
    if (TransVarB == 1) {
        // Special case for single-element arrays
        TransVarResultOfAddition = TransVarProdHigh1[0] + TransVarSumOfTwo;
    } else {
        final double TransVarProdHigh = TransVarProdHigh1[0];
        double TransVarProdHighNext2 = TransVarProdHigh1[1];
        double TransVarSHighCur = TransVarProdHigh + TransVarProdHighNext2;
        double TransVarSPrime_0 = TransVarSHighCur - TransVarProdHighNext2;
        double TransVarSLowSumNext = (TransVarProdHighNext2 - (TransVarSHighCur - TransVarSPrime_0)) + (TransVarProdHigh - TransVarSPrime_0);

        final int TransVarLenMinusOne1 = TransVarB - 1;
        for (int TransVarIi = 1; TransVarIi < TransVarLenMinusOne1; TransVarIi++) {
            TransVarProdHighNext2 = TransVarProdHigh1[TransVarIi + 1];
            final double TransVarSHighCurNext = TransVarSHighCur + TransVarProdHighNext2;
            TransVarSPrime_0 = TransVarSHighCurNext - TransVarProdHighNext2;
            TransVarSLowSumNext += (TransVarProdHighNext2 - (TransVarSHighCurNext - TransVarSPrime_0))
                    + (TransVarSHighCur - TransVarSPrime_0);
            TransVarSHighCur = TransVarSHighCurNext;
        }

        TransVarResultOfAddition = TransVarSHighCur + (TransVarSumOfTwo + TransVarSLowSumNext);
    }

    if (Double.isNaN(TransVarResultOfAddition)) {
        TransVarResultOfAddition = 0;
        for (int TransVarJ = 0; TransVarJ < TransVarB; TransVarJ++) {
            TransVarResultOfAddition += TransVarA2[TransVarJ] * TransVarC[TransVarJ];
        }
    }

    return TransVarResultOfAddition;
}