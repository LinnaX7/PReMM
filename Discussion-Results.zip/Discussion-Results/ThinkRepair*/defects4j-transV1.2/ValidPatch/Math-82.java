
private Integer getPivotRow(final int TransVarColIndex, final SimplexTableau TransVarSimplexTableau) {
    double TransVarMinRatioForSimplex = Double.MAX_VALUE;
    Integer TransVarMinRatioPosSimplex = null;
    int TransVarIndex = TransVarSimplexTableau.getNumObjectiveFunctions();

    while (TransVarIndex < TransVarSimplexTableau.getHeight()) {
        final double TransVarRatio = TransVarSimplexTableau.getEntry(TransVarIndex, TransVarSimplexTableau.getWidth() - 1);
        final double TransVarSimplexEntry = TransVarSimplexTableau.getEntry(TransVarIndex, TransVarColIndex);

        // Ensure the entry is positive (not just non-negative)
        if (MathUtils.compareTo(TransVarSimplexEntry, 0, epsilon) > 0) {
            final double TransVarMinRatio = TransVarRatio / TransVarSimplexEntry;
            if (TransVarMinRatio < TransVarMinRatioForSimplex) {
                TransVarMinRatioForSimplex = TransVarMinRatio;
                TransVarMinRatioPosSimplex = TransVarIndex;
            }
        }
        TransVarIndex++;
    }

    return TransVarMinRatioPosSimplex;
}