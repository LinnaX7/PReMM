
public void integrate(final ExpandableStatefulODE TransVarEquation, final double TransVarTime)
    throws MathIllegalStateException, MathIllegalArgumentException {

    // Perform sanity checks
    sanityChecks(TransVarEquation, TransVarTime);
    setEquations(TransVarEquation);
    final boolean TransVarForwards = TransVarTime > TransVarEquation.getTime();

    // Create some internal working arrays
    final double[] TransVarY1 = TransVarEquation.getCompleteState();
    final double[] TransVarY2 = TransVarY1.clone();
    final int TransVarTotalStages = c.length + 1;
    final double[][] TransVarYDot = new double[TransVarTotalStages][TransVarY2.length];
    final double[] TransVarY_old = TransVarY1.clone();
    final double[] TransVarYDotNew = new double[TransVarY2.length];

    // Set up an interpolator sharing the integrator arrays
    final RungeKuttaStepInterpolator TransVarRk4StepInterpolator = (RungeKuttaStepInterpolator) prototype.copy();
    TransVarRk4StepInterpolator.reinitialize(this, TransVarY_old, TransVarYDot, TransVarForwards,
                                             TransVarEquation.getPrimaryMapper(), TransVarEquation.getSecondaryMappers());
    TransVarRk4StepInterpolator.storeTime(TransVarEquation.getTime());

    // Set up integration control objects
    stepStart = TransVarEquation.getTime();
    double TransVarHnew = 0;
    boolean TransVarFirstStep = true;
    initIntegration(TransVarEquation.getTime(), TransVarY1, TransVarTime);

    // Main integration loop
    isLastStep = false;
    do {
        TransVarRk4StepInterpolator.shift();

        // Iterate over step size, ensuring local normalized error is smaller than 1
        double TransVarError2 = 10;
        while (TransVarError2 >= 1.0) {
            if (TransVarFirstStep || !fsal) {
                computeDerivatives(stepStart, TransVarY2, TransVarYDot[0]);
            }
            if (TransVarFirstStep) {
                final double[] TransVarS = new double[mainSetDimension];
                if (vecAbsoluteTolerance == null) {
                    for (int i = 0; i < TransVarS.length; i++) {
                        TransVarS[i] = scalAbsoluteTolerance + scalRelativeTolerance * FastMath.abs(TransVarY2[i]);
                    }
                } else {
                    for (int i = 0; i < TransVarS.length; i++) {
                        TransVarS[i] = vecAbsoluteTolerance[i] + vecRelativeTolerance[i] * FastMath.abs(TransVarY2[i]);
                    }
                }
                TransVarHnew = initializeStep(TransVarForwards, getOrder(), TransVarS, stepStart, TransVarY2,
                                              TransVarYDot[0], TransVarY_old, TransVarYDot[1]);
                // Ensure the initial step size is within the bounds of the integration interval
                if (TransVarForwards) {
                    TransVarHnew = Math.min(TransVarHnew, TransVarTime - stepStart);
                } else {
                    TransVarHnew = Math.max(TransVarHnew, TransVarTime - stepStart);
                }
                TransVarFirstStep = false;
            }
            stepSize = TransVarHnew;
            for (int k = 1; k < TransVarTotalStages; k++) {
                for (int i = 0; i < TransVarY1.length; i++) {
                    double sum = a[k - 1][0] * TransVarYDot[0][i];
                    for (int n = 1; n < k; n++) {
                        sum += a[k - 1][n] * TransVarYDot[n][i];
                    }
                    TransVarY_old[i] = TransVarY2[i] + stepSize * sum;
                }
                computeDerivatives(stepStart + c[k - 1] * stepSize, TransVarY_old, TransVarYDot[k]);
            }
            for (int j = 0; j < TransVarY1.length; j++) {
                double sum = b[0] * TransVarYDot[0][j];
                for (int k = 1; k < TransVarTotalStages; k++) {
                    sum += b[k] * TransVarYDot[k][j];
                }
                TransVarY_old[j] = TransVarY2[j] + stepSize * sum;
            }
            TransVarError2 = estimateError(TransVarYDot, TransVarY2, TransVarY_old, stepSize);
            if (TransVarError2 >= 1.0) {
                final double factor = FastMath.min(maxGrowth,
                                                   FastMath.max(minReduction, safety * FastMath.pow(TransVarError2, exp)));
                TransVarHnew = filterStep(stepSize * factor, TransVarForwards, false);
                // Ensure the new step size is within the bounds of the integration interval
                if (TransVarForwards) {
                    TransVarHnew = Math.min(TransVarHnew, TransVarTime - stepStart);
                } else {
                    TransVarHnew = Math.max(TransVarHnew, TransVarTime - stepStart);
                }
            }
        }

        // Local error is small enough: accept the step, trigger events and step handlers
        TransVarRk4StepInterpolator.storeTime(stepStart + stepSize);
        System.arraycopy(TransVarY_old, 0, TransVarY2, 0, TransVarY1.length);
        System.arraycopy(TransVarYDot[TransVarTotalStages - 1], 0, TransVarYDotNew, 0, TransVarY1.length);
        stepStart = acceptStep(TransVarRk4StepInterpolator, TransVarY2, TransVarYDotNew, TransVarTime);
        System.arraycopy(TransVarY2, 0, TransVarY_old, 0, TransVarY2.length);

        // Check if this is the last step
        if (isLastStep) {
            break;
        }

        // Prepare next step
        TransVarRk4StepInterpolator.storeTime(stepStart);

        if (fsal) {
            // Save the last evaluation for the next step
            System.arraycopy(TransVarYDotNew, 0, TransVarYDot[0], 0, TransVarY1.length);
        }

        // Step size control for next step
        final double factor = FastMath.min(maxGrowth,
                                           FastMath.max(minReduction, safety * FastMath.pow(TransVarError2, exp)));
        final double scaledHNew = stepSize * factor;
        final double nextTime = stepStart + scaledHNew;
        final boolean nextTimeIsValid = TransVarForwards ? (nextTime >= TransVarTime) : (nextTime <= TransVarTime);
        TransVarHnew = filterStep(scaledHNew, TransVarForwards, nextTimeIsValid);

        final double nextFilteredTime = stepStart + TransVarHnew;
        final boolean filteredNextIsLastForward = TransVarForwards ? (nextFilteredTime >= TransVarTime) : (nextFilteredTime <= TransVarTime);
        if (filteredNextIsLastForward) {
            TransVarHnew = TransVarTime - stepStart;
        }
    } while (!isLastStep);

    // Dispatch results
    TransVarEquation.setTime(stepStart);
    TransVarEquation.setCompleteState(TransVarY2);

    resetInternalState();
}