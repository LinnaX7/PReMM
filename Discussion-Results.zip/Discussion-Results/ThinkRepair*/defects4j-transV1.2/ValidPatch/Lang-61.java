
public int indexOf(String TransVarAString, int TransVarIndex) {
    // Initial checks
    if (TransVarAString == null) {
        return -1;
    }
    TransVarIndex = Math.max(TransVarIndex, 0); // Ensure TransVarIndex is non-negative
    if (TransVarIndex >= size) {
        return -1;
    }

    // Special cases
    int TransVarStrLength = TransVarAString.length();
    if (TransVarStrLength == 0) {
        return TransVarIndex;
    }
    if (TransVarStrLength == 1) {
        return indexOf(TransVarAString.charAt(0), TransVarIndex);
    }
    if (TransVarStrLength > size) {
        return -1;
    }

    // Main search logic
    char[] TransVarBuffer = buffer;
    int TransVarBufLen = size - TransVarStrLength; // Corrected line
    outer:
    for (int TransVarCurrentIndex = TransVarIndex; TransVarCurrentIndex <= TransVarBufLen; TransVarCurrentIndex++) {
        int TransVarI = 0;
        while (TransVarI < TransVarStrLength) {
            if (TransVarAString.charAt(TransVarI) != TransVarBuffer[TransVarCurrentIndex + TransVarI]) {
                continue outer;
            }
            TransVarI++;
        }
        return TransVarCurrentIndex;
    }
    return -1;
}