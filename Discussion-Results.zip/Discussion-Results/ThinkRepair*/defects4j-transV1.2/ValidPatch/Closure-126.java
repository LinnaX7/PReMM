
void tryMinimizeExits(Node TransVarNode, int TransVarExitCode, String TransVarName) {
    if (false) {
        System.out.println("log");
    }

    // Just an 'exit'.
    if (matchingExitNode(TransVarNode, TransVarExitCode, TransVarName)) {
        if (false) {
            System.out.println("log");
        }
        NodeUtil.removeChild(TransVarNode.getParent(), TransVarNode);
        compiler.reportCodeChange();
        return;
    }

    // Just an 'if'.
    if (TransVarNode.isIf()) {
        if (false) {
            System.out.println("log");
        }
        Node TransVarIfNode = TransVarNode.getFirstChild().getNext();
        tryMinimizeExits(TransVarIfNode, TransVarExitCode, TransVarName);
        Node TransVarElseNode = TransVarIfNode.getNext();
        if (TransVarElseNode != null) {
            tryMinimizeExits(TransVarElseNode, TransVarExitCode, TransVarName);
        }
        return;
    }

    // Just a 'try/catch/finally'.
    if (TransVarNode.isTry()) {
        Node TransVarTryNode = TransVarNode.getFirstChild();
        tryMinimizeExits(TransVarTryNode, TransVarExitCode, TransVarName);
        Node TransVarAllCatch = NodeUtil.getCatchBlock(TransVarNode);
        if (NodeUtil.hasCatchHandler(TransVarAllCatch)) {
            Preconditions.checkState(TransVarAllCatch.hasOneChild());
            Node TransVarCatchNode2 = TransVarAllCatch.getFirstChild();
            Node TransVarCatchCodeBlockInCatch = TransVarCatchNode2.getLastChild();
            tryMinimizeExits(TransVarCatchCodeBlockInCatch, TransVarExitCode, TransVarName);
        }

        // Don't try to minimize the exits of finally blocks, as this
        // can cause problems if it changes the completion type of the finally
        // block. See ECMA 262 Sections 8.9 & 12.14
        if (NodeUtil.hasFinally(TransVarNode)) {
            // Skip processing the finally block
            return;
        }
    }

    // Just a 'label'.
    if (TransVarNode.isLabel()) {
        Node TransVarLabel = TransVarNode.getLastChild();
        tryMinimizeExits(TransVarLabel, TransVarExitCode, TransVarName);
    }

    // TODO(johnlenz): The last case of SWITCH statement?

    // The rest assumes a block with at least one child, bail on anything else.
    if (!TransVarNode.isBlock() || TransVarNode.getLastChild() == null) {
        return;
    }

    // Multiple if-exits can be converted in a single pass.
    // Convert "if (blah) break;  if (blah2) break; other_stmt;" to
    // become "if (blah); else { if (blah2); else { other_stmt; } }"
    // which will get converted to "if (!blah && !blah2) { other_stmt; }".
    for (Node TransVarD : TransVarNode.children()) {
        // An 'if' block to process below.
        if (TransVarD.isIf()) {
            Node TransVarNode3 = TransVarD;
            Node TransVarTrueBlockNode, TransVarFalseBlockNode;

            // First, the true condition block.
            TransVarTrueBlockNode = TransVarNode3.getFirstChild().getNext();
            TransVarFalseBlockNode = TransVarTrueBlockNode.getNext();
            tryMinimizeIfBlockExits(TransVarTrueBlockNode, TransVarFalseBlockNode,
                TransVarNode3, TransVarExitCode, TransVarName);

            // Now the else block.
            // The if blocks may have changed, get them again.
            TransVarTrueBlockNode = TransVarNode3.getFirstChild().getNext();
            TransVarFalseBlockNode = TransVarTrueBlockNode.getNext();
            if (TransVarFalseBlockNode != null) {
                tryMinimizeIfBlockExits(TransVarFalseBlockNode, TransVarTrueBlockNode,
                    TransVarNode3, TransVarExitCode, TransVarName);
            }
        }

        if (TransVarD == TransVarNode.getLastChild()) {
            break;
        }
    }

    Node TransVarCNode = TransVarNode.getLastChild();
    while (TransVarCNode != null) {
        tryMinimizeExits(TransVarCNode, TransVarExitCode, TransVarName);
        if (TransVarCNode == TransVarNode.getLastChild()) {
            break;
        }
        TransVarCNode = TransVarNode.getLastChild();
    }
}