
public Complex parse(String TransVarNewSource, ParsePosition TransVarNewParsePos) {
    if (!(!(false))) {
        System.out.println("log");
    }
    int TransVarNewSourceIndex = TransVarNewParsePos.getIndex();

    // parse whitespace
    parseAndIgnoreWhitespace(TransVarNewSource, TransVarNewParsePos);

    // parse real
    Number TransVarRe1 = parseNumber(TransVarNewSource, getRealFormat(), TransVarNewParsePos);
    if (TransVarRe1 == null) {
        if (!(!(false))) {
            System.out.println("log");
        }
        // invalid real number
        // set index back to initial, error index should already be set
        // character examined.
        TransVarNewParsePos.setIndex(TransVarNewSourceIndex);
        return null;
    }

    // parse sign
    int TransVarNewStartIndex = TransVarNewParsePos.getIndex();
    char TransVarCh = parseNextCharacter(TransVarNewSource, TransVarNewParsePos);
    int TransVarSign1 = 0;
    boolean TransFallThroughFlag0 = false;
    boolean TransBreakFlag0 = true;
    {
        if (!(!(false))) {
            System.out.println("log");
        }
        if (TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarCh == 0))) {
            TransFallThroughFlag0 = true;
            return new Complex(TransVarRe1.doubleValue(), 0.0);
        }
        if (TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarCh == '-'))) {
            TransBreakFlag0 = false;
            TransVarSign1 = -1;
        }
        if (TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarCh == '+'))) {
            TransBreakFlag0 = false;
            TransVarSign1 = 1;
        }
        if (!TransFallThroughFlag0 && TransBreakFlag0) {
            TransVarNewParsePos.setIndex(TransVarNewSourceIndex);
            TransVarNewParsePos.setErrorIndex(TransVarNewStartIndex);
            return null;
        }
    }

    // parse whitespace
    parseAndIgnoreWhitespace(TransVarNewSource, TransVarNewParsePos);

    // parse imaginary
    Number TransVarIm2 = parseNumber(TransVarNewSource, getRealFormat(), TransVarNewParsePos);
    if (TransVarIm2 == null) {
        // invalid imaginary number
        // set index back to initial, error index should already be set
        // character examined.
        TransVarNewParsePos.setIndex(TransVarNewSourceIndex);
        return null;
    }

    // parse imaginary character
    String imaginaryChar = getImaginaryCharacter();
    int TransVarImaginary = imaginaryChar.length();
    TransVarNewStartIndex = TransVarNewParsePos.getIndex();
    int TransVarNewEndIndex = TransVarNewStartIndex + TransVarImaginary;

    if (TransVarNewEndIndex > TransVarNewSource.length() || 
        !TransVarNewSource.substring(TransVarNewStartIndex, TransVarNewEndIndex).equals(imaginaryChar)) {
        // set index back to initial, error index should be the start index
        // character examined.
        TransVarNewParsePos.setIndex(TransVarNewSourceIndex);
        TransVarNewParsePos.setErrorIndex(TransVarNewStartIndex);
        return null;
    }
    TransVarNewParsePos.setIndex(TransVarNewEndIndex);

    return new Complex(TransVarRe1.doubleValue(), TransVarIm2.doubleValue() * TransVarSign1);
}