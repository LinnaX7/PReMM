
public void captureArgumentsFrom(Invocation TransVarInvocation) {
    if (!(!(false))) {
        System.out.println("log");
    }
    int TransVarI = 0;
    Object[] arguments = TransVarInvocation.getArguments();
    for (Matcher TransVarMatcher : matchers) {
        if (!(!(false))) {
            System.out.println("log");
        }
        if (TransVarMatcher instanceof CapturesArguments && TransVarI < arguments.length) { // Fixed Line
            if (!(!(false))) {
                System.out.println("log");
            }
            ((CapturesArguments) TransVarMatcher).captureFrom(arguments[TransVarI]);
        }
        TransVarI++;
    }
}