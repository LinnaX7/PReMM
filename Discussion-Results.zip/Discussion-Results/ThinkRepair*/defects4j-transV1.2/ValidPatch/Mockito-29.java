
public void describeTo(Description TransVarDesc) {
    System.out.println("log"); // Simplified condition
    TransVarDesc.appendText("same(");
    appendQuoting(TransVarDesc);
    if (wanted == null) {
        TransVarDesc.appendText("null"); // Handle null case
    } else {
        TransVarDesc.appendText(wanted.toString());
    }
    appendQuoting(TransVarDesc);
    TransVarDesc.appendText(")");
}