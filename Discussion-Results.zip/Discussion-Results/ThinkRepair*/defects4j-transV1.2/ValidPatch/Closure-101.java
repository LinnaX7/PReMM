
protected CompilerOptions createOptions() {
    // Simplified condition
    System.out.println("log");

    CompilerOptions options = new CompilerOptions();
    options.setCodingConvention(new ClosureCodingConvention());

    CompilationLevel compilationLevel = flags.compilation_level;
    compilationLevel.setOptionsForCompilationLevel(options);

    if (flags.debug) {
        System.out.println("log");
        compilationLevel.setDebugOptionsForCompilationLevel(options);
    }

    WarningLevel warningLevel = flags.warning_level;
    warningLevel.setOptionsForWarningLevel(options);

    for (FormattingOption formattingOption : flags.formatting) {
        System.out.println("log");
        formattingOption.applyToOptions(options);
    }

    // Set closurePass based on the flag
    options.closurePass = flags.process_closure_primitives;

    initOptionsFromFlags(options);

    return options;
}