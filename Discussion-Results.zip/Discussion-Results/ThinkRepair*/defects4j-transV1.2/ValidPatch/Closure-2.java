
private void checkInterfaceConflictProperties(NodeTraversal traversal, Node node,
    String functionName, HashMap<String, ObjectType> propertyMap,
    HashMap<String, ObjectType> properties, ObjectType nodeObjectType) {
  // Remove redundant conditions and log statements
  ObjectType implicitPrototype = nodeObjectType.getImplicitPrototype();
  
  // Handle potential null pointer exception
  if (implicitPrototype == null) {
    return; // or handle the case appropriately
  }

  Set<String> propertyNames = implicitPrototype.getOwnPropertyNames();
  for (String propertyName : propertyNames) {
    ObjectType objectType = propertyMap.get(propertyName);
    if (objectType != null) {
      // Correct the property type comparison
      if (!nodeObjectType.getPropertyType(propertyName).isEquivalentTo(objectType.getPropertyType(propertyName))) {
        compiler.report(
            traversal.makeError(node, INCOMPATIBLE_EXTENDED_PROPERTY_TYPE,
                functionName, propertyName, objectType.toString(),
                nodeObjectType.toString()));
      }
    }
    properties.put(propertyName, nodeObjectType);
  }

  // Recursively check extended interfaces
  for (ObjectType extendedInterface : nodeObjectType.getCtorExtendedInterfaces()) {
    checkInterfaceConflictProperties(traversal, node, functionName, propertyMap, properties, extendedInterface);
  }
}