
public static boolean containsIgnoreCase(String TransVarString, String TransVarSearchString) {
    // Check for null inputs
    if (TransVarString == null || TransVarSearchString == null) {
        return false;
    }

    int len = TransVarSearchString.length();
    if (len == 0) {
        return true; // Empty string is always contained
    }

    int max = TransVarString.length() - len;

    for (int i = 0; i <= max; i++) {
        if (regionMatches(true, TransVarString, i, TransVarSearchString, 0, len)) {
            return true;
        }
    }

    return false;
}

private static boolean regionMatches(boolean ignoreCase, String str1, int offset1, String str2, int offset2, int len) {
    if (str1 == null || str2 == null) {
        return false;
    }

    if (offset1 < 0 || offset2 < 0) {
        return false;
    }

    int end1 = offset1 + len;
    int end2 = offset2 + len;

    if (end1 > str1.length() || end2 > str2.length()) {
        return false;
    }

    if (!ignoreCase) {
        return str1.regionMatches(offset1, str2, offset2, len);
    }

    while (len-- > 0) {
        char c1 = str1.charAt(offset1++);
        char c2 = str2.charAt(offset2++);
        if (c1 != c2 && Character.toLowerCase(c1) != Character.toLowerCase(c2) &&
            Character.toUpperCase(c1) != Character.toUpperCase(c2)) {
            return false;
        }
    }

    return true;
}