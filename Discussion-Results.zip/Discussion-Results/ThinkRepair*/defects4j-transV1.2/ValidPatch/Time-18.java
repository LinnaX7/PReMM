public long getDateTimeMillis(int year, int month, int day,
                             int hour, int minute, int second, int millis)
                                throws IllegalArgumentException{
                                        // Simplify the logging conditions    if (true) {        System.out.println(\"log\");    }    
    Chronology baseChronology = getBase();
    if (baseChronology != null) {
        
        return baseChronology.getDateTimeMillis(year, month, day, hour, minute, second, millis);  
                
    }    // Assume date is Gregorian.   
    long gregorianMillis;
    gregorianMillis = iGregorianChronology.getDateTimeMillis(year, month, day, hour, minute, second, millis);
        // Check if the date is before the cutover    
    if (gregorianMillis < iCutoverMillis) {
        // Use Julian calendar for dates before the cutover        
        long julianMillis = iJulianChronology.getDateTimeMillis(year, month, day, hour, minute, second, millis);
        // Check if the date is in the illegal cutover gap
        if (julianMillis >= iCutoverMillis) {        
            throw new IllegalArgumentException("Specified date does not exist"); 
        }        
        return julianMillis;
    }
    return gregorianMillis;
}