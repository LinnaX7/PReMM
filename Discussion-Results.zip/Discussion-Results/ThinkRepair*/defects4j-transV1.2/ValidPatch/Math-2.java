
public double getNumericalMean() {
    // Calculate the mean of the hypergeometric distribution
    double mean = (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
    return mean;
}