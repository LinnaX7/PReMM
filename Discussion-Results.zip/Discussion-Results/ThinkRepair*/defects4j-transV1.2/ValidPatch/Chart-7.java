
private void updateBounds(TimePeriod transVarTimePeriod, int transVarTimeIndex) {
    long transVarStartTime = transVarTimePeriod.getStart().getTime();
    long transVarEndTime = transVarTimePeriod.getEnd().getTime();
    long transVarMiddleTime = transVarStartTime + ((transVarEndTime - transVarStartTime) / 2);

    // Update minStartIndex
    if (this.minStartIndex >= 0) {
        long transVarMinStartTime = getDataItem(this.minStartIndex).getPeriod().getStart().getTime();
        if (transVarStartTime < transVarMinStartTime) {
            this.minStartIndex = transVarTimeIndex;
        }
    } else {
        this.minStartIndex = transVarTimeIndex;
    }

    // Update maxStartIndex
    if (this.maxStartIndex >= 0) {
        long transVarStart = getDataItem(this.maxStartIndex).getPeriod().getStart().getTime();
        if (transVarStartTime > transVarStart) {
            this.maxStartIndex = transVarTimeIndex;
        }
    } else {
        this.maxStartIndex = transVarTimeIndex;
    }

    // Update minMiddleIndex
    if (this.minMiddleIndex >= 0) {
        long transVarSt = getDataItem(this.minMiddleIndex).getPeriod().getStart().getTime();
        long transVarEnd = getDataItem(this.minMiddleIndex).getPeriod().getEnd().getTime();
        long transVarMid = transVarSt + (transVarEnd - transVarSt) / 2;
        if (transVarMiddleTime < transVarMid) {
            this.minMiddleIndex = transVarTimeIndex;
        }
    } else {
        this.minMiddleIndex = transVarTimeIndex;
    }

    // Update maxMiddleIndex
    if (this.maxMiddleIndex >= 0) {
        long transVarMaxMiddleStart = getDataItem(this.maxMiddleIndex).getPeriod().getStart().getTime();
        long transVarMaxMiddleEnd = getDataItem(this.maxMiddleIndex).getPeriod().getEnd().getTime();
        long transVarMaxMiddle = transVarMaxMiddleStart + (transVarMaxMiddleEnd - transVarMaxMiddleStart) / 2;
        if (transVarMiddleTime > transVarMaxMiddle) {
            this.maxMiddleIndex = transVarTimeIndex;
        }
    } else {
        this.maxMiddleIndex = transVarTimeIndex;
    }

    // Update minEndIndex
    if (this.minEndIndex >= 0) {
        long transVarMinMiddleEnd = getDataItem(this.minEndIndex).getPeriod().getEnd().getTime();
        if (transVarEndTime < transVarMinMiddleEnd) {
            this.minEndIndex = transVarTimeIndex;
        }
    } else {
        this.minEndIndex = transVarTimeIndex;
    }

    // Update maxEndIndex
    if (this.maxEndIndex >= 0) {
        long transVarMaxEndTime = getDataItem(this.maxEndIndex).getPeriod().getEnd().getTime();
        if (transVarEndTime > transVarMaxEndTime) {
            this.maxEndIndex = transVarTimeIndex;
        }
    } else {
        this.maxEndIndex = transVarTimeIndex;
    }
}