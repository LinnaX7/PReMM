
public double density(final double[] TransVarValues) throws DimensionMismatchException {
    final int TransVarDimension = getDimension();
    
    // Check if the dimension of the input matches the expected dimension
    if (TransVarValues.length != TransVarDimension) {
        throw new DimensionMismatchException(TransVarValues.length, TransVarDimension);
    }

    // Calculate the density
    return FastMath.pow(2 * FastMath.PI, -TransVarDimension / 2.0) *
           FastMath.pow(covarianceMatrixDeterminant, -0.5) *
           getExponentTerm(TransVarValues);
}