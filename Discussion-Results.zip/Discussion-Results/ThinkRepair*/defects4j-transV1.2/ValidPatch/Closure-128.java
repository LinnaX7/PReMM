
static boolean isSimpleNumber(String TransVarS1) {
    int TransVarLengthOfString = TransVarS1.length();
    int TransVarIndex2 = 0;

    // Simplify the loop condition
    while (TransVarIndex2 < TransVarLengthOfString) {
        char TransVarC2 = TransVarS1.charAt(TransVarIndex2);
        // Check if the character is not a digit
        if (TransVarC2 < '0' || TransVarC2 > '9') {
            return false;
        }
        TransVarIndex2++;
    }

    // Ensure the string is not empty and does not start with a leading zero unless it is '0'
    return TransVarLengthOfString > 0 && (TransVarLengthOfString == 1 || TransVarS1.charAt(0) != '0');
}