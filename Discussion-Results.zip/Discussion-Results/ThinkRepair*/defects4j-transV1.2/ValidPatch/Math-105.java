
public double getSumSquaredErrors() {
    // Check for NaN values in the input
    if (Double.isNaN(sumYY) || Double.isNaN(sumXY) || Double.isNaN(sumXX)) {
        return Double.NaN;
    }

    // Ensure sumXX is not zero to avoid division by zero
    if (sumXX == 0) {
        return Double.NaN; // Return NaN if sumXX is zero
    }

    // Calculate the sum of squared errors
    double sse = sumYY - (sumXY * sumXY) / sumXX;

    // Ensure the result is non-negative
    if (Double.isNaN(sse) || sse < 0) {
        // Handle numerical instability by setting a very small positive value or NaN
        sse = 0;
    }

    return sse;
}