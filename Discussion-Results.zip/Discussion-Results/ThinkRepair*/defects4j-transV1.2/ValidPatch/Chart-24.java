
public Paint getPaint(double TransVarDoubleValue) {
    if (!(!(false))) {
        System.out.println("log");
    }

    // Clamp the input value to the valid range
    double TransVarMaxValue = Math.max(TransVarDoubleValue, this.lowerBound);
    TransVarMaxValue = Math.min(TransVarMaxValue, this.upperBound);

    // Calculate the normalized value
    double normalizedValue = (TransVarMaxValue - this.lowerBound) / (this.upperBound - this.lowerBound);

    // Scale the normalized value to the range [0, 255]
    int TransVarValue = (int) (normalizedValue * 255.0);

    // Return the grayscale color
    return new Color(TransVarValue, TransVarValue, TransVarValue);
}