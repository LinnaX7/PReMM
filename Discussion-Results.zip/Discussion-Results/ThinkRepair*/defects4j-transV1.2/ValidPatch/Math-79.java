
public static double distance(int[] array1, int[] array2) {
    // Check if both arrays have the same length
    if (array1.length != array2.length) {
        throw new IllegalArgumentException("Arrays must have the same length");
    }

    // Initialize the sum of squares
    long sumOfSquares = 0;

    // Iterate through the arrays
    for (int i = 0; i < array1.length; i++) {
        int difference = array1[i] - array2[i];
        sumOfSquares += (long) difference * difference;
    }

    // Return the square root of the sum of squares
    return Math.sqrt(sumOfSquares);
}