
private double calculateAsymptoticPValue(final double TransVarUmin,
                                         final int TransVarNum,
                                         final int TransVarMin)
    throws ConvergenceException, MaxCountExceededException {

    // Ensure numerical stability by using double for all intermediate calculations
    final long TransVarN1n2prod = (long) TransVarNum * TransVarMin;

    // Calculate the expected value
    final double TransVarEu = TransVarN1n2prod / 2.0;

    // Calculate the variance
    final double TransVarVarU = TransVarN1n2prod * (TransVarNum + TransVarMin + 1) / 12.0;

    // Calculate the Z-score
    final double TransVarZ2 = (TransVarUmin - TransVarEu) / FastMath.sqrt(TransVarVarU);

    // Use the standard normal distribution to calculate the p-value
    final NormalDistribution TransVarStdNormal = new NormalDistribution(0, 1);

    return 2 * TransVarStdNormal.cumulativeProbability(TransVarZ2);
}