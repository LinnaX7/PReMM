
public static boolean containsAny(CharSequence TransVarSequence, char[] TransVarCharSequence) {
    if (isEmpty(TransVarSequence) || ArrayUtils.isEmpty(TransVarCharSequence)) {
        return false;
    }

    int TransVarCharSequenceLength = TransVarSequence.length();
    int TransVarSearchLengthOfSearchChars = TransVarCharSequence.length;

    for (int TransVarJ = 0; TransVarJ < TransVarCharSequenceLength; ) {
        char TransVarCharSeq = TransVarSequence.charAt(TransVarJ);
        if (Character.isHighSurrogate(TransVarCharSeq) && TransVarJ + 1 < TransVarCharSequenceLength) {
            // Handle surrogate pair
            char lowSurrogate = TransVarSequence.charAt(TransVarJ + 1);
            for (int TransVarJ1 = 0; TransVarJ1 < TransVarSearchLengthOfSearchChars; TransVarJ1++) {
                if (TransVarCharSequence[TransVarJ1] == TransVarCharSeq && TransVarJ1 + 1 < TransVarSearchLengthOfSearchChars && TransVarCharSequence[TransVarJ1 + 1] == lowSurrogate) {
                    return true;
                }
            }
            TransVarJ += 2; // Move past the surrogate pair
        } else {
            for (int TransVarJ1 = 0; TransVarJ1 < TransVarSearchLengthOfSearchChars; TransVarJ1++) {
                if (TransVarCharSequence[TransVarJ1] == TransVarCharSeq) {
                    return true;
                }
            }
            TransVarJ++; // Move to the next character
        }
    }
    return false;
}