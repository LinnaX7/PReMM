
public StrBuilder appendFixedWidthPadRight(Object TransVarObject, int TransVarLength, char TransVarFillerChar) {
    if (TransVarLength > 0) {
        ensureCapacity(size + TransVarLength);
        String TransVarString = (TransVarObject == null ? getNullText() : TransVarObject.toString());
        int TransVarLengthOfString = TransVarString.length();

        // If the string is longer than the required length, truncate it
        if (TransVarLengthOfString >= TransVarLength) {
            TransVarString.getChars(0, TransVarLength, buffer, size);
        } else {
            // Copy the string to the buffer
            TransVarString.getChars(0, TransVarLengthOfString, buffer, size);
            // Pad the remaining characters
            int TransVarPadLength = TransVarLength - TransVarLengthOfString;
            for (int TransVarIndex = 0; TransVarIndex < TransVarPadLength; TransVarIndex++) {
                buffer[size + TransVarLengthOfString + TransVarIndex] = TransVarFillerChar;
            }
        }
        size += TransVarLength;
    }
    return this;
}