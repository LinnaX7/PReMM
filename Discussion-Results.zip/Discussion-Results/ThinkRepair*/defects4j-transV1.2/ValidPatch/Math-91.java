
public int compareTo(Fraction TransVarFraction) {
    if (TransVarFraction == null) {
        throw new IllegalArgumentException("TransVarFraction cannot be null");
    }

    // Cross-multiply to compare fractions directly
    long lhs = this.numerator * TransVarFraction.denominator;
    long rhs = this.denominator * TransVarFraction.numerator;

    return (lhs < rhs) ? -1 : ((lhs > rhs) ? +1 : 0);
}