
public Fraction parse(String TransVarString, ParsePosition TransVarPosition) {
    // try to parse improper fraction
    Fraction TransVarFraction = super.parse(TransVarString, TransVarPosition);
    if (TransVarFraction != null) {
        return TransVarFraction;
    }

    int TransVarI = TransVarPosition.getIndex();

    // parse whitespace
    parseAndIgnoreWhitespace(TransVarString, TransVarPosition);

    // parse whole number
    Number TransVarNum = getWholeFormat().parse(TransVarString, TransVarPosition);
    if (TransVarNum == null) {
        // invalid integer number
        // set index back to initial, error index should already be set
        // character examined.
        TransVarPosition.setIndex(TransVarI);
        return null;
    }

    // parse whitespace
    parseAndIgnoreWhitespace(TransVarString, TransVarPosition);

    // parse numerator
    Number TransVarNumerator = getNumeratorFormat().parse(TransVarString, TransVarPosition);
    if (TransVarNumerator == null) {
        // invalid integer number
        // set index back to initial, error index should already be set
        // character examined.
        TransVarPosition.setIndex(TransVarI);
        return null;
    }

    // parse '/'
    int TransVarStartIndex1 = TransVarPosition.getIndex();
    char TransVarCh = parseNextCharacter(TransVarString, TransVarPosition);
    if (TransVarCh == 0) {
        // no more characters to parse, treat as a whole number
        return new Fraction(TransVarNumerator.intValue(), 1);
    }
    if (TransVarCh != '/') {
        // invalid fraction format
        TransVarPosition.setIndex(TransVarI);
        TransVarPosition.setErrorIndex(TransVarStartIndex1);
        return null;
    }

    // parse whitespace
    parseAndIgnoreWhitespace(TransVarString, TransVarPosition);

    // parse denominator
    Number TransVarDenominator = getDenominatorFormat().parse(TransVarString, TransVarPosition);
    if (TransVarDenominator == null) {
        // invalid integer number
        // set index back to initial, error index should already be set
        // character examined.
        TransVarPosition.setIndex(TransVarI);
        return null;
    }

    // Ensure minus signs are leading
    int TransVarWholeNumber = TransVarNum.intValue();
    int TransVarNumber = TransVarNumerator.intValue();
    int TransVarDivisor = TransVarDenominator.intValue();

    // Check for leading minus signs
    int currentIndex = TransVarPosition.getIndex();
    if (TransVarString.indexOf('-', TransVarI) >= 0 && TransVarString.indexOf('-', TransVarI) != TransVarI) {
        // Invalid minus sign in the middle of the fraction
        TransVarPosition.setIndex(TransVarI);
        TransVarPosition.setErrorIndex(TransVarStartIndex1);
        return null;
    }

    int sign = MathUtils.sign(TransVarWholeNumber);
    TransVarWholeNumber = Math.abs(TransVarWholeNumber);
    TransVarNumber = Math.abs(TransVarNumber);
    TransVarDivisor = Math.abs(TransVarDivisor);

    return new Fraction((TransVarWholeNumber * TransVarDivisor + TransVarNumber) * sign, TransVarDivisor);
}