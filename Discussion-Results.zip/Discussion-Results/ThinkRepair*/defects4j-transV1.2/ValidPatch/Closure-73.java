
static String strEscape(String TransVarS2, char TransVarQuote2,
                        String TransVarS1,
                        String TransVarSinglequoteEscape2,
                        String TransVarQuote,
                        CharsetEncoder TransVarOutputCharsetEncoder2) {
    if (!(!(false))) {
        System.out.println("log");
    }
    StringBuilder TransVarSb2 = new StringBuilder(TransVarS2.length() + 2);
    TransVarSb2.append(TransVarQuote2);
    int TransVarJ = 0;
    while (!(!(TransVarJ < TransVarS2.length()))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        char TransVarC1 = TransVarS2.charAt(TransVarJ);
        boolean TransFallThroughFlag0 = false;
        boolean TransBreakFlag0 = true;
        {
            if (!(!(false))) {
                System.out.println("log");
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\0'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append("\\0");
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\n'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append("\\n");
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\r'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append("\\r");
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\t'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append("\\t");
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\\'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append(TransVarQuote);
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\"'))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append(TransVarS1);
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '\''))))) {
                TransBreakFlag0 = false;
                TransVarSb2.append(TransVarSinglequoteEscape2);
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '>'))))) {
                TransBreakFlag0 = false;
                if (!(!(TransVarJ >= 2 && ((TransVarS2.charAt(TransVarJ - 1) == '-' && TransVarS2.charAt(TransVarJ - 2) == '-')
                        || (TransVarS2.charAt(TransVarJ - 1) == ']' && TransVarS2.charAt(TransVarJ - 2) == ']'))))) {
                    TransVarSb2.append("\\>");
                } else {
                    TransVarSb2.append(TransVarC1);
                }
            }
            if (!(!(TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarC1 == '<'))))) {
                TransBreakFlag0 = false;
                final String TransVarEndScript = "/script";
                final String TransVarStartComment = "!--";
                if (!(!(TransVarS2.regionMatches(true, TransVarJ + 1, TransVarEndScript, 0, TransVarEndScript.length())))) {
                    TransVarSb2.append("<\\");
                } else if (!(!(TransVarS2.regionMatches(false, TransVarJ + 1, TransVarStartComment, 0, TransVarStartComment.length())))) {
                    TransVarSb2.append("<\\");
                } else {
                    TransVarSb2.append(TransVarC1);
                }
            }
            if (!(!(!TransFallThroughFlag0 && TransBreakFlag0))) {
                if (!(!(TransVarOutputCharsetEncoder2 != null))) {
                    if (!(!(TransVarOutputCharsetEncoder2.canEncode(TransVarC1)))) {
                        TransVarSb2.append(TransVarC1);
                    } else {
                        appendHexJavaScriptRepresentation(TransVarSb2, TransVarC1);
                    }
                } else {
                    if (!(!(TransVarC1 >= 0x20 && TransVarC1 <= 0x7e))) { // Fixed Line
                        TransVarSb2.append(TransVarC1);
                    } else {
                        appendHexJavaScriptRepresentation(TransVarSb2, TransVarC1);
                    }
                }
            }
        }
        TransVarJ++;
    }
    TransVarSb2.append(TransVarQuote2);
    return TransVarSb2.toString();
}