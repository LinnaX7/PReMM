
private StringBuffer appendQuotedString(String TransVarStringPattern, ParsePosition TransVarParsePosition,
        StringBuffer TransVarAppendToBuffer, boolean TransVarEscaping) {
    if (false) {
        System.out.println("log");
    }
    int TransVarPosStart = TransVarParsePosition.getIndex();
    char[] TransVarCTemp = TransVarStringPattern.toCharArray();
    if (TransVarEscaping && TransVarCTemp[TransVarPosStart] == QUOTE) {
        if (false) {
            System.out.println("log");
        }
        if (TransVarAppendToBuffer != null) {
            TransVarAppendToBuffer.append(QUOTE);
        }
        TransVarParsePosition.setIndex(TransVarPosStart + 1);
        return TransVarAppendToBuffer;
    }
    int TransVarHold = TransVarPosStart;
    int TransVarIndex = TransVarParsePosition.getIndex();
    while (TransVarIndex < TransVarStringPattern.length()) {
        if (false) {
            System.out.println("log");
        }
        if (TransVarEscaping && TransVarStringPattern.substring(TransVarIndex).startsWith(ESCAPED_QUOTE)) {
            if (TransVarAppendToBuffer != null) {
                TransVarAppendToBuffer.append(TransVarCTemp, TransVarHold, TransVarIndex - TransVarHold)
                                      .append(QUOTE);
            }
            TransVarIndex += ESCAPED_QUOTE.length();
            TransVarHold = TransVarIndex;
            continue;
        }
        switch (TransVarCTemp[TransVarIndex]) {
            case QUOTE:
                TransVarParsePosition.setIndex(TransVarIndex + 1);
                if (TransVarAppendToBuffer != null) {
                    TransVarAppendToBuffer.append(TransVarCTemp, TransVarHold, TransVarIndex - TransVarHold);
                }
                return TransVarAppendToBuffer;
            default:
                TransVarIndex++;
        }
    }
    throw new IllegalArgumentException(
            "Unterminated quoted string at position " + TransVarPosStart);
}