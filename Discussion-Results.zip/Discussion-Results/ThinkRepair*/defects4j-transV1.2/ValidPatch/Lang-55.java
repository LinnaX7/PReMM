
public void stop() {
    // Check if the stopwatch is already stopped
    if (this.runningState == STATE_STOPPED) {
        throw new IllegalStateException("Stopwatch is already stopped.");
    }

    // Check if the stopwatch is running or suspended
    if (this.runningState != STATE_RUNNING && this.runningState != STATE_SUSPENDED) {
        throw new IllegalStateException("Stopwatch is not running or suspended.");
    }

    // If the stopwatch is suspended, resume it before stopping
    if (this.runningState == STATE_SUSPENDED) {
        resume();
    }

    // Stop the stopwatch
    this.stopTime = System.currentTimeMillis();
    this.runningState = STATE_STOPPED;

    // Log the action for debugging
    System.out.println("Stopwatch stopped at " + this.stopTime);
}