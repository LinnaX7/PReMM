
public static Class<?>[] toClass(Object[] transVarArray1) {
    // Check if the input array is null
    if (transVarArray1 == null) {
        return null;
    }

    // Check if the input array is empty
    if (transVarArray1.length == 0) {
        return ArrayUtils.EMPTY_CLASS_ARRAY;
    }

    // Create a new array of Class<?> with the same length as transVarArray1
    Class<?>[] transVarArray = new Class<?>[transVarArray1.length];

    // Iterate over each element in transVarArray1
    for (int transVarIndex = 0; transVarIndex < transVarArray1.length; transVarIndex++) {
        Object element = transVarArray1[transVarIndex];
        if (element != null) {
            transVarArray[transVarIndex] = element.getClass();
        } else {
            transVarArray[transVarIndex] = null; // Handle null elements
        }
    }

    // Return the new array
    return transVarArray;
}