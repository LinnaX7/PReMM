
public Complex add(Complex TransVarLhs)
    throws NullArgumentException {
    MathUtils.checkNotNull(TransVarLhs);

    double realPart = real + TransVarLhs.getReal();
    double imaginaryPart = imaginary + TransVarLhs.getImaginary();

    // Handle NaN values according to IEEE 754 standard
    if (Double.isNaN(real) || Double.isNaN(TransVarLhs.getReal())) {
        realPart = Double.NaN;
    }
    if (Double.isNaN(imaginary) || Double.isNaN(TransVarLhs.getImaginary())) {
        imaginaryPart = Double.NaN;
    }

    // Ensure the result is NaN if any part is NaN
    if (Double.isNaN(realPart) || Double.isNaN(imaginaryPart)) {
        return createComplex(Double.NaN, Double.NaN);
    }

    return createComplex(realPart, imaginaryPart);
}