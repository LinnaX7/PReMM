
public double cumulativeProbability(double TransVarValue) throws MathException {
    final double TransVarDeviation = TransVarValue - mean;

    // Handle extreme values without computing the erf function
    if (TransVarValue < (mean - 20 * standardDeviation)) {
        return 0;
    } else if (TransVarValue > (mean + 20 * standardDeviation)) {
        return 1;
    }

    try {
        return 0.5 * (1.0 + Erf.erf(TransVarDeviation / (standardDeviation * FastMath.sqrt(2.0))));
    } catch (MaxIterationsExceededException e) {
        // Log the exception if needed
        System.out.println("MaxIterationsExceededException caught: " + e.getMessage());
        
        // Handle the exception by returning the appropriate extreme value
        if (TransVarValue < mean) {
            return 0;
        } else {
            return 1;
        }
    }
}