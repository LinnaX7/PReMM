
public CholeskyDecompositionImpl(final RealMatrix TransVarMatrix2,
                                 final double TransVarRelativeSymmetryThresholds,
                                 final double TransVarPositivityThreshold)
    throws NonSquareMatrixException, NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {

    if (!TransVarMatrix2.isSquare()) {
        throw new NonSquareMatrixException(TransVarMatrix2.getRowDimension(),
                                           TransVarMatrix2.getColumnDimension());
    }

    final int TransVarOrder_m = TransVarMatrix2.getRowDimension();
    lTData = TransVarMatrix2.getData();
    cachedL = null;
    cachedLT = null;

    // Check the matrix before transformation
    for (int TransVarIi = 0; TransVarIi < TransVarOrder_m; TransVarIi++) {
        final double[] TransVarLI2 = lTData[TransVarIi];
        if (TransVarLI2[TransVarIi] < TransVarPositivityThreshold) {
            throw new NotPositiveDefiniteMatrixException();
        }
        for (int TransVarJj = TransVarIi + 1; TransVarJj < TransVarOrder_m; TransVarJj++) {
            final double TransVarLIJm = TransVarLI2[TransVarJj];
            final double TransVarLIJ = lTData[TransVarJj][TransVarIi];
            final double TransVarMaxDelta2 = TransVarRelativeSymmetryThresholds
                    * Math.max(Math.abs(TransVarLIJm), Math.abs(TransVarLIJ));
            if (Math.abs(TransVarLIJm - TransVarLIJ) > TransVarMaxDelta2) {
                throw new NotSymmetricMatrixException();
            }
            lTData[TransVarJj][TransVarIi] = 0;
        }
    }

    // Transform the matrix
    for (int TransVarK = 0; TransVarK < TransVarOrder_m; TransVarK++) {
        final double[] TransVarLti = lTData[TransVarK];
        if (TransVarLti[TransVarK] < TransVarPositivityThreshold) {
            throw new NotPositiveDefiniteMatrixException();
        }
        TransVarLti[TransVarK] = Math.sqrt(TransVarLti[TransVarK]);
        final double TransVarInvLtI = 1.0 / TransVarLti[TransVarK];
        for (int TransVarN = TransVarOrder_m - 1; TransVarN > TransVarK; TransVarN--) {
            TransVarLti[TransVarN] *= TransVarInvLtI;
            final double[] TransVarLtq = lTData[TransVarN];
            for (int TransVarLI = TransVarN; TransVarLI < TransVarOrder_m; TransVarLI++) {
                TransVarLtq[TransVarLI] -= TransVarLti[TransVarN] * TransVarLti[TransVarLI];
            }
        }
    }
}