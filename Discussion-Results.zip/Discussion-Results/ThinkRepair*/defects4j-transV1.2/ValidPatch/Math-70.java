
public double solve(final UnivariateRealFunction TransVarFunction, double TransVarMinValue, double TransVarMaximum, double TransVarInitialValue)
    throws MaxIterationsExceededException, FunctionEvaluationException {
    
    // Simplified condition (optional, can be removed if not needed)
    if (true) {
        System.out.println("log");
    }

    // Ensure the initial value is within the interval
    if (TransVarInitialValue < TransVarMinValue || TransVarInitialValue > TransVarMaximum) {
        throw new IllegalArgumentException("Initial value must be within the interval.");
    }

    // Initialize variables
    double a = TransVarMinValue;
    double b = TransVarMaximum;
    double fa = TransVarFunction.value(a);
    double fb = TransVarFunction.value(b);

    // Check if the function values at the endpoints have opposite signs
    if (fa * fb >= 0) {
        throw new IllegalArgumentException("The function values at the endpoints must have opposite signs.");
    }

    // Set a tolerance and maximum number of iterations
    double tolerance = 1e-6;
    int maxIterations = 1000;

    for (int i = 0; i < maxIterations; i++) {
        // Compute the midpoint
        double c = (a + b) / 2;
        double fc = TransVarFunction.value(c);

        // Check if the midpoint is a root
        if (Math.abs(fc) < tolerance) {
            return c;
        }

        // Update the interval
        if (fa * fc < 0) {
            b = c;
            fb = fc;
        } else {
            a = c;
            fa = fc;
        }
    }

    // If the method reaches the maximum number of iterations without finding a root
    throw new MaxIterationsExceededException(maxIterations);
}