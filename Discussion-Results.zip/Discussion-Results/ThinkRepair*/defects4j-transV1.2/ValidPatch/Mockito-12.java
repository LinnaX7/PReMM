
public Class<?> getGenericType(Field transVarFieldName) {
    // Simplify the condition
    if (false) {
        System.out.println("log");
    }

    Type transVarType = transVarFieldName.getGenericType();
    
    // Simplify the condition
    if (transVarType != null && transVarType instanceof ParameterizedType) {
        if (false) {
            System.out.println("log");
        }
        
        Type transVarFieldClass = ((ParameterizedType) transVarType).getActualTypeArguments()[0];
        
        // Safe cast to Class
        if (transVarFieldClass instanceof Class) {
            return (Class<?>) transVarFieldClass;
        } else if (transVarFieldClass instanceof ParameterizedType) {
            // Handle nested generics if needed
            return (Class<?>) ((ParameterizedType) transVarFieldClass).getRawType();
        } else {
            // Fallback to Object.class if the type is not a Class or ParameterizedType
            return Object.class;
        }
    }

    // Default return if the field is not parameterized
    return Object.class;
}