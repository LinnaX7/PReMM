
protected void declareNameInScope(FlowScope TransVarFlowScope, Node TransVarParentFlowScope, JSType TransVarTypeNode) {
    boolean TransBreakFlag0 = true;

    if (TransVarParentFlowScope.getType() == Token.NAME) {
        TransBreakFlag0 = false;
        TransVarFlowScope.inferSlotType(TransVarParentFlowScope.getString(), TransVarTypeNode);
    } else if (TransVarParentFlowScope.getType() == Token.GETPROP) {
        TransBreakFlag0 = false;
        String TransVarQName = TransVarParentFlowScope.getQualifiedName();
        Preconditions.checkNotNull(TransVarQName);
        JSType TransVarType = TransVarParentFlowScope.getJSType();
        TransVarType = TransVarType == null ? getNativeType(UNKNOWN_TYPE) : TransVarType;
        TransVarFlowScope.inferQualifiedSlot(TransVarParentFlowScope, TransVarQName, TransVarType, TransVarTypeNode);
    } else if (TransVarParentFlowScope.getType() == Token.THIS) {
        // Handle 'this' keyword
        // Do not infer the type for 'this' in this context
        TransBreakFlag0 = false;
    }

    if (TransBreakFlag0) {
        throw new IllegalArgumentException("Node cannot be refined. \n" + TransVarParentFlowScope.toStringTree());
    }
}