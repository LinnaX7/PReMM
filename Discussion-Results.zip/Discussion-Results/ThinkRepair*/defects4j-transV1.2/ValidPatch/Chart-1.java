
public LegendItemCollection getLegendItems() {
    LegendItemCollection legendItems = new LegendItemCollection();

    if (this.plot == null) {
        return legendItems;
    }

    int plotIndex = this.plot.getIndexOf(this);
    CategoryDataset dataset = this.plot.getDataset(plotIndex);

    if (dataset == null) {
        return legendItems;
    }

    int seriesCount = dataset.getRowCount();

    if (plot.getRowRenderingOrder().equals(SortOrder.ASCENDING)) {
        for (int i = 0; i < seriesCount; i++) {
            if (isSeriesVisibleInLegend(i)) {
                LegendItem legendItem = getLegendItem(plotIndex, i);
                if (legendItem != null) {
                    legendItems.add(legendItem);
                }
            }
        }
    } else {
        for (int i = seriesCount - 1; i >= 0; i--) {
            if (isSeriesVisibleInLegend(i)) {
                LegendItem legendItem = getLegendItem(plotIndex, i);
                if (legendItem != null) {
                    legendItems.add(legendItem);
                }
            }
        }
    }

    return legendItems;
}