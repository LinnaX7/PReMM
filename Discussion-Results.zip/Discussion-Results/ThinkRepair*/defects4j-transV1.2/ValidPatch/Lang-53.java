
private static void modify(Calendar TransVarCalendar, int TransVarCalendarField, boolean TransVarIsRound) {
    if (TransVarCalendar.get(Calendar.YEAR) > 280000000) {
        throw new ArithmeticException("Calendar value too large for accurate calculations");
    }
    
    if (TransVarCalendarField == Calendar.MILLISECOND) {
        return;
    }

    // ----------------- Fix for LANG-59 ---------------------- START ---------------
    // see http://issues.apache.org/jira/browse/LANG-59
    //
    // Manually truncate milliseconds, seconds and minutes, rather than using
    // Calendar methods.

    Date TransVarD = TransVarCalendar.getTime();
    long TransVarDate = TransVarD.getTime();
    boolean TransVarIsDone = false;

    // truncate milliseconds
    int TransVarMillis = TransVarCalendar.get(Calendar.MILLISECOND);
    if (TransVarIsRound) {
        if (TransVarMillis >= 500) {
            TransVarDate += 1000 - TransVarMillis;
        } else {
            TransVarDate -= TransVarMillis;
        }
        if (TransVarCalendarField == Calendar.SECOND) {
            TransVarIsDone = true;
        }
    } else {
        TransVarDate -= TransVarMillis;
        if (TransVarCalendarField == Calendar.SECOND) {
            TransVarIsDone = true;
        }
    }

    // truncate seconds
    int TransVarSecond = TransVarCalendar.get(Calendar.SECOND);
    if (!TransVarIsDone && TransVarIsRound) {
        if (TransVarSecond >= 30) {
            TransVarDate += 60000 - (TransVarSecond * 1000L);
        } else {
            TransVarDate -= TransVarSecond * 1000L;
        }
        if (TransVarCalendarField == Calendar.MINUTE) {
            TransVarIsDone = true;
        }
    } else if (!TransVarIsDone) {
        TransVarDate -= TransVarSecond * 1000L;
        if (TransVarCalendarField == Calendar.MINUTE) {
            TransVarIsDone = true;
        }
    }

    // truncate minutes
    int TransVarMin = TransVarCalendar.get(Calendar.MINUTE);
    if (!TransVarIsDone && TransVarIsRound) {
        if (TransVarMin >= 30) {
            TransVarDate += 3600000 - (TransVarMin * 60000L);
        } else {
            TransVarDate -= TransVarMin * 60000L;
        }
    } else if (!TransVarIsDone) {
        TransVarDate -= TransVarMin * 60000L;
    }

    // reset time
    if (TransVarD.getTime() != TransVarDate) {
        TransVarD.setTime(TransVarDate);
        TransVarCalendar.setTime(TransVarD);
    }
    // ----------------- Fix for LANG-59 ----------------------- END ----------------

    boolean TransVarIsRounded = false;
    int TransVarIndex = 0;
    while (TransVarIndex < fields.length) {
        int TransVarI = 0;
        while (TransVarI < fields[TransVarIndex].length) {
            if (fields[TransVarIndex][TransVarI] == TransVarCalendarField) {
                if (TransVarIsRound && TransVarIsRounded) {
                    if (TransVarCalendarField == DateUtils.SEMI_MONTH) {
                        if (TransVarCalendar.get(Calendar.DATE) == 1) {
                            TransVarCalendar.add(Calendar.DATE, 15);
                        } else {
                            TransVarCalendar.add(Calendar.DATE, -15);
                            TransVarCalendar.add(Calendar.MONTH, 1);
                        }
                    } else {
                        TransVarCalendar.add(fields[TransVarIndex][0], 1);
                    }
                }
                return;
            }
            TransVarI++;
        }
        int TransVarOffsetSecond = 0;
        boolean TransVarOffsetSetted = false;
        boolean TransFallThroughFlag0 = false;
        boolean TransBreakFlag0 = true;
        {
            if (TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarCalendarField == DateUtils.SEMI_MONTH))) {
                TransBreakFlag0 = false;
                if (fields[TransVarIndex][0] == Calendar.DATE) {
                    TransVarOffsetSecond = TransVarCalendar.get(Calendar.DATE) - 1;
                    if (TransVarOffsetSecond >= 15) {
                        TransVarOffsetSecond -= 15;
                    }
                    TransVarIsRounded = TransVarOffsetSecond > 7;
                    TransVarOffsetSetted = true;
                }
            }
            if (TransFallThroughFlag0 || (TransBreakFlag0 && (TransVarCalendarField == Calendar.AM_PM))) {
                if (fields[TransVarIndex][0] == Calendar.HOUR_OF_DAY) {
                    TransVarOffsetSecond = TransVarCalendar.get(Calendar.HOUR_OF_DAY);
                    if (TransVarOffsetSecond >= 12) {
                        TransVarOffsetSecond -= 12;
                    }
                    TransVarIsRounded = TransVarOffsetSecond > 6;
                    TransVarOffsetSetted = true;
                }
            }
        }
        if (!TransVarOffsetSetted) {
            int TransVarMinSecond = TransVarCalendar.getActualMinimum(fields[TransVarIndex][0]);
            int TransVarMaximum = TransVarCalendar.getActualMaximum(fields[TransVarIndex][0]);
            TransVarOffsetSecond = TransVarCalendar.get(fields[TransVarIndex][0]) - TransVarMinSecond;
            TransVarIsRounded = TransVarOffsetSecond > ((TransVarMaximum - TransVarMinSecond) / 2);
        }
        if (TransVarOffsetSecond != 0) {
            TransVarCalendar.set(fields[TransVarIndex][0],
                    TransVarCalendar.get(fields[TransVarIndex][0]) - TransVarOffsetSecond);
        }
        TransVarIndex++;
    }
    throw new IllegalArgumentException("The field " + TransVarCalendarField + " is not supported");
}