
private static String extractClassNameIfGoog(Node TransVarNode1, Node TransVarNode, String TransVarName) {
  String TransVarClassNameObject = null;

  if (NodeUtil.isExprCall(TransVarNode)) {
    Node TransVarCallee1 = TransVarNode1.getFirstChild();
    if (TransVarCallee1 != null && TransVarCallee1.getType() == Token.GETPROP) {
      String TransVarNameNode = TransVarCallee1.getQualifiedName();
      if (TransVarName.equals(TransVarNameNode)) {
        Node TransVarNextNode = TransVarCallee1.getNext();
        if (TransVarNextNode != null && TransVarNextNode.getType() == Token.STRING) {
          TransVarClassNameObject = TransVarNextNode.getString();
        }
      }
    }
  }

  return TransVarClassNameObject;
}