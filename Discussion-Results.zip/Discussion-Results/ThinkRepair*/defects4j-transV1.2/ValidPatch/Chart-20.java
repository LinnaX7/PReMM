
public ValueMarker(double TransVarCurrentValue, Paint TransVarPaintValue, Stroke TransVarCurrentStroke, 
                   Paint TransVarP, Stroke TransVarCurrentStroke2, float TransVarAlpha2) {
    super(TransVarPaintValue, TransVarCurrentStroke, TransVarP, TransVarCurrentStroke2, TransVarAlpha2);
    this.value = TransVarCurrentValue;
}