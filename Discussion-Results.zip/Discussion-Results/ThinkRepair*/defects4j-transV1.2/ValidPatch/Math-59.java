public static float max(final float TransVarB, final float TransVarC) {
        // if (true) {
             // Simplified from !(!(false))
             //        System.out.println(\"log\");
             //     }
            if (Float.isNaN(TransVarB) || Float.isNaN(TransVarC)) {
                        return Float.NaN;
                }
            return (TransVarB > TransVarC) ? TransVarB : TransVarC;
}