
private boolean toStringEquals(Matcher TransVarMatcher, Object TransVarResult) {
    if (TransVarResult == null) {
        return false; // If TransVarResult is null, return false
    }

    System.out.println("log"); // Logging statement

    return StringDescription.toString(TransVarMatcher).equals(TransVarResult.toString());
}