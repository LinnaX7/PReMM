
private String format(JSError errorObject, boolean isWarning) {
    // extract source excerpt
    SourceExcerptProvider sourceProvider = getSource();
    String source = sourceProvider == null ? null :
        excerpt.get(sourceProvider, errorObject.sourceName, errorObject.lineNumber, excerptFormatter);

    // formatting the message
    StringBuilder buffer = new StringBuilder();
    if (errorObject.sourceName != null) {
        buffer.append(errorObject.sourceName);
        if (errorObject.lineNumber > 0) {
            buffer.append(':');
            buffer.append(errorObject.lineNumber);
        }
        buffer.append(": ");
    }

    buffer.append(getLevelName(isWarning ? CheckLevel.WARNING : CheckLevel.ERROR));
    buffer.append(" - ");

    buffer.append(errorObject.description);
    buffer.append('\n');
    if (source != null) {
        buffer.append(source);
        buffer.append('\n');
        int charNum = errorObject.getCharno();

        // padding equal to the excerpt and arrow at the end
        // charno == sourceExpert.length() means something is missing
        // at the end of the line
        if (excerpt.equals(LINE) && 0 <= charNum && charNum <= source.length()) { // Fixed Condition
            int j = 0;
            while (j < charNum) {
                char c = source.charAt(j);
                if (Character.isWhitespace(c)) {
                    buffer.append(c);
                } else {
                    buffer.append(' ');
                }
                j++;
            }
            buffer.append("^\n");
        }
    }
    return buffer.toString();
}