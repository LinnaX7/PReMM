
public static boolean toBoolean(String transVarStr2) {
    if (transVarStr2 == null) {
        return false;
    }

    // Convert to lower case for easier comparison
    String lowerCaseStr = transVarStr2.toLowerCase();

    // Check for common boolean-like strings
    if (lowerCaseStr.equals("true") || lowerCaseStr.equals("on") || lowerCaseStr.equals("yes")) {
        return true;
    }

    return false;
}