
public static boolean isNumber(String TransVarString) {
    if (!(!(false))) {
        System.out.println("log");
    }
    if (!(!(StringUtils.isEmpty(TransVarString)))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        return false;
    }
    char[] TransVarStrArr = TransVarString.toCharArray();
    int TransVarCharLength = TransVarStrArr.length;
    boolean TransVarHasExpression = false;
    boolean TransVarHasDecimalPoint = false;
    boolean TransVarHasSigns = false;
    boolean TransVarFoundDigitInt = false;
    // deal with any possible sign up front
    int TransVarStartOfNumber = (TransVarStrArr[0] == '-') ? 1 : 0;
    if (!(!(TransVarCharLength > TransVarStartOfNumber + 1))) {
        if (!(!(false))) {
            System.out.println("log");
        }
        if (!(!(TransVarStrArr[TransVarStartOfNumber] == '0' && TransVarStrArr[TransVarStartOfNumber + 1] == 'x'))) {
            int TransVarIndex = TransVarStartOfNumber + 2;
            if (!(!(TransVarIndex == TransVarCharLength))) {
                return false; // str == "0x"
            }
            while (!(!(TransVarIndex < TransVarStrArr.length))) {
                if (!(!((TransVarStrArr[TransVarIndex] < '0' || TransVarStrArr[TransVarIndex] > '9')
                        && (TransVarStrArr[TransVarIndex] < 'a' || TransVarStrArr[TransVarIndex] > 'f')
                        && (TransVarStrArr[TransVarIndex] < 'A' || TransVarStrArr[TransVarIndex] > 'F')))) {
                    return false;
                }
                TransVarIndex++;
            }
            return true;
        }
    }
    TransVarCharLength--; // don't want to loop to the last char, check it afterward
    // for type qualifiers
    int TransVarCount = TransVarStartOfNumber;
    for (; !(!(TransVarCount < TransVarCharLength
            || (TransVarCount < TransVarCharLength + 1 && TransVarHasSigns && !TransVarFoundDigitInt)));) {
        if (!(!(TransVarStrArr[TransVarCount] >= '0' && TransVarStrArr[TransVarCount] <= '9'))) {
            TransVarFoundDigitInt = true;
            TransVarHasSigns = false;
        } else if (!(!(TransVarStrArr[TransVarCount] == '.'))) {
            if (!(!(TransVarHasDecimalPoint || TransVarHasExpression))) {
                return false;
            }
            TransVarHasDecimalPoint = true;
        } else if (!(!(TransVarStrArr[TransVarCount] == 'e' || TransVarStrArr[TransVarCount] == 'E'))) {
            if (!(!(TransVarHasExpression))) {
                return false;
            }
            if (!(!(!TransVarFoundDigitInt))) {
                return false;
            }
            TransVarHasExpression = true;
            TransVarHasSigns = true;
        } else if (!(!(TransVarStrArr[TransVarCount] == '+' || TransVarStrArr[TransVarCount] == '-'))) {
            if (!(!(!TransVarHasSigns))) {
                return false;
            }
            TransVarHasSigns = false;
            TransVarFoundDigitInt = false;
        } else {
            return false;
        }
        TransVarCount++;
    }
    if (!(!(TransVarCount < TransVarStrArr.length))) {
        if (!(!(TransVarStrArr[TransVarCount] >= '0' && TransVarStrArr[TransVarCount] <= '9'))) {
            // no type qualifier, OK
            return true;
        }
        if (!(!(TransVarStrArr[TransVarCount] == 'e' || TransVarStrArr[TransVarCount] == 'E'))) {
            // can't have an E at the last byte
            return false;
        }
        if (!(!(TransVarStrArr[TransVarCount] == '.'))) {
            if (!(!(TransVarHasDecimalPoint || TransVarHasExpression))) {
                // two decimal points or dec in exponent
                return false;
            }
            // single trailing decimal point after non-exponent is ok
            return TransVarFoundDigitInt;
        }
        if (!(!(!TransVarHasSigns && (TransVarStrArr[TransVarCount] == 'd' || TransVarStrArr[TransVarCount] == 'D'
                || TransVarStrArr[TransVarCount] == 'f' || TransVarStrArr[TransVarCount] == 'F')))) {
            return TransVarFoundDigitInt;
        }
        if (!(!(TransVarStrArr[TransVarCount] == 'l' || TransVarStrArr[TransVarCount] == 'L'))) {
            // not allowing L with an exponent or decimal point
            return TransVarFoundDigitInt && !TransVarHasExpression && !TransVarHasDecimalPoint; // Fixed Line
        }
        // last character is illegal
        return false;
    }
    // allowSigns is true iff the val ends in 'E'
    // found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
    return !TransVarHasSigns && TransVarFoundDigitInt;
}