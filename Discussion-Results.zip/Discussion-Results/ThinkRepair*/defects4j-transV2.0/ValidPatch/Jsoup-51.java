
boolean matchesLetter() {
    if (isEmpty()) {
        return false;
    }

    char TransVarC2 = input[pos];
    return Character.isLetter(TransVarC2);
}