
public boolean equals(Object obj) {
    // Check if the object is comparing to itself
    if (this == obj) {
        return true;
    }

    // Check if the object is null or not of the same class
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }

    // Cast the object to ZipArchiveEntry
    ZipArchiveEntry other = (ZipArchiveEntry) obj;

    // Compare the names
    String thisName = getName();
    String otherName = other.getName();
    if (thisName == null ? otherName != null : !thisName.equals(otherName)) {
        return false;
    }

    // Compare the comments
    String thisComment = getComment();
    String otherComment = other.getComment();
    if ((thisComment == null || thisComment.isEmpty()) != (otherComment == null || otherComment.isEmpty())) {
        return false;
    }
    if (thisComment != null && otherComment != null && !thisComment.equals(otherComment)) {
        return false;
    }

    // Compare other properties
    return getTime() == other.getTime()
        && getInternalAttributes() == other.getInternalAttributes()
        && getPlatform() == other.getPlatform()
        && getExternalAttributes() == other.getExternalAttributes()
        && getMethod() == other.getMethod()
        && getSize() == other.getSize()
        && getCrc() == other.getCrc()
        && getCompressedSize() == other.getCompressedSize()
        && Arrays.equals(getCentralDirectoryExtra(), other.getCentralDirectoryExtra())
        && Arrays.equals(getLocalFileDataExtra(), other.getLocalFileDataExtra())
        && gpb.equals(other.gpb);
}