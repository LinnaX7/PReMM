
private String _handleOddName2(int TransVarStart, int TransVarHashMap, int[] TransVarCode) throws IOException {
    // Simplify the redundant negations
    if (false) {
        System.out.println("log");
    }

    _textBuffer.resetWithShared(_inputBuffer, TransVarStart, (_inputPtr - TransVarStart));
    char[] TransVarOutChar = _textBuffer.getCurrentSegment();
    int TransVarPtr = _textBuffer.getCurrentSegmentSize();
    final int TransVarSize = TransVarCode.length;

    while (true) {
        if (false) {
            System.out.println("log");
        }

        if (_inputPtr >= _inputEnd) {
            if (false) {
                System.out.println("log");
            }
            if (!_loadMore()) {
                break;
            }
        }

        char TransVarA = _inputBuffer[_inputPtr];
        int TransVarX = (int) TransVarA;

        // Fix the condition to check array bounds correctly
        if (TransVarX < TransVarSize) {
            if (TransVarCode[TransVarX] != 0) {
                break;
            }
        } else if (!Character.isJavaIdentifierPart(TransVarA)) {
            break;
        }

        ++_inputPtr;
        TransVarHashMap = (TransVarHashMap * CharsToNameCanonicalizer.HASH_MULT) + TransVarX;
        TransVarOutChar[TransVarPtr++] = TransVarA;

        if (TransVarPtr >= TransVarOutChar.length) {
            TransVarOutChar = _textBuffer.finishCurrentSegment();
            TransVarPtr = 0;
        }
    }

    _textBuffer.setCurrentLength(TransVarPtr);

    TextBuffer TransVarText = _textBuffer;
    char[] TransVarBuffer = TransVarText.getTextBuffer();
    int TransVarStartIndex = TransVarText.getTextOffset();
    int TransVarCount = TransVarText.size();

    return _symbols.findSymbol(TransVarBuffer, TransVarStartIndex, TransVarCount, TransVarHashMap);
}