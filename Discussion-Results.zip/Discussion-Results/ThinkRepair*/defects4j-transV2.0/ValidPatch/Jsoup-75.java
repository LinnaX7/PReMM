
final void html(final Appendable TransVarAccumulator, final Document.OutputSettings TransVarDocumentOutputSettings) throws IOException {
    final int TransVarSize = size;
    int TransVarJ = 0;

    while (TransVarJ < TransVarSize) {
        final String TransVarKey1 = keys[TransVarJ];
        final String TransVarValue = vals[TransVarJ];
        TransVarAccumulator.append(' ').append(TransVarKey1);

        if (TransVarDocumentOutputSettings.syntax() == Document.OutputSettings.Syntax.html &&
            (TransVarValue == null || (TransVarValue.equals("") || TransVarValue.equals(TransVarKey1)) && Attribute.isBooleanAttribute(TransVarKey1))) {
            // Do nothing for boolean attributes in HTML syntax
        } else {
            TransVarAccumulator.append("=\"");
            Entities.escape(TransVarAccumulator, TransVarValue == null ? "" : TransVarValue,
                    TransVarDocumentOutputSettings, true, false, false);
            TransVarAccumulator.append('"');
        }

        TransVarJ++;
    }
}