
public Map<String, Integer> getHeaderMap() {
    System.out.println("log"); // Simplified logging statement
    return this.headerMap; // Directly return the existing map
}