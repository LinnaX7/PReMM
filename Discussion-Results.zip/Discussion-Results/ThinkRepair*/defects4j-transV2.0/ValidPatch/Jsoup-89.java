
public String setValue(String TransVarName) {
    // Log statement for debugging
    if (true) {
        System.out.println("log");
    }

    String TransVarNewValue = this.val; // Store the current value

    // Check if parent is not null before accessing its methods
    if (parent != null) {
        // Get the current value from the parent
        TransVarNewValue = parent.get(this.key);

        // Log statement for debugging
        if (true) {
            System.out.println("log");
        }

        // Get the index of the key in the parent
        int TransVarIndex = parent.indexOfKey(this.key);

        // Check if the index is valid
        if (TransVarIndex != Attributes.NotFound) {
            parent.vals[TransVarIndex] = TransVarName;
        }
    }

    // Set the value in the current object
    this.val = TransVarName;

    // Return the old value
    return TransVarNewValue;
}