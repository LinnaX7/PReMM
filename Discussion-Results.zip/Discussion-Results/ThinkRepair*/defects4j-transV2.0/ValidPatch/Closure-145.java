
private boolean isOneExactlyFunctionOrDo(Node node) {
  // Check if the node is either a FUNCTION or a DO node.
  // This is used to ensure that labeled FUNCTION or DO nodes are not
  // generated when extraneous BLOCKs are skipped.
  // A labeled node should either be a FUNCTION or a DO, not an empty
  // statement or a block with more than one child.

  if (node.getType() == Token.LABEL) {
    Node labeledNode = node.getLastChild();
    return (labeledNode.getType() == Token.FUNCTION || labeledNode.getType() == Token.DO) &&
           (labeledNode.getType() != Token.BLOCK || labeledNode.getChildCount() <= 1);
  }

  return (node.getType() == Token.FUNCTION || node.getType() == Token.DO);
}