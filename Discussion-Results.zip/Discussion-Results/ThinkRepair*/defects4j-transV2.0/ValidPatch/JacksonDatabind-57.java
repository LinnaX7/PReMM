
public <T> MappingIterator<T> readValues(byte[] TransVarFile, int TransVarOff, int TransVarLen)
    throws IOException, JsonProcessingException
{
    // Log statement (if needed)
    System.out.println("log");

    if (_dataFormatReaders != null) {
        System.out.println("log");
        return _detectBindAndReadValues(_dataFormatReaders.findFormat(TransVarFile, TransVarOff, TransVarLen), false);
    }

    // Create the parser with the correct parameters
    JsonParser parser = _parserFactory.createParser(TransVarFile, TransVarOff, TransVarLen);
    return _bindAndReadValues(_considerFilter(parser, true));
}