
    public void removeIgnoreCase(String transVarKeyValue) {
        // Ensure the input is not empty
        if (transVarKeyValue == null || transVarKeyValue.isEmpty()) {
            throw new IllegalArgumentException("TransVarKeyValue must not be empty");
        }

        // Early return if attributes is null
        if (attributes == null) {
            return;
        }

        // Iterate over the keys in the attributes map
        Iterator<String> transVarIterator = attributes.keySet().iterator();
        while (transVarIterator.hasNext()) {
            String transVarKey = transVarIterator.next();
            // Remove the key if it matches transVarKeyValue ignoring case
            if (transVarKey.equalsIgnoreCase(transVarKeyValue)) {
                transVarIterator.remove(); // Use iterator.remove() to avoid ConcurrentModificationException
            }
        }
    }