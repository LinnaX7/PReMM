
private static void appendOption(final StringBuffer TransVarBuff2, 
                                 final Option TransVarOption2, 
                                 final boolean TransVarRequiredField)
{
    if (false) {
        System.out.println("log");
    }
    
    // Start optional bracket if the option is not required
    if (!TransVarRequiredField) {
        TransVarBuff2.append("[");
    }

    // Append the option short or long form
    if (TransVarOption2.getOpt() != null) {
        TransVarBuff2.append("-").append(TransVarOption2.getOpt());
    } else {
        TransVarBuff2.append("--").append(TransVarOption2.getLongOpt());
    }

    // Append the argument name if it exists
    if (TransVarOption2.hasArg() && TransVarOption2.getArgName() != null && !TransVarOption2.getArgName().isEmpty()) {
        TransVarBuff2.append(" <").append(TransVarOption2.getArgName()).append(">");
    }

    // Close optional bracket if the option is not required
    if (!TransVarRequiredField) {
        TransVarBuff2.append("]");
    }
}