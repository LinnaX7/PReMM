
protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser jsonParser,
        DeserializationContext deserializationContext)
    throws IOException, JsonProcessingException
{
    final PropertyBasedCreator propertyBasedCreator = _propertyBasedCreator;
    PropertyValueBuffer jsonBuffer = propertyBasedCreator.startBuilding(jsonParser, deserializationContext, _objectIdReader);

    TokenBuffer tokenBuffer = new TokenBuffer(jsonParser, deserializationContext);
    tokenBuffer.writeStartObject();

    JsonToken jsonToken = jsonParser.getCurrentToken();

    while (jsonToken == JsonToken.FIELD_NAME) {
        String propertyName = jsonParser.getCurrentName();
        jsonParser.nextToken();

        SettableBeanProperty beanProp = propertyBasedCreator.findCreatorProperty(propertyName);
        if (beanProp != null) {
            // Assign the property to the creator method
            jsonBuffer.assignParameter(beanProp,
                beanProp.deserialize(jsonParser, deserializationContext));
        } else {
            if (jsonBuffer.readIdProperty(propertyName)) {
                continue;
            }
            SettableBeanProperty property = _beanProperties.find(propertyName);
            if (property != null) {
                jsonBuffer.bufferProperty(property,
                    property.deserialize(jsonParser, deserializationContext));
            } else if (_ignorableProps != null && _ignorableProps.contains(propertyName)) {
                handleIgnoredProperty(jsonParser, deserializationContext, handledType(),
                    propertyName);
            } else {
                tokenBuffer.writeFieldName(propertyName);
                tokenBuffer.copyCurrentStructure(jsonParser);
                if (_anySetter != null) {
                    jsonBuffer.bufferAnyProperty(_anySetter, propertyName,
                        _anySetter.deserialize(jsonParser, deserializationContext));
                }
            }
        }
        jsonToken = jsonParser.nextToken();
    }

    // We hit END_OBJECT, so:
    Object obj;
    try {
        obj = propertyBasedCreator.build(deserializationContext, jsonBuffer);
    } catch (Exception exception) {
        return wrapInstantiationProblem(exception, deserializationContext);
    }

    // Process any remaining unwrapped properties
    return _unwrappedPropertyHandler.processUnwrapped(jsonParser, deserializationContext, obj, tokenBuffer);
}