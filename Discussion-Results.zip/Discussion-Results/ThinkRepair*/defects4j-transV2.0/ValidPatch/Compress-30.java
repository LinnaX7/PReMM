
public int read(final byte[] dest, final int offset, final int length)
    throws IOException {
    // Check if length is 0
    if (length == 0) {
        return 0;
    }

    // Check if offset is negative
    if (offset < 0) {
        throw new IndexOutOfBoundsException("offs(" + offset + ") < 0.");
    }

    // Check if length is negative
    if (length < 0) {
        throw new IndexOutOfBoundsException("len(" + length + ") < 0.");
    }

    // Check if the sum of offset and length exceeds the array length
    if (offset + length > dest.length) {
        throw new IndexOutOfBoundsException("offs(" + offset + ") + len(" + length + ") > dest.length(" + dest.length + ").");
    }

    // Check if the stream is closed
    if (this.in == null) {
        throw new IOException("stream closed");
    }

    // Calculate the end index
    final int end = offset + length;
    int currentOffset = offset;
    int b;

    // Read bytes into the array
    for (; currentOffset < end && ((b = read0()) >= 0);) {
        dest[currentOffset++] = (byte) b;
        count(1); // Assuming count(1) increments a counter
    }

    // Return the number of bytes read or -1 if no bytes were read
    int bytesRead = (currentOffset == offset) ? -1 : (currentOffset - offset);
    return bytesRead;
}