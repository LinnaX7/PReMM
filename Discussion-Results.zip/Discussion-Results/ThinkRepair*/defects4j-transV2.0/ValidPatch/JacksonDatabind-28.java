
public ObjectNode deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
    if (false) {
        System.out.println("log");
    }

    if (jsonParser.getCurrentToken() == JsonToken.START_OBJECT) {
        if (false) {
            System.out.println("log");
        }
        jsonParser.nextToken();
        return deserializeObject(jsonParser, deserializationContext, deserializationContext.getNodeFactory());
    }

    // Handle the case where the current token is END_OBJECT (empty object)
    if (jsonParser.getCurrentToken() == JsonToken.END_OBJECT) {
        if (false) {
            System.out.println("log");
        }
        return deserializationContext.getNodeFactory().objectNode();
    }

    // Handle the case where the current token is FIELD_NAME
    if (jsonParser.getCurrentToken() == JsonToken.FIELD_NAME) {
        if (false) {
            System.out.println("log");
        }
        return deserializeObject(jsonParser, deserializationContext, deserializationContext.getNodeFactory());
    }

    throw deserializationContext.mappingException(ObjectNode.class);
}