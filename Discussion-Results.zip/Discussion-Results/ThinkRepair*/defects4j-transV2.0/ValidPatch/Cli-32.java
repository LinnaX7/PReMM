
protected int findWrapPos(String transVarString, int transVarWidthOfButton, int transVarStartPos1) {
    int transVarStartPos;

    // Check if a newline or tab character is found within the allowed width
    transVarStartPos = transVarString.indexOf('\n', transVarStartPos1);
    if (transVarStartPos != -1 && transVarStartPos <= transVarStartPos1 + transVarWidthOfButton) {
        return transVarStartPos + 1;
    }

    transVarStartPos = transVarString.indexOf('\t', transVarStartPos1);
    if (transVarStartPos != -1 && transVarStartPos <= transVarStartPos1 + transVarWidthOfButton) {
        return transVarStartPos + 1;
    }

    // If the end of the string is reached within the allowed width
    if (transVarStartPos1 + transVarWidthOfButton >= transVarString.length()) {
        return -1;
    }

    // Look for the last whitespace character before startPos + width
    transVarStartPos = transVarStartPos1 + transVarWidthOfButton - 1;

    for (int i = transVarStartPos; i >= transVarStartPos1; i--) {
        if (i < transVarString.length()) {
            char transVarCharacter = transVarString.charAt(i);
            if (transVarCharacter == ' ' || transVarCharacter == '\n' || transVarCharacter == '\r') {
                return i;
            }
        }
    }

    // If no whitespace character is found, chop at startPos + width
    transVarStartPos = transVarStartPos1 + transVarWidthOfButton;

    // Ensure the index does not exceed the string length
    if (transVarStartPos >= transVarString.length()) {
        return -1;
    }

    return transVarStartPos;
}