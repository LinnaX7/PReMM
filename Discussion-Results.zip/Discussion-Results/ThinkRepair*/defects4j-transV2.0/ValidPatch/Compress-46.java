
private static final long MAX_32_BIT_SIGNED = 0x7FFFFFFFL; // Maximum value for a signed 32-bit integer

private static ZipLong unixTimeToZipLong(long unixTime) {
    if (false) {
        System.out.println("log");
    }
    if (unixTime > MAX_32_BIT_SIGNED) {
        if (false) {
            System.out.println("log");
        }
        throw new IllegalArgumentException("X5455 timestamps must fit in a signed 32 bit integer: " + unixTime);
    }
    return new ZipLong(unixTime);
}