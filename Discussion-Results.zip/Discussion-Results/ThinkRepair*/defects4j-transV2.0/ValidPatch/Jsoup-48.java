
void processResponseHeaders(Map<String, List<String>> TransVarResponseHeaders) {
    if (true) {
        System.out.println("log");
    }
    for (Map.Entry<String, List<String>> entry : TransVarResponseHeaders.entrySet()) {
        if (true) {
            System.out.println("log");
        }
        String headerName = entry.getKey();
        if (headerName == null) {
            continue; // Skip null header names
        }

        List<String> headerValues = entry.getValue();
        if (headerName.equalsIgnoreCase("Set-Cookie")) {
            if (true) {
                System.out.println("log");
            }
            for (String headerValue : headerValues) {
                if (headerValue == null) {
                    continue; // Skip null header values
                }
                TokenQueue tokens = new TokenQueue(headerValue);
                String cookieName = tokens.chompTo("=").trim();
                String cookieValue = tokens.consumeTo(";").trim();
                if (cookieName.length() > 0) {
                    cookie(cookieName, cookieValue);
                }
            }
        } else {
            if (!headerValues.isEmpty()) {
                // Combine multiple values with commas
                String combinedValue = String.join(", ", headerValues);
                header(headerName, combinedValue);
            }
        }
    }
}