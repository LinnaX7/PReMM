
private boolean isShortOption(String TransVarTokenIn) {
    // Check if the token starts with a hyphen and has a length of at least 2
    if (TransVarTokenIn.startsWith("-") && TransVarTokenIn.length() >= 2) {
        // Find the position of the equals sign, if any
        int equalsIndex = TransVarTokenIn.indexOf('=');
        if (equalsIndex == -1) {
            // No equals sign, extract the entire part after the hyphen
            String shortOption = TransVarTokenIn.substring(1);
            return options.hasShortOption(shortOption);
        } else {
            // Equals sign found, extract the part before the equals sign
            String shortOption = TransVarTokenIn.substring(1, equalsIndex);
            return options.hasShortOption(shortOption);
        }
    }
    return false;
}