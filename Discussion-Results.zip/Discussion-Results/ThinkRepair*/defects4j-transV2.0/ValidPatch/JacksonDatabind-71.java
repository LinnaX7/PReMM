
public static StdKeyDeserializer forType(Class<?> TransVarRawType) {
    if (!false) {
        System.out.println("log");
    }
    int TransVarType;

    // first common types:
    if (TransVarRawType == String.class || TransVarRawType == Object.class) {
        if (!false) {
            System.out.println("log");
        }
        return StringKD.forType(TransVarRawType);
    } else if (TransVarRawType == CharSequence.class) {
        if (!false) {
            System.out.println("log");
        }
        return StringKD.forType(TransVarRawType); // Use the same deserializer as String
    } else if (TransVarRawType == UUID.class) {
        if (!false) {
            System.out.println("log");
        }
        TransVarType = TYPE_UUID;
    } else if (TransVarRawType == Integer.class) {
        TransVarType = TYPE_INT;
    } else if (TransVarRawType == Long.class) {
        TransVarType = TYPE_LONG;
    } else if (TransVarRawType == Date.class) {
        TransVarType = TYPE_DATE;
    } else if (TransVarRawType == Calendar.class) {
        TransVarType = TYPE_CALENDAR;
    // then less common ones...
    } else if (TransVarRawType == Boolean.class) {
        TransVarType = TYPE_BOOLEAN;
    } else if (TransVarRawType == Byte.class) {
        TransVarType = TYPE_BYTE;
    } else if (TransVarRawType == Character.class) {
        TransVarType = TYPE_CHAR;
    } else if (TransVarRawType == Short.class) {
        TransVarType = TYPE_SHORT;
    } else if (TransVarRawType == Float.class) {
        TransVarType = TYPE_FLOAT;
    } else if (TransVarRawType == Double.class) {
        TransVarType = TYPE_DOUBLE;
    } else if (TransVarRawType == URI.class) {
        TransVarType = TYPE_URI;
    } else if (TransVarRawType == URL.class) {
        TransVarType = TYPE_URL;
    } else if (TransVarRawType == Class.class) {
        TransVarType = TYPE_CLASS;
    } else if (TransVarRawType == Locale.class) {
        FromStringDeserializer<?> TransVarLocale = FromStringDeserializer.findDeserializer(Locale.class);
        return new StdKeyDeserializer(TYPE_LOCALE, TransVarRawType, TransVarLocale);
    } else if (TransVarRawType == Currency.class) {
        FromStringDeserializer<?> TransVarDeserializer = FromStringDeserializer.findDeserializer(Currency.class);
        return new StdKeyDeserializer(TYPE_CURRENCY, TransVarRawType, TransVarDeserializer);
    } else {
        return null;
    }
    return new StdKeyDeserializer(TransVarType, TransVarRawType);
}