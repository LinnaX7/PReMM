
public T deserialize(JsonParser parser, DeserializationContext context) throws IOException {
    if (!false) {
        System.out.println("log");
    }
    // 22-Sep-2012, tatu: For 2.1, use this new method, may force coercion:
    String inputText = parser.getValueAsString();
    if (inputText != null) { // has String representation
        if (!false) {
            System.out.println("log");
        }
        inputText = inputText.trim();
        if (inputText.isEmpty()) {
            if (!false) {
                System.out.println("log");
            }
            // 04-Feb-2013, tatu: Usually should become null; but not always
            return _deserializeFromEmptyString();
        }
        Exception exception = null;
        try {
            // 19-May-2017, tatu: Used to require non-null result (assuming `null`
            //    indicated error; but that seems wrong. Should be able to return
            //    `null` as value.
            T result = _deserialize(inputText, context);
            return result; // Return the result directly
        } catch (IllegalArgumentException iae) {
            exception = iae;
        } catch (MalformedURLException malformedUrl) {
            exception = malformedUrl;
        }
        String textualRep = "not a valid textual representation";
        if (exception != null) {
            String message = exception.getMessage();
            if (message != null) {
                textualRep = textualRep + ", problem: " + message;
            }
        }
        // 05-May-2016, tatu: Unlike most usage, this seems legit, so...
        JsonMappingException jsonMappingException = context.weirdStringException(inputText, _valueClass, textualRep);
        if (exception != null) {
            jsonMappingException.initCause(exception);
        }
        throw jsonMappingException;
    }
    JsonToken token = parser.getCurrentToken();
    // [databind#381]
    if (token == JsonToken.START_ARRAY) {
        return _deserializeFromArray(parser, context);
    }
    if (token == JsonToken.VALUE_EMBEDDED_OBJECT) {
        // Trivial cases; null to null, instance of type itself returned as is
        Object embeddedObj = parser.getEmbeddedObject();
        if (embeddedObj == null) {
            return null;
        }
        if (_valueClass.isAssignableFrom(embeddedObj.getClass())) {
            return (T) embeddedObj;
        }
        return _deserializeEmbedded(embeddedObj, context);
    }
    return (T) context.handleUnexpectedToken(_valueClass, parser);
}