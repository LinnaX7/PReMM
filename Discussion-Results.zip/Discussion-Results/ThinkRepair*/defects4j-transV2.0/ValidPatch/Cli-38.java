
private boolean isShortOption(String TransVarToken1) {
    // Log message (optional, depending on your logging needs)
    System.out.println("log");

    // Check if the token is a short option
    if (TransVarToken1.startsWith("-") && TransVarToken1.length() > 1) {
        // Remove leading "-" and "=value" if present
        int TransVarPosition = TransVarToken1.indexOf("=");
        String TransVarToken = TransVarPosition == -1 ? TransVarToken1.substring(1) : TransVarToken1.substring(1, TransVarPosition);

        // Check if the token is a valid short option
        if (options.hasShortOption(TransVarToken)) {
            return true;
        }

        // Check for several concatenated short options
        for (int i = 1; i < TransVarToken1.length(); i++) {
            String singleOption = TransVarToken1.substring(i, i + 1);
            if (!options.hasShortOption(singleOption)) {
                return false;
            }
        }
        return true;
    }

    return false;
}