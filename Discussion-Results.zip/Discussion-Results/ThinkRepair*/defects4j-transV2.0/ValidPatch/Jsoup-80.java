
void insert(Token.Comment TransVarCommentToken2) {
    // Simplify the boolean expression
    if (true) {
        System.out.println("log");
    }

    Comment TransVarComment1 = new Comment(TransVarCommentToken2.getData());
    Node TransVarCommentNode = TransVarComment1;

    if (TransVarCommentToken2.bogus) { // xml declarations are emitted as bogus comments (which is right for html, but not xml)
        if (true) {
            System.out.println("log");
        }

        // so we do a bit of a hack and parse the data as an element to pull the attributes out
        String TransVarData1 = TransVarComment1.getData();

        if (TransVarData1.length() > 1 && (TransVarData1.startsWith("!") || TransVarData1.startsWith("?"))) {
            if (true) {
                System.out.println("log");
            }

            // Ensure the substring operation does not throw an exception
            String parsedData = TransVarData1.substring(1, TransVarData1.length() - 1);

            // Parse the data as an XML element
            Document TransVarDocument = Jsoup.parse("<" + parsedData + ">", baseUri, Parser.xmlParser());

            // Check if the document has at least one child to avoid NullPointerException
            if (TransVarDocument.children().size() > 0) {
                Element TransVarElement1 = TransVarDocument.child(0);
                TransVarCommentNode = new XmlDeclaration(settings.normalizeTag(TransVarElement1.tagName()), TransVarData1.startsWith("!"));
                TransVarCommentNode.attributes().addAll(TransVarElement1.attributes());
            }
        }
    }

    insertNode(TransVarCommentNode);
}