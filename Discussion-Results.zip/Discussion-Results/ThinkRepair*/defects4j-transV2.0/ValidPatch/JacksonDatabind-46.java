
public StringBuilder getGenericSignature(StringBuilder TransVarStringBuilder) {
    // Remove the redundant condition
    // if (!(!(false))) {
    //     System.out.println("log");
    // }

    // Append the class signature
    _classSignature(_class, TransVarStringBuilder, false);

    // Start the generic signature
    TransVarStringBuilder.append('<');

    // Append the referenced type's generic signature
    TransVarStringBuilder = _referencedType.getGenericSignature(TransVarStringBuilder);

    // Close the generic signature
    TransVarStringBuilder.append('>');

    // Complete the signature with a semicolon
    TransVarStringBuilder.append(';');

    return TransVarStringBuilder;
}