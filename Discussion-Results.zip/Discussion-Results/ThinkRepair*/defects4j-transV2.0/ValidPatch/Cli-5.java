
static String stripLeadingHyphens(String TransVarS) {
    if (TransVarS == null) {
        return null;
    }
    while (TransVarS.startsWith("-")) {
        TransVarS = TransVarS.substring(1);
    }
    return TransVarS;
}