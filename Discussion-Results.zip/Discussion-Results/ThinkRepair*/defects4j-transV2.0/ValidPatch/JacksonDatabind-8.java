
protected void verifyNonDup(AnnotatedWithParams TransVarNewTwo, int TransVarTypeIndex2, boolean TransVarNewThree) {
    // Create the mask for the given type index
    final int TransVarMask2 = (1 << TransVarTypeIndex2);
    _hasNonDefaultCreator = true;

    // Get the existing creator for the given type index
    AnnotatedWithParams TransVarNewOne = _creators[TransVarTypeIndex2];

    // Check if there is an existing creator
    if (TransVarNewOne != null) {
        // Check if the existing creator is explicitly annotated
        if ((_explicitCreators & TransVarMask2) != 0) {
            // If the existing creator is explicitly annotated and the new one is not, return early
            if (!TransVarNewThree) {
                return;
            }

            // Both creators are explicitly annotated, throw an exception if they are of the same class
            if (TransVarNewOne.getClass() == TransVarNewTwo.getClass()) {
                throw new IllegalArgumentException("Conflicting " + TYPE_DESCS[TransVarTypeIndex2]
                        + " creators: already had explicitly marked " + TransVarNewOne + ", encountered " + TransVarNewTwo);
            }
        }
    }

    // If the new creator is explicitly annotated, update the bitmask
    if (TransVarNewThree) {
        _explicitCreators |= TransVarMask2;
    }

    // Set the new creator
    _creators[TransVarTypeIndex2] = _fixAccess(TransVarNewTwo);
}