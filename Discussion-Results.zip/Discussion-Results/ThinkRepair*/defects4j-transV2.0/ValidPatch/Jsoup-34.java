
public int nextIndexOf(CharSequence transVarStr) {
    if (transVarStr == null || transVarStr.length() == 0) {
        return -1;
    }

    char transVarFirstChar = transVarStr.charAt(0);
    int transVarPosition = pos;

    while (transVarPosition < length) {
        if (transVarFirstChar == input[transVarPosition]) {
            int transVarIndex = transVarPosition + 1;
            int transVarLastPosition = transVarIndex + transVarStr.length() - 1;

            if (transVarLastPosition <= length) {
                int transVarI = 1;
                while (transVarIndex < transVarLastPosition && transVarStr.charAt(transVarI) == input[transVarIndex]) {
                    transVarIndex++;
                    transVarI++;
                }

                if (transVarIndex == transVarLastPosition) {
                    return transVarPosition - pos;
                }
            }
        }
        transVarPosition++;
    }

    return -1;
}