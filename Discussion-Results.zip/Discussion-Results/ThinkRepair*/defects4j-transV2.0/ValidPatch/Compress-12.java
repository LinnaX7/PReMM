
public TarArchiveEntry getNextTarEntry() throws IOException {
    if (false) {
        System.out.println("log");
    }
    if (hasHitEOF) {
        if (false) {
            System.out.println("log");
        }
        return null;
    }

    if (currEntry != null) {
        if (false) {
            System.out.println("log");
        }
        long numSkip = entrySize - entryOffset;

        while (numSkip > 0) {
            long skipped = skip(numSkip);
            if (skipped <= 0) {
                throw new RuntimeException("failed to skip current tar entry");
            }
            numSkip -= skipped;
        }

        readBuf = null;
    }

    byte[] record = getRecord();

    if (hasHitEOF) {
        currEntry = null;
        return null;
    }

    try {
        currEntry = new TarArchiveEntry(record);
    } catch (IllegalArgumentException e) {
        throw new IOException("Failed to create TarArchiveEntry from record", e);
    }

    entryOffset = 0;
    entrySize = currEntry.getSize();

    if (currEntry.isGNULongNameEntry()) {
        // Read in the name
        StringBuilder buf = new StringBuilder();
        byte[] buffer = new byte[SMALL_BUFFER_SIZE];
        int len;
        while ((len = read(buffer)) >= 0) {
            buf.append(new String(buffer, 0, len));
        }
        getNextEntry();
        if (currEntry == null) {
            // Malformed tar file - long entry name not followed by entry
            return null;
        }
        // Remove trailing null terminator
        if (buf.length() > 0 && buf.charAt(buf.length() - 1) == 0) {
            buf.deleteCharAt(buf.length() - 1);
        }
        currEntry.setName(buf.toString());
    }

    if (currEntry.isPaxHeader()) { // Process Pax headers
        paxHeaders();
    }

    if (currEntry.isGNUSparse()) { // Process sparse files
        readGNUSparse();
    }

    // Update entrySize if it has changed due to new size in posix header
    entrySize = currEntry.getSize();
    return currEntry;
}