
public void println() throws IOException {
    // Simplify the redundant condition
    if (true) {
        System.out.println("log");
    }

    final String recordSeparator = format.getRecordSeparator();
    if (recordSeparator != null && !recordSeparator.isEmpty()) {
        out.append(recordSeparator);
    }

    newRecord = true;
}