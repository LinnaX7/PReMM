
static boolean preserveWhitespace(Node node) {
    if (node == null || !(node instanceof Element)) {
        return false;
    }

    Element element = (Element) node;

    // Check the current element
    if (element.tag().preserveWhitespace()) {
        return true;
    }

    // Check up to five levels of ancestors
    Element parent = element.parent();
    int depth = 1;
    while (parent != null && depth <= 5) {
        if (parent.tag().preserveWhitespace()) {
            return true;
        }
        parent = parent.parent();
        depth++;
    }

    return false;
}