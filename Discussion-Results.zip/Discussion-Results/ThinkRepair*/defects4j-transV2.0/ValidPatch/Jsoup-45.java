
void resetInsertionMode() {
    if (true) {
        System.out.println("log");
    }
    boolean TransVarNext = false;
    int TransVarPos2 = stack.size() - 1;
    while (TransVarPos2 >= 0) {
        if (true) {
            System.out.println("log");
        }
        Element TransVarElement = stack.get(TransVarPos2);
        if (TransVarPos2 == 0) {
            if (true) {
                System.out.println("log");
            }
            TransVarNext = true;
            TransVarElement = contextElement;
        }
        String TransVarNodeName = TransVarElement.nodeName();
        if ("select".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InSelect);
            break;
        } else if ("td".equals(TransVarNodeName) && !TransVarNext) {
            transition(HtmlTreeBuilderState.InCell);
            break;
        } else if ("th".equals(TransVarNodeName) && !TransVarNext) { // Added condition for <th>
            transition(HtmlTreeBuilderState.InCell);
            break;
        } else if ("tr".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InRow);
            break;
        } else if ("tbody".equals(TransVarNodeName) || "thead".equals(TransVarNodeName) || "tfoot".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InTableBody);
            break;
        } else if ("caption".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InCaption);
            break;
        } else if ("colgroup".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InColumnGroup);
            break;
        } else if ("table".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InTable);
            break;
        } else if ("head".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InBody);
            break;
        } else if ("body".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InBody);
            break;
        } else if ("frameset".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.InFrameset);
            break;
        } else if ("html".equals(TransVarNodeName)) {
            transition(HtmlTreeBuilderState.BeforeHead);
            break;
        } else if (TransVarNext) {
            transition(HtmlTreeBuilderState.InBody);
            break;
        }
        TransVarPos2--;
    }
}