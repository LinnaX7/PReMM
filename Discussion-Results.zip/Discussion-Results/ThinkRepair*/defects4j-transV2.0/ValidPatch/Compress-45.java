
public static int formatLongOctalOrBinaryBytes(
    final long TransVarLongValue, final byte[] TransVarByteArray, final int TransVarOffsetOfInterest, final int TransVarByteCount) {

    // Check whether we are dealing with UID/GID or SIZE field
    final long TransVarMaxLengthAsOctalChar = TransVarByteCount == TarConstants.UIDLEN ? TarConstants.MAXID : TarConstants.MAXSIZE;

    final boolean TransVarNeg = TransVarLongValue < 0;
    if (TransVarNeg || TransVarLongValue > TransVarMaxLengthAsOctalChar) {
        if (TransVarByteCount < 9) {
            formatLongBinary(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount, TransVarNeg);
        } else {
            formatBigIntegerBinary(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount, TransVarNeg);
        }
    } else {
        return formatLongOctalBytes(TransVarLongValue, TransVarByteArray, TransVarOffsetOfInterest, TransVarByteCount);
    }

    TransVarByteArray[TransVarOffsetOfInterest] = (byte) (TransVarNeg ? 0xff : 0x80);
    return TransVarOffsetOfInterest + TransVarByteCount;
}