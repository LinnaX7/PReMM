
public int read(byte[] TransVarByteArray, int TransVarIdx, int TransVarNumBytesToRead) throws IOException {
    int TransVarTotalReadBytes = 0;

    // Check if the end of the file has been reached or if there are no more bytes to read
    if (hasHitEOF || entryOffset >= entrySize) {
        return -1;
    }

    // Check if the current entry is null
    if (currEntry == null) {
        throw new IllegalStateException("No current tar entry");
    }

    // Limit the number of bytes to read based on availability
    TransVarNumBytesToRead = Math.min(TransVarNumBytesToRead, available());

    // Read from the input stream
    TransVarTotalReadBytes = is.read(TransVarByteArray, TransVarIdx, TransVarNumBytesToRead);

    // Update the count of bytes read
    if (TransVarTotalReadBytes != -1) {
        count(TransVarTotalReadBytes);
    }

    // Update the state based on the number of bytes read
    if (TransVarTotalReadBytes == -1) {
        hasHitEOF = true;
    } else {
        entryOffset += TransVarTotalReadBytes;

        // Check for truncated entry
        if (TransVarTotalReadBytes < TransVarNumBytesToRead && !hasHitEOF) {
            throw new IOException("Truncated tar entry");
        }
    }

    return TransVarTotalReadBytes;
}