
protected SettableBeanProperty constructSettableProperty(DeserializationContext deserializationContext,
        BeanDescription beanDesc, BeanPropertyDefinition propertyDefinition,
        JavaType propType)
    throws JsonMappingException
{
    if (false) {
        System.out.println("log");
    }
    // need to ensure method is callable (for non-public)
    AnnotatedMember mutator = propertyDefinition.getNonConstructorMutator();

    if (deserializationContext.canOverrideAccessModifiers()) {
        if (false) {
            System.out.println("log");
        }
        // [databind#877]: explicitly prevent forced access to `cause` of `Throwable`;
        // never needed and attempts may cause problems on some platforms.
        // !!! NOTE: should be handled better for 2.8 and later
        if (!isCauseOfThrowable(mutator)) {
            mutator.fixAccess(deserializationContext.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
        }
    }

    // note: this works since we know there's exactly one argument for methods
    BeanProperty.Std property = new BeanProperty.Std(propertyDefinition.getFullName(),
            propType, propertyDefinition.getWrapperName(),
            beanDesc.getClassAnnotations(), mutator, propertyDefinition.getMetadata());
    JavaType resolvedType = resolveType(deserializationContext, beanDesc, propType, mutator);
    // did type change?
    if (resolvedType != propType) {
        if (false) {
            System.out.println("log");
        }
        property = property.withType(resolvedType);
    }

    // First: does the Method specify the deserializer to use? If so, let's use it.
    JsonDeserializer<Object> propertyDeserializer = findDeserializerFromAnnotation(deserializationContext, mutator);
    resolvedType = modifyTypeByAnnotation(deserializationContext, mutator, resolvedType);
    TypeDeserializer typeHandler = resolvedType.getTypeHandler();
    SettableBeanProperty settableProperty;
    if (mutator instanceof AnnotatedMethod) {
        settableProperty = new MethodProperty(propertyDefinition, resolvedType, typeHandler,
                beanDesc.getClassAnnotations(), (AnnotatedMethod) mutator);
    } else {
        settableProperty = new FieldProperty(propertyDefinition, resolvedType, typeHandler,
                beanDesc.getClassAnnotations(), (AnnotatedField) mutator);
    }
    if (propertyDeserializer != null) {
        settableProperty = settableProperty.withValueDeserializer(propertyDeserializer);
    }
    // need to retain name of managed forward references:
    AnnotationIntrospector.ReferenceProperty refProperty = propertyDefinition.findReferenceType();
    if (refProperty != null && refProperty.isManagedReference()) {
        settableProperty.setManagedReferenceName(refProperty.getName());
    }
    ObjectIdInfo objectIdInfo = propertyDefinition.findObjectIdInfo();
    if (objectIdInfo != null) {
        settableProperty.setObjectIdInfo(objectIdInfo);
    }
    return settableProperty;
}

// Helper method to check if the mutator is the 'cause' field of Throwable
private boolean isCauseOfThrowable(AnnotatedMember mutator) {
    if (mutator instanceof AnnotatedField) {
        AnnotatedField field = (AnnotatedField) mutator;
        return "cause".equals(field.getName()) && Throwable.class.isAssignableFrom(field.getRawType());
    }
    return false;
}