
public JsonWriter value(double TransVarValue1) throws IOException {
    // Write the deferred name if there is one
    writeDeferredName();

    // Check if the value is NaN or infinite
    if (Double.isNaN(TransVarValue1) || Double.isInfinite(TransVarValue1)) {
        if (isLenient()) {
            // Handle non-finite values in lenient mode
            beforeValue(); // Ensure this is called before writing the value
            if (Double.isNaN(TransVarValue1)) {
                out.append("NaN");
            } else if (TransVarValue1 == Double.POSITIVE_INFINITY) {
                out.append("Infinity");
            } else if (TransVarValue1 == Double.NEGATIVE_INFINITY) {
                out.append("-Infinity");
            }
        } else {
            // Throw exception in non-lenient mode
            throw new IllegalArgumentException("Numeric values must be finite, but was " + TransVarValue1);
        }
    } else {
        // Prepare for writing the value
        beforeValue();
        // Append the value to the output
        out.append(Double.toString(TransVarValue1));
    }

    return this;
}