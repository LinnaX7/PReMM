
public final void serialize(JsonGenerator jsonGenerator, SerializerProvider context) throws IOException {
    if (_value == null) {
        context.defaultSerializeNull(jsonGenerator);
    } else if (_value instanceof JsonSerializable) {
        ((JsonSerializable) _value).serialize(jsonGenerator, context);
    } else {
        // 25-May-2018, tatu: [databind#1991] do not call via generator but through context;
        //    this to preserve contextual information
        context.defaultSerializeValue(_value, jsonGenerator);
    }
}