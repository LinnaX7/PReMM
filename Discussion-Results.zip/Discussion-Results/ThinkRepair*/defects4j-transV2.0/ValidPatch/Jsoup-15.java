
boolean process(Token TransVarToken, TreeBuilder TransVarTreeBuilder) {
    if (false) {
        System.out.println("log");
    }
    switch (TransVarToken.type) {
        case Character: {
            if (false) {
                System.out.println("log");
            }
            Token.Character TransVarCharacter = TransVarToken.asCharacter();
            if (TransVarCharacter.getData().equals(nullString)) {
                if (false) {
                    System.out.println("log");
                }
                // todo confirm that check
                TransVarTreeBuilder.error(this);
                return false;
            } else if (isWhitespace(TransVarCharacter)) {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarCharacter);
            } else {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarCharacter);
                TransVarTreeBuilder.framesetOk(false);
            }
            break;
        }
        case Comment: {
            TransVarTreeBuilder.insert(TransVarToken.asComment());
            break;
        }
        case Doctype: {
            TransVarTreeBuilder.error(this);
            return false;
        }
        case StartTag:
            Token.StartTag TransVarStartToken = TransVarToken.asStartTag();
            String TransVarTagName = TransVarStartToken.name();
            if (TransVarTagName.equals("html")) {
                TransVarTreeBuilder.error(this);
                // merge attributes onto real html
                Element TransVarFirstElement = TransVarTreeBuilder.getStack().getFirst();
                for (Attribute TransVarAttr : TransVarStartToken.getAttributes()) {
                    if (!TransVarFirstElement.hasAttr(TransVarAttr.getKey())) {
                        TransVarFirstElement.attributes().put(TransVarAttr);
                    }
                }
            } else if (StringUtil.in(TransVarTagName, "base", "basefont", "bgsound", "command", "link", "meta", "noframes",
                    "style", "title")) {
                return TransVarTreeBuilder.process(TransVarToken, InHead);
            } else if (TransVarTagName.equals("body")) {
                TransVarTreeBuilder.error(this);
                LinkedList<Element> TransVarElemStack = TransVarTreeBuilder.getStack();
                if (TransVarElemStack.size() == 1 || (TransVarElemStack.size() > 2 && !TransVarElemStack.get(1).nodeName().equals("body"))) {
                    // only in fragment case
                    return false; // ignore
                } else {
                    TransVarTreeBuilder.framesetOk(false);
                    Element TransVarCurrentElement = TransVarElemStack.get(1);
                    for (Attribute TransVarAttribute1 : TransVarStartToken.getAttributes()) {
                        if (!TransVarCurrentElement.hasAttr(TransVarAttribute1.getKey())) {
                            TransVarCurrentElement.attributes().put(TransVarAttribute1);
                        }
                    }
                }
            } else if (TransVarTagName.equals("frameset")) {
                TransVarTreeBuilder.error(this);
                LinkedList<Element> TransVarElementStack = TransVarTreeBuilder.getStack();
                if (TransVarElementStack.size() == 1 || (TransVarElementStack.size() > 2 && !TransVarElementStack.get(1).nodeName().equals("body"))) {
                    // only in fragment case
                    return false; // ignore
                } else if (!TransVarTreeBuilder.framesetOk()) {
                    return false; // ignore frameset
                } else {
                    Element TransVarElement = TransVarElementStack.get(1);
                    if (TransVarElement.parent() != null) {
                        TransVarElement.remove();
                    }
                    while (TransVarElementStack.size() > 1) {
                        TransVarElementStack.removeLast();
                    }
                    TransVarTreeBuilder.insert(TransVarStartToken);
                    TransVarTreeBuilder.transition(InFrameset);
                }
            } else if (StringUtil.in(TransVarTagName, "address", "article", "aside", "blockquote", "center", "details", "dir",
                    "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "menu", "nav", "ol",
                    "p", "section", "summary", "ul")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
            } else if (StringUtil.in(TransVarTagName, "h1", "h2", "h3", "h4", "h5", "h6")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                if (StringUtil.in(TransVarTreeBuilder.currentElement().nodeName(), "h1", "h2", "h3", "h4", "h5", "h6")) {
                    TransVarTreeBuilder.error(this);
                    TransVarTreeBuilder.pop();
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
            } else if (StringUtil.in(TransVarTagName, "pre", "listing")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
                // todo: ignore LF if next token
                TransVarTreeBuilder.framesetOk(false);
            } else if (TransVarTagName.equals("form")) {
                if (TransVarTreeBuilder.getFormElement() != null) {
                    TransVarTreeBuilder.error(this);
                    return false;
                }
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                Element TransVarFormElem = TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.setFormElement(TransVarFormElem);
            } else if (TransVarTagName.equals("li")) {
                TransVarTreeBuilder.framesetOk(false);
                LinkedList<Element> TransVarStack1 = TransVarTreeBuilder.getStack();
                int TransVarIndex = TransVarStack1.size() - 1;
                while (TransVarIndex > 0) {
                    Element TransVarElement1 = TransVarStack1.get(TransVarIndex);
                    if (TransVarElement1.nodeName().equals("li")) {
                        TransVarTreeBuilder.process(new Token.EndTag("li"));
                        break;
                    }
                    if (TransVarTreeBuilder.isSpecial(TransVarElement1) && !StringUtil.in(TransVarElement1.nodeName(), "address", "div", "p")) {
                        break;
                    }
                    TransVarIndex--;
                }
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
            } else if (StringUtil.in(TransVarTagName, "dd", "dt")) {
                TransVarTreeBuilder.framesetOk(false);
                LinkedList<Element> TransVarElementList = TransVarTreeBuilder.getStack();
                int TransVarJ = TransVarElementList.size() - 1;
                while (TransVarJ > 0) {
                    Element TransVarElement2 = TransVarElementList.get(TransVarJ);
                    if (StringUtil.in(TransVarElement2.nodeName(), "dd", "dt")) {
                        TransVarTreeBuilder.process(new Token.EndTag(TransVarElement2.nodeName()));
                        break;
                    }
                    if (TransVarTreeBuilder.isSpecial(TransVarElement2) && !StringUtil.in(TransVarElement2.nodeName(), "address", "div", "p")) {
                        break;
                    }
                    TransVarJ--;
                }
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
            } else if (TransVarTagName.equals("plaintext")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.tokeniser.transition(TokeniserState.PLAINTEXT); // once in, never gets out
            } else if (TransVarTagName.equals("button")) {
                if (TransVarTreeBuilder.inButtonScope("button")) {
                    // close and reprocess
                    TransVarTreeBuilder.error(this);
                    TransVarTreeBuilder.process(new Token.EndTag("button"));
                    TransVarTreeBuilder.process(TransVarStartToken);
                } else {
                    TransVarTreeBuilder.reconstructFormattingElements();
                    TransVarTreeBuilder.insert(TransVarStartToken);
                    TransVarTreeBuilder.framesetOk(false);
                }
            } else if (TransVarTagName.equals("a")) {
                if (TransVarTreeBuilder.getActiveFormattingElement("a") != null) {
                    TransVarTreeBuilder.error(this);
                    TransVarTreeBuilder.process(new Token.EndTag("a"));

                    // still on stack?
                    Element TransVarRemainingElement = TransVarTreeBuilder.getFromStack("a");
                    if (TransVarRemainingElement != null) {
                        TransVarTreeBuilder.removeFromActiveFormattingElements(TransVarRemainingElement);
                        TransVarTreeBuilder.removeFromStack(TransVarRemainingElement);
                    }
                }
                TransVarTreeBuilder.reconstructFormattingElements();
                Element TransVarElem = TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.pushActiveFormattingElements(TransVarElem);
            } else if (StringUtil.in(TransVarTagName, "b", "big", "code", "em", "font", "i", "s", "small", "strike", "strong",
                    "tt", "u")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                Element TransVarNewElement = TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.pushActiveFormattingElements(TransVarNewElement);
            } else if (TransVarTagName.equals("nobr")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                if (TransVarTreeBuilder.inScope("nobr")) {
                    TransVarTreeBuilder.error(this);
                    TransVarTreeBuilder.process(new Token.EndTag("nobr"));
                    TransVarTreeBuilder.reconstructFormattingElements();
                }
                Element TransVarNewEl = TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.pushActiveFormattingElements(TransVarNewEl);
            } else if (StringUtil.in(TransVarTagName, "applet", "marquee", "object")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.insertMarkerToFormattingElements();
                TransVarTreeBuilder.framesetOk(false);
            } else if (TransVarTagName.equals("table")) {
                if (TransVarTreeBuilder.getDocument().quirksMode() != Document.QuirksMode.quirks && TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.framesetOk(false);
                TransVarTreeBuilder.transition(InTable);
            } else if (StringUtil.in(TransVarTagName, "area", "br", "embed", "img", "keygen", "wbr")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insertEmpty(TransVarStartToken);
                TransVarTreeBuilder.framesetOk(false);
            } else if (TransVarTagName.equals("input")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                Element TransVarElmnt = TransVarTreeBuilder.insertEmpty(TransVarStartToken);
                if (!TransVarElmnt.attr("type").equalsIgnoreCase("hidden")) {
                    TransVarTreeBuilder.framesetOk(false);
                }
            } else if (StringUtil.in(TransVarTagName, "param", "source", "track")) {
                TransVarTreeBuilder.insertEmpty(TransVarStartToken);
            } else if (TransVarTagName.equals("hr")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.insertEmpty(TransVarStartToken);
                TransVarTreeBuilder.framesetOk(false);
            } else if (TransVarTagName.equals("image")) {
                // we're not supposed to ask.
                TransVarStartToken.name("img");
                return TransVarTreeBuilder.process(TransVarStartToken);
            } else if (TransVarTagName.equals("isindex")) {
                // how much do we care about the early 90s?
                TransVarTreeBuilder.error(this);
                if (TransVarTreeBuilder.getFormElement() != null) {
                    return false;
                }

                TransVarTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
                TransVarTreeBuilder.process(new Token.StartTag("form"));
                if (TransVarStartToken.attributes.hasKey("action")) {
                    Element TransVarFormElement = TransVarTreeBuilder.getFormElement();
                    TransVarFormElement.attr("action", TransVarStartToken.attributes.get("action"));
                }
                TransVarTreeBuilder.process(new Token.StartTag("hr"));
                TransVarTreeBuilder.process(new Token.StartTag("label"));
                // hope you like english.
                String TransVarSearchPrompt = TransVarStartToken.attributes.hasKey("prompt") ?
                        TransVarStartToken.attributes.get("prompt") :
                        "This is a searchable index. Enter search keywords: ";

                TransVarTreeBuilder.process(new Token.Character(TransVarSearchPrompt));

                // input
                Attributes TransVarAttribs = new Attributes();
                for (Attribute TransVarAttributes : TransVarStartToken.attributes) {
                    if (StringUtil.in(TransVarAttributes.getKey(), "name", "action", "prompt")) {
                        TransVarAttribs.put(TransVarAttributes);
                    }
                }
                TransVarAttribs.put("name", "isindex");
                TransVarTreeBuilder.process(new Token.StartTag("input", TransVarAttribs));
                TransVarTreeBuilder.process(new Token.EndTag("label"));
                TransVarTreeBuilder.process(new Token.StartTag("hr"));
                TransVarTreeBuilder.process(new Token.EndTag("form"));
            } else if (TransVarTagName.equals("textarea")) {
                TransVarTreeBuilder.insert(TransVarStartToken);
                // todo: If the next token is a U+000A LINE FEED (LF) character token, then ignore that token and move on to the next one. (Newlines at the start of textarea elements are ignored as an authoring convenience.)
                TransVarTreeBuilder.tokeniser.transition(TokeniserState.Rcdata);
                TransVarTreeBuilder.markInsertionMode();
                TransVarTreeBuilder.framesetOk(false);
                TransVarTreeBuilder.transition(Text);
            } else if (TransVarTagName.equals("xmp")) {
                if (TransVarTreeBuilder.inButtonScope("p")) {
                    TransVarTreeBuilder.process(new Token.EndTag("p"));
                }
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.framesetOk(false);
                handleRawtext(TransVarStartToken, TransVarTreeBuilder);
            } else if (TransVarTagName.equals("iframe")) {
                TransVarTreeBuilder.framesetOk(false);
                handleRawtext(TransVarStartToken, TransVarTreeBuilder);
            } else if (TransVarTagName.equals("noembed")) {
                // also handle noscript if script enabled
                handleRawtext(TransVarStartToken, TransVarTreeBuilder);
            } else if (TransVarTagName.equals("select")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.framesetOk(false);

                TreeBuilderState TransVarParserState = TransVarTreeBuilder.state();
                if (TransVarParserState.equals(InTable) || TransVarParserState.equals(InCaption)
                        || TransVarParserState.equals(InTableBody) || TransVarParserState.equals(InRow)
                        || TransVarParserState.equals(InCell)) {
                    TransVarTreeBuilder.transition(InSelectInTable);
                } else {
                    TransVarTreeBuilder.transition(InSelect);
                }
            } else if (StringUtil.in(TransVarTagName, "optgroup", "option")) {
                if (TransVarTreeBuilder.currentElement().nodeName().equals("option")) {
                    TransVarTreeBuilder.process(new Token.EndTag("option"));
                }
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarStartToken);
            } else if (StringUtil.in(TransVarTagName, "rp", "rt")) {
                if (TransVarTreeBuilder.inScope("ruby")) {
                    TransVarTreeBuilder.generateImpliedEndTags();
                    if (TransVarTreeBuilder.currentElement().nodeName().equals("ruby")) {
                        TransVarTreeBuilder.error(this);
                        TransVarTreeBuilder.popStackToBefore("ruby"); // i.e. close up to but not include name
                    }
                    TransVarTreeBuilder.insert(TransVarStartToken);
                }
            } else if (TransVarTagName.equals("math")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                // todo: handle A start tag whose tag name is "math" (i.e. foreign, mathml)
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
            } else if (TransVarTagName.equals("svg")) {
                TransVarTreeBuilder.reconstructFormattingElements();
                // todo: handle A start tag whose tag name is "svg" (xlink, svg)
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
            } else if (StringUtil.in(TransVarTagName, "caption", "col", "colgroup", "frame", "head", "tbody", "td", "tfoot",
                    "th", "thead", "tr")) {
                TransVarTreeBuilder.error(this);
                return false;
            } else if (StringUtil.in(TransVarTagName, "script", "style")) {
                // Handle raw text for script and style tags
                TransVarTreeBuilder.insert(TransVarStartToken);
                TransVarTreeBuilder.tokeniser.transition(TokeniserState.Rawtext);
                TransVarTreeBuilder.markInsertionMode();
                TransVarTreeBuilder.transition(Text);
            } else {
                TransVarTreeBuilder.reconstructFormattingElements();
                TransVarTreeBuilder.insert(TransVarStartToken);
            }
            break;

        case EndTag:
            Token.EndTag TransVarTokenEndTag = TransVarToken.asEndTag();
            TransVarTagName = TransVarTokenEndTag.name();
            if (TransVarTagName.equals("body")) {
                if (!TransVarTreeBuilder.inScope("body")) {
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    // todo: error if stack contains something not dd, dt, li, optgroup, option, p, rp, rt, tbody, td, tfoot, th, thead, tr, body, html
                    TransVarTreeBuilder.transition(AfterBody);
                }
            } else if (TransVarTagName.equals("html")) {
                boolean TransVarIgnored = TransVarTreeBuilder.process(new Token.EndTag("body"));
                if (!TransVarIgnored) {
                    return TransVarTreeBuilder.process(TransVarTokenEndTag);
                }
            } else if (StringUtil.in(TransVarTagName, "address", "article", "aside", "blockquote", "button", "center",
                    "details", "dir", "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup",
                    "listing", "menu", "nav", "ol", "pre", "section", "summary", "ul")) {
                // todo: refactor these lookups
                if (!TransVarTreeBuilder.inScope(TransVarTagName)) {
                    // nothing to close
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags();
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose(TransVarTagName);
                }
            } else if (TransVarTagName.equals("form")) {
                Element TransVarCurrentFormElement = TransVarTreeBuilder.getFormElement();
                TransVarTreeBuilder.setFormElement(null);
                if (TransVarCurrentFormElement == null || !TransVarTreeBuilder.inScope(TransVarTagName)) {
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags();
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    // remove currentForm from stack. will shift anything under up.
                    TransVarTreeBuilder.removeFromStack(TransVarCurrentFormElement);
                }
            } else if (TransVarTagName.equals("p")) {
                if (!TransVarTreeBuilder.inButtonScope(TransVarTagName)) {
                    TransVarTreeBuilder.error(this);
                    TransVarTreeBuilder.process(new Token.StartTag(TransVarTagName)); // if no p to close, creates an empty <p></p>
                    return TransVarTreeBuilder.process(TransVarTokenEndTag);
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags(TransVarTagName);
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose(TransVarTagName);
                }
            } else if (TransVarTagName.equals("li")) {
                if (!TransVarTreeBuilder.inListItemScope(TransVarTagName)) {
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags(TransVarTagName);
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose(TransVarTagName);
                }
            } else if (StringUtil.in(TransVarTagName, "dd", "dt")) {
                if (!TransVarTreeBuilder.inScope(TransVarTagName)) {
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags(TransVarTagName);
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose(TransVarTagName);
                }
            } else if (StringUtil.in(TransVarTagName, "h1", "h2", "h3", "h4", "h5", "h6")) {
                if (!TransVarTreeBuilder.inScope(new String[]{"h1", "h2", "h3", "h4", "h5", "h6"})) {
                    TransVarTreeBuilder.error(this);
                    return false;
                } else {
                    TransVarTreeBuilder.generateImpliedEndTags(TransVarTagName);
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose("h1", "h2", "h3", "h4", "h5", "h6");
                }
            } else if (TransVarTagName.equals("sarcasm")) {
                // *sigh*
                return anyOtherEndTag(TransVarToken, TransVarTreeBuilder);
            } else if (StringUtil.in(TransVarTagName, "a", "b", "big", "code", "em", "font", "i", "nobr", "s", "small",
                    "strike", "strong", "tt", "u")) {
                // Adoption Agency Algorithm.
                for (int TransVarCounter = 0; TransVarCounter < 8; TransVarCounter++) {
                    Element TransVarFormatElement = TransVarTreeBuilder.getActiveFormattingElement(TransVarTagName);
                    if (TransVarFormatElement == null) {
                        return anyOtherEndTag(TransVarToken, TransVarTreeBuilder);
                    } else if (!TransVarTreeBuilder.onStack(TransVarFormatElement)) {
                        TransVarTreeBuilder.error(this);
                        TransVarTreeBuilder.removeFromActiveFormattingElements(TransVarFormatElement);
                        return true;
                    } else if (!TransVarTreeBuilder.inScope(TransVarFormatElement.nodeName())) {
                        TransVarTreeBuilder.error(this);
                        return false;
                    } else if (TransVarTreeBuilder.currentElement() == TransVarFormatElement) {
                        TransVarTreeBuilder.error(this);
                    }

                    Element TransVarFurthestElement = null;
                    Element TransVarCommonAncestry = null;
                    boolean TransVarSeenFormatting = false;
                    LinkedList<Element> TransVarStackElement = TransVarTreeBuilder.getStack();
                    int TransVarStartElementIndex = 0;
                    while (TransVarStartElementIndex < TransVarStackElement.size()) {
                        Element TransVarEle = TransVarStackElement.get(TransVarStartElementIndex);
                        if (TransVarEle == TransVarFormatElement) {
                            TransVarCommonAncestry = TransVarStackElement.get(TransVarStartElementIndex - 1);
                            TransVarSeenFormatting = true;
                        } else if (TransVarSeenFormatting && TransVarTreeBuilder.isSpecial(TransVarEle)) {
                            TransVarFurthestElement = TransVarEle;
                            break;
                        }
                        TransVarStartElementIndex++;
                    }
                    if (TransVarFurthestElement == null) {
                        TransVarTreeBuilder.popStackToClose(TransVarFormatElement.nodeName());
                        TransVarTreeBuilder.removeFromActiveFormattingElements(TransVarFormatElement);
                        return true;
                    }

                    // Let a bookmark note the position of the formatting element in the list of active formatting elements relative to the elements on either side of it in the list.
                    Element TransVarFurthest = TransVarFurthestElement;
                    Element TransVarLastElem = TransVarFurthestElement;
                    for (int TransVarK = 0; TransVarK < 3; TransVarK++) {
                        if (TransVarTreeBuilder.onStack(TransVarFurthest)) {
                            TransVarFurthest = TransVarTreeBuilder.aboveOnStack(TransVarFurthest);
                        }
                        if (TransVarTreeBuilder.isInActiveFormattingElements(TransVarFurthest)) {
                            TransVarTreeBuilder.removeFromStack(TransVarFurthest);
                            continue;
                        } else if (TransVarFurthest == TransVarFormatElement) {
                            break;
                        }

                        Element TransVarNewElmnt = new Element(Tag.valueOf(TransVarFurthest.nodeName()), TransVarTreeBuilder.getBaseUri());
                        TransVarTreeBuilder.replaceActiveFormattingElement(TransVarFurthest, TransVarNewElmnt);
                        TransVarTreeBuilder.replaceOnStack(TransVarFurthest, TransVarNewElmnt);
                        TransVarFurthest = TransVarNewElmnt;

                        if (TransVarLastElem == TransVarFurthestElement) {
                            // Move the aforementioned bookmark to be immediately after the new node in the list of active formatting elements.
                        }
                        if (TransVarLastElem.parent() != null) {
                            TransVarLastElem.remove();
                        }
                        TransVarFurthest.appendChild(TransVarLastElem);

                        TransVarLastElem = TransVarFurthest;
                    }

                    if (StringUtil.in(TransVarCommonAncestry.nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                        if (TransVarLastElem.parent() != null) {
                            TransVarLastElem.remove();
                        }
                        TransVarTreeBuilder.insertInFosterParent(TransVarLastElem);
                    } else {
                        if (TransVarLastElem.parent() != null) {
                            TransVarLastElem.remove();
                        }
                        TransVarCommonAncestry.appendChild(TransVarLastElem);
                    }

                    Element TransVarAdopter1 = new Element(Tag.valueOf(TransVarTagName), TransVarTreeBuilder.getBaseUri());
                    Node[] TransVarChildren = TransVarFurthestElement.childNodes().toArray(new Node[TransVarFurthestElement.childNodes().size()]);
                    for (Node TransVarChild : TransVarChildren) {
                        TransVarAdopter1.appendChild(TransVarChild); // Append will reparent. Thus the clone to avoid concurrent mod.
                    }
                    TransVarFurthestElement.appendChild(TransVarAdopter1);
                    TransVarTreeBuilder.removeFromActiveFormattingElements(TransVarFormatElement);
                    // Insert the new element into the list of active formatting elements at the position of the aforementioned bookmark.
                    TransVarTreeBuilder.removeFromStack(TransVarFormatElement);
                    TransVarTreeBuilder.insertOnStackAfter(TransVarFurthestElement, TransVarAdopter1);
                }
            } else if (StringUtil.in(TransVarTagName, "applet", "marquee", "object")) {
                if (TransVarTreeBuilder.inScope("name")) {
                    if (TransVarTreeBuilder.inScope(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                        return false;
                    }
                    TransVarTreeBuilder.generateImpliedEndTags();
                    if (TransVarTreeBuilder.currentElement().nodeName().equals(TransVarTagName)) {
                        TransVarTreeBuilder.error(this);
                    }
                    TransVarTreeBuilder.popStackToClose(TransVarTagName);
                    TransVarTreeBuilder.clearFormattingElementsToLastMarker();
                }
            } else if (TransVarTagName.equals("br")) {
                TransVarTreeBuilder.error(this);
                TransVarTreeBuilder.process(new Token.StartTag("br"));
                return false;
            } else {
                return anyOtherEndTag(TransVarToken, TransVarTreeBuilder);
            }

            break;
        case EOF:
            // todo: error if stack contains something not dd, dt, li, p, tbody, td, tfoot, th, thead, tr, body, html
            // stop parsing
            break;
    }
    return true;
}