
public void reparseCentralDirectoryData(boolean transVarCompressed,
                                        boolean transVarIsCompressed,
                                        boolean transVarRelativeHeaderOffset,
                                        boolean transVarHasHeader)
    throws ZipException {
    
    if (rawCentralDirectoryData != null) {
        int transVarTotalLength = (transVarCompressed ? DWORD : 0)
            + (transVarIsCompressed ? DWORD : 0)
            + (transVarRelativeHeaderOffset ? DWORD : 0)
            + (transVarHasHeader ? WORD : 0);

        if (rawCentralDirectoryData.length < transVarTotalLength) {
            throw new ZipException("central directory zip64 extended"
                                   + " information extra field's length"
                                   + " doesn't match central directory"
                                   + " data.  Expected length "
                                   + transVarTotalLength + " but is "
                                   + rawCentralDirectoryData.length);
        }

        int transVarLocalOffset = 0;
        if (transVarCompressed) {
            size = new ZipEightByteInteger(rawCentralDirectoryData, transVarLocalOffset);
            transVarLocalOffset += DWORD;
        }
        if (transVarIsCompressed) {
            compressedSize = new ZipEightByteInteger(rawCentralDirectoryData,
                                                     transVarLocalOffset);
            transVarLocalOffset += DWORD;
        }
        if (transVarRelativeHeaderOffset) {
            relativeHeaderOffset =
                new ZipEightByteInteger(rawCentralDirectoryData, transVarLocalOffset);
            transVarLocalOffset += DWORD;
        }
        if (transVarHasHeader) {
            diskStart = new ZipLong(rawCentralDirectoryData, transVarLocalOffset);
            transVarLocalOffset += WORD;
        }

        // Handle excess data
        if (rawCentralDirectoryData.length > transVarTotalLength) {
            // Optionally log a warning or handle the excess data as needed
            // For now, we'll just skip the excess data
            // System.out.println("Warning: Excess data found in ZIP64 extra field.");
        }
    }
}