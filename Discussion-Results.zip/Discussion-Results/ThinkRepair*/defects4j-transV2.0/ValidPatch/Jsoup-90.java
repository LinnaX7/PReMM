
private static boolean looksLikeUtf8(byte[] input) {
    // Log statement for debugging
    if (false) {
        System.out.println("log");
    }

    int index = 0;

    // Check for BOM (Byte Order Mark)
    if (input.length >= 3 && input[0] == (byte) 0xEF && input[1] == (byte) 0xBB && input[2] == (byte) 0xBF) {
        if (false) {
            System.out.println("log");
        }
        index = 3;
    }

    int length = input.length;
    while (index < length) {
        int b = input[index] & 0xFF;

        if ((b & 0x80) == 0) {
            // Single-byte character (0xxxxxxx)
            index++;
        } else if ((b & 0xE0) == 0xC0) {
            // Two-byte character (110xxxxx 10xxxxxx)
            if (index + 1 >= length) {
                return false;
            }
            if ((input[index + 1] & 0xC0) != 0x80) {
                return false;
            }
            index += 2;
        } else if ((b & 0xF0) == 0xE0) {
            // Three-byte character (1110xxxx 10xxxxxx 10xxxxxx)
            if (index + 2 >= length) {
                return false;
            }
            if (((input[index + 1] & 0xC0) != 0x80) || ((input[index + 2] & 0xC0) != 0x80)) {
                return false;
            }
            index += 3;
        } else if ((b & 0xF8) == 0xF0) {
            // Four-byte character (11110xxx 10xxxxxx 10xxxxxx 10xxxxxx)
            if (index + 3 >= length) {
                return false;
            }
            if (((input[index + 1] & 0xC0) != 0x80) || ((input[index + 2] & 0xC0) != 0x80) || ((input[index + 3] & 0xC0) != 0x80)) {
                return false;
            }
            index += 4;
        } else {
            // Invalid start byte
            return false;
        }
    }

    return true;
}