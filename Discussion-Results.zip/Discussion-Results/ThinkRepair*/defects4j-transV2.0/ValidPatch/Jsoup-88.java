
public String getValue() {
    // Ensure val is initialized to avoid potential NullPointerException
    if (val == null) {
        val = ""; // or any default value you prefer
    }

    // Removed the redundant condition
    System.out.println("log");

    return val;
}