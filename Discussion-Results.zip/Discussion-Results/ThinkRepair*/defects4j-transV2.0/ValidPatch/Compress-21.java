
private void writeBits(final DataOutput transVarDataHeader, final BitSet transVarDataBitSet, final int transVarSize) throws IOException {
    int cacheLength = 0;
    int shiftLength = 7;
    int item = 0;

    while (item < transVarSize) {
        cacheLength |= (transVarDataBitSet.get(item) ? 1 : 0) << shiftLength;
        shiftLength--;
        if (shiftLength == -1) { // When shiftLength reaches -1, it means the byte is full
            transVarDataHeader.write(cacheLength);
            shiftLength = 7; // Reset shiftLength to 7 for the next byte
            cacheLength = 0; // Reset cacheLength for the next byte
        }
        item++;
    }

    if (shiftLength != 7) { // Write the remaining bits if there are any left
        transVarDataHeader.write(cacheLength);
    }
}