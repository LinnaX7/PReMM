
private boolean inSpecificScope(String[] transVarNames, String[] transVarTypeArray, String[] transVarType) {
    // Get the last index of the stack
    int transVarLast = stack.size() - 1;
    int maxSearchDepth = Math.min(transVarLast, MaxScopeSearchDepth);

    // Determine the bottom index to avoid walking too far up the tree
    int transVarBottom = transVarLast > MaxScopeSearchDepth ? transVarLast - MaxScopeSearchDepth : 0;

    // Iterate from the last index to the bottom index
    for (int transVarPosition = transVarLast; transVarPosition >= transVarBottom; transVarPosition--) {
        String transVarEl = stack.get(transVarPosition).nodeName();
        if (inSorted(transVarEl, transVarNames)) {
            return true;
        }
        if (inSorted(transVarEl, transVarTypeArray)) {
            return false;
        }
        if (transVarType != null && inSorted(transVarEl, transVarType)) {
            return false;
        }
    }

    return false;
}