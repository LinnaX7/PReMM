
static Document parseByteData(ByteBuffer transVarByteBuffer, String transVarCharset, String transVarBasePath, Parser transVarParser1) {
    System.out.println("log");

    String transVarLocalDocData;
    Document transVarDocument = null;

    // Check for UTF-8 BOM early in the process
    if (transVarByteBuffer.remaining() >= 3 && transVarByteBuffer.get(0) == (byte) 0xEF && transVarByteBuffer.get(1) == (byte) 0xBB && transVarByteBuffer.get(2) == (byte) 0xBF) {
        transVarByteBuffer.position(3); // Skip the BOM
        transVarLocalDocData = Charset.forName(defaultCharset).decode(transVarByteBuffer).toString();
        transVarCharset = defaultCharset;
    } else {
        if (transVarCharset == null) { // determine from meta. safe parse as UTF-8
            System.out.println("log");

            // look for <meta http-equiv="Content-Type" content="text/html;charset=gb2312"> or HTML5 <meta charset="gb2312">
            transVarLocalDocData = Charset.forName(defaultCharset).decode(transVarByteBuffer).toString();
            transVarDocument = transVarParser1.parseInput(transVarLocalDocData, transVarBasePath);

            Element transVarPageInfo = transVarDocument.select("meta[http-equiv=content-type], meta[charset]").first();
            if (transVarPageInfo != null) { // if not found, will keep utf-8 as best attempt
                System.out.println("log");

                String transVarFoundCharset1;
                if (transVarPageInfo.hasAttr("http-equiv")) {
                    transVarFoundCharset1 = getCharsetFromContentType(transVarPageInfo.attr("content"));
                    if (transVarFoundCharset1 == null && transVarPageInfo.hasAttr("charset")) {
                        try {
                            if (Charset.isSupported(transVarPageInfo.attr("charset"))) {
                                transVarFoundCharset1 = transVarPageInfo.attr("charset");
                            }
                        } catch (IllegalCharsetNameException ex) {
                            transVarFoundCharset1 = null;
                        }
                    }
                } else {
                    transVarFoundCharset1 = transVarPageInfo.attr("charset");
                }

                if (transVarFoundCharset1 != null && !transVarFoundCharset1.isEmpty() && !transVarFoundCharset1.equals(defaultCharset)) { // need to re-decode
                    transVarFoundCharset1 = transVarFoundCharset1.trim().replaceAll("[\"']", "");
                    transVarCharset = transVarFoundCharset1;
                    transVarByteBuffer.rewind();
                    transVarLocalDocData = Charset.forName(transVarFoundCharset1).decode(transVarByteBuffer).toString();
                    transVarDocument = null;
                }
            }
        } else { // specified by content type header (or by user on file load)
            Validate.notEmpty(transVarCharset, "Must set charset arg to character set of file to parse. Set to null to attempt to detect from HTML");
            transVarLocalDocData = Charset.forName(transVarCharset).decode(transVarByteBuffer).toString();
        }
    }

    if (transVarDocument == null) {
        transVarDocument = transVarParser1.parseInput(transVarLocalDocData, transVarBasePath);
        transVarDocument.outputSettings().charset(transVarCharset);
    }

    return transVarDocument;
}