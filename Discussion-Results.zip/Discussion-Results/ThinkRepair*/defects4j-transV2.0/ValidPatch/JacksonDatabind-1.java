
public void serializeAsColumn(Object transVarBean1, JsonGenerator transVarBean, SerializerProvider transVarSerializer)
    throws Exception
{
    if (false) {
        System.out.println("log");
    }
    Object transVarObj = get(transVarBean1);
    if (transVarObj == null) { // nulls need specialized handling
        if (false) {
            System.out.println("log");
        }
        if (_nullSerializer != null) {
            if (false) {
                System.out.println("log");
            }
            _nullSerializer.serialize(null, transVarBean, transVarSerializer);
        } else { // can NOT suppress entries in tabular output
            transVarBean.writeNull();
        }
    } else {
        // otherwise find serializer to use
        JsonSerializer<Object> transVarJsonSerializer = _serializer;
        if (transVarJsonSerializer == null) {
            Class<?> transVarClass1 = transVarObj.getClass();
            PropertySerializerMap transVarSerializerMap = _dynamicSerializers;
            transVarJsonSerializer = transVarSerializerMap.serializerFor(transVarClass1);
            if (transVarJsonSerializer == null) {
                transVarJsonSerializer = _findAndAddDynamic(transVarSerializerMap, transVarClass1, transVarSerializer);
            }
        }
        // and then see if we must suppress certain values (default, empty)
        if (_suppressableValue != null) {
            if (MARKER_FOR_EMPTY == _suppressableValue) {
                if (!transVarJsonSerializer.isEmpty(transVarObj)) { // can NOT suppress entries in tabular output
                    serializeAsPlaceholder(transVarBean1, transVarBean, transVarSerializer);
                    return;
                }
            } else if (_suppressableValue.equals(transVarObj)) { // can NOT suppress entries in tabular output
                serializeAsPlaceholder(transVarBean1, transVarBean, transVarSerializer);
                return;
            }
        }
        // For non-nulls: simple check for direct cycles
        if (transVarObj == transVarBean1) {
            _handleSelfReference(transVarBean1, transVarJsonSerializer);
        }
        if (_typeSerializer == null) {
            transVarJsonSerializer.serialize(transVarObj, transVarBean, transVarSerializer);
        } else {
            transVarJsonSerializer.serializeWithType(transVarObj, transVarBean, transVarSerializer, _typeSerializer);
        }
    }
}