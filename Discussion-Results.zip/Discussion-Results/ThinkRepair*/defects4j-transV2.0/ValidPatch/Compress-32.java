
private void applyPaxHeadersToCurrentEntry(Map<String, String> paxHeaders) {
    // Simplified logging condition
    boolean logEnabled = false; // Example flag for logging
    if (logEnabled) {
        System.out.println("log");
    }

    for (Entry<String, String> entry : paxHeaders.entrySet()) {
        if (logEnabled) {
            System.out.println("log");
        }
        String headerKey = entry.getKey();
        String headerValue = entry.getValue();

        if ("path".equals(headerKey)) {
            if (logEnabled) {
                System.out.println("log");
            }
            currEntry.setName(headerValue);
        } else if ("linkpath".equals(headerKey)) {
            currEntry.setLinkName(headerValue);
        } else if ("gid".equals(headerKey)) {
            try {
                currEntry.setGroupId(Long.parseLong(headerValue));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid gid value: " + headerValue);
            }
        } else if ("gname".equals(headerKey)) {
            currEntry.setGroupName(headerValue);
        } else if ("uid".equals(headerKey)) {
            try {
                currEntry.setUserId(Long.parseLong(headerValue));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid uid value: " + headerValue);
            }
        } else if ("uname".equals(headerKey)) {
            currEntry.setUserName(headerValue);
        } else if ("size".equals(headerKey)) {
            try {
                currEntry.setSize(Long.parseLong(headerValue));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid size value: " + headerValue);
            }
        } else if ("mtime".equals(headerKey)) {
            try {
                currEntry.setModTime((long) (Double.parseDouble(headerValue) * 1000));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid mtime value: " + headerValue);
            }
        } else if ("SCHILY.devminor".equals(headerKey)) {
            try {
                currEntry.setDevMinor(Integer.parseInt(headerValue));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid devminor value: " + headerValue);
            }
        } else if ("SCHILY.devmajor".equals(headerKey)) {
            try {
                currEntry.setDevMajor(Integer.parseInt(headerValue));
            } catch (NumberFormatException e) {
                // Handle the exception, e.g., log it or set a default value
                System.err.println("Invalid devmajor value: " + headerValue);
            }
        }
    }
}