
protected String buildCanonicalName() {
    // Simplified logging statement (optional)
    System.out.println("log");

    StringBuilder TransVarBuilder = new StringBuilder();
    TransVarBuilder.append(_class.getName());
    TransVarBuilder.append('<');
    TransVarBuilder.append(_referencedType.toCanonical());
    TransVarBuilder.append('>'); // Add the closing angle bracket

    return TransVarBuilder.toString();
}