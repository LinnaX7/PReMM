
public KeyDeserializer createKeyDeserializer(DeserializationContext deserializationContext, JavaType typeObject)
    throws JsonMappingException
{
    final DeserializationConfig config = deserializationContext.getConfig();
    KeyDeserializer keyDeserializer = null;

    // Check if the factory configuration has key deserializers
    if (_factoryConfig.hasKeyDeserializers()) {
        BeanDescription description = config.introspectClassAnnotations(typeObject.getRawClass());
        for (KeyDeserializers keyDeserializers : _factoryConfig.keyDeserializers()) {
            keyDeserializer = keyDeserializers.findKeyDeserializer(typeObject, config, description);
            if (keyDeserializer != null) {
                System.out.println("Found key deserializer from factory: " + keyDeserializer.getClass().getName());
                break;
            }
        }
    }

    // Handle enum types
    if (keyDeserializer == null) {
        if (typeObject.isEnumType()) {
            keyDeserializer = _createEnumKeyDeserializer(deserializationContext, typeObject);
            System.out.println("Created enum key deserializer: " + keyDeserializer.getClass().getName());
        } else {
            keyDeserializer = StdKeyDeserializers.findStringBasedKeyDeserializer(config, typeObject);
            System.out.println("Created string-based key deserializer: " + keyDeserializer.getClass().getName());
        }
    }

    // Post-processing
    if (keyDeserializer != null && _factoryConfig.hasDeserializerModifiers()) {
        for (BeanDeserializerModifier modifier : _factoryConfig.deserializerModifiers()) {
            keyDeserializer = modifier.modifyKeyDeserializer(config, typeObject, keyDeserializer);
            System.out.println("Modified key deserializer by: " + modifier.getClass().getName() + " to: " + keyDeserializer.getClass().getName());
        }
    }

    return keyDeserializer;
}