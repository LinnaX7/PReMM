
public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper TransVarJsonVisitor, JavaType TransVarTypeHintVisitor) throws JsonMappingException {
    if (_isInt) {
        visitIntFormat(TransVarJsonVisitor, TransVarTypeHintVisitor, JsonParser.NumberType.BIG_INTEGER);
    } else {
        Class<?> TransVarT = handledType();
        if (TransVarT == BigDecimal.class) {
            visitFloatFormat(TransVarJsonVisitor, TransVarTypeHintVisitor, JsonParser.NumberType.BIG_DECIMAL);
        } else {
            TransVarJsonVisitor.expectNumberFormat(TransVarTypeHintVisitor);
        }
    }
}