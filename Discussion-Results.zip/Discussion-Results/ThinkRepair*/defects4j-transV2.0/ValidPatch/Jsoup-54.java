
private void copyAttributes(org.jsoup.nodes.Node transVarHtml, Element transVarElement) {
    // Simplify and remove redundant log conditions
    for (Attribute transVarAttr : transVarHtml.attributes()) {
        // Sanitize the attribute name to conform to XML standards
        String transVarAttributeName = transVarAttr.getKey();
        transVarAttributeName = transVarAttributeName.replaceAll("^[^a-zA-Z_:]", "_").replaceAll("[^-a-zA-Z0-9_:.]", "");

        // Set the sanitized attribute name and value
        transVarElement.setAttribute(transVarAttributeName, transVarAttr.getValue());
    }
}