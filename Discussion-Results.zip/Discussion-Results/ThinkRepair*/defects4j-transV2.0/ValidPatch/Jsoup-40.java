
public DocumentType(String TransVarPerson, String TransVarPersonId, String TransVarPersonNumber, String TransVarUri) {
    super(TransVarUri);

    // Skip validation if TransVarPerson is null or empty
    if (TransVarPerson != null && !TransVarPerson.isEmpty()) {
        Validate.notEmpty(TransVarPerson);
        attr("name", TransVarPerson);
    } else {
        // Optionally, you can log a warning or handle it as needed
        // System.out.println("TransVarPerson is null or empty, skipping validation.");
    }

    attr("publicId", TransVarPersonId);
    attr("systemId", TransVarPersonNumber);
}