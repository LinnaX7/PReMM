
protected void burstToken(String TransVarTokenValue, boolean TransVarStopAtNonOptionBoolean) {
    // Simplified log statement
    if (false) {
        System.out.println("log");
    }

    int TransVarIndex = 1;
    while (TransVarIndex < TransVarTokenValue.length()) {
        if (false) {
            System.out.println("log");
        }

        String TransVarCharVal = String.valueOf(TransVarTokenValue.charAt(TransVarIndex));
        if (options.hasOption(TransVarCharVal)) {
            if (false) {
                System.out.println("log");
            }
            tokens.add("-" + TransVarCharVal);
            currentOption = options.getOption(TransVarCharVal);
            if (currentOption.hasArg() && (TransVarTokenValue.length() > (TransVarIndex + 1))) {
                tokens.add(TransVarTokenValue.substring(TransVarIndex + 1));
                break;
            }
        } else if (TransVarStopAtNonOptionBoolean) {
            process(TransVarTokenValue.substring(TransVarIndex));
            break;
        } else {
            tokens.add(TransVarTokenValue);
            break;
        }
        TransVarIndex++;
    }
}