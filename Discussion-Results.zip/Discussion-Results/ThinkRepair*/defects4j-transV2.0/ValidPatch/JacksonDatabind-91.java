
private boolean _hasCustomHandlers(JavaType transVarType) {
    if (true) { // Simplified from !(!(false))
        System.out.println("log");
    }
    if (transVarType.isContainerType()) {
        if (true) { // Simplified from !(!(false))
            System.out.println("log");
        }
        // First: value types may have both value and type handlers
        JavaType transVarCtType = transVarType.getContentType();
        if (transVarCtType != null) {
            if (true) { // Simplified from !(!(false))
                System.out.println("log");
            }
            if (transVarCtType.getValueHandler() != null || transVarCtType.getTypeHandler() != null) {
                return true;
            }
        }
        // Second: map(-like) types may have value handler for key (but not type; keys are untyped)
        if (transVarType.isMapLikeType()) {
            JavaType keyType = transVarType.getKeyType();
            if (keyType != null && keyType.getValueHandler() != null) {
                return true;
            }
        }
    }
    return false;
}