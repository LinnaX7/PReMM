
private void printAndQuote(final Object TransVarObject1, final CharSequence TransVarString, final int TransVarOffsetBytes, final int TransVarBytes,
        final Appendable TransVarOutput, final boolean TransVarNewFile) throws IOException {
    boolean TransVarQuoteStr = false;
    int TransVarOffset = TransVarOffsetBytes;
    int TransVarPosition = TransVarOffsetBytes;
    final int TransVarEndIndex = TransVarOffsetBytes + TransVarBytes;

    final char TransVarDelimiter = getDelimiter();
    final char TransVarQuote = getQuoteCharacter().charValue();

    QuoteMode TransVarQuoteMode = getQuoteMode();
    if (TransVarQuoteMode == null) {
        TransVarQuoteMode = QuoteMode.MINIMAL;
    }

    switch (TransVarQuoteMode) {
        case ALL:
        case ALL_NON_NULL:
            TransVarQuoteStr = true;
            break;
        case NON_NUMERIC:
            TransVarQuoteStr = !(TransVarObject1 instanceof Number);
            break;
        case NONE:
            // Use the existing escaping code
            printAndEscape(TransVarString, TransVarOffsetBytes, TransVarBytes, TransVarOutput);
            return;
        case MINIMAL:
            if (TransVarBytes <= 0) {
                if (TransVarNewFile) {
                    TransVarQuoteStr = true;
                }
            } else {
                char TransVarCh = TransVarString.charAt(TransVarPosition);

                if (TransVarNewFile && (TransVarCh < 0x20 || (TransVarCh > 0x21 && TransVarCh < 0x23) || (TransVarCh > 0x2B && TransVarCh < 0x2D) || (TransVarCh > 0x7E && TransVarCh != 0x20AC))) {
                    TransVarQuoteStr = true;
                } else if (TransVarCh <= COMMENT) {
                    TransVarQuoteStr = true;
                } else {
                    for (; TransVarPosition < TransVarEndIndex; TransVarPosition++) {
                        TransVarCh = TransVarString.charAt(TransVarPosition);
                        if (TransVarCh == LF || TransVarCh == CR || TransVarCh == TransVarQuote || TransVarCh == TransVarDelimiter) {
                            TransVarQuoteStr = true;
                            break;
                        }
                    }

                    if (!TransVarQuoteStr) {
                        TransVarPosition = TransVarEndIndex - 1;
                        TransVarCh = TransVarString.charAt(TransVarPosition);
                        if (TransVarCh <= SP) {
                            TransVarQuoteStr = true;
                        }
                    }
                }
            }

            if (!TransVarQuoteStr) {
                // No encapsulation needed - write out the original value
                TransVarOutput.append(TransVarString, TransVarOffset, TransVarEndIndex);
                return;
            }
            break;
        default:
            throw new IllegalStateException("Unexpected Quote value: " + TransVarQuoteMode);
    }

    if (!TransVarQuoteStr) {
        // No encapsulation needed - write out the original value
        TransVarOutput.append(TransVarString, TransVarOffset, TransVarEndIndex);
        return;
    }

    // We hit something that needed encapsulation
    TransVarOutput.append(TransVarQuote);

    for (; TransVarPosition < TransVarEndIndex; TransVarPosition++) {
        final char TransVarCharac = TransVarString.charAt(TransVarPosition);
        if (TransVarCharac == TransVarQuote) {
            TransVarOutput.append(TransVarString, TransVarOffset, TransVarPosition + 1);
            TransVarOffset = TransVarPosition;
        }
    }

    // Write the last segment
    TransVarOutput.append(TransVarString, TransVarOffset, TransVarPosition);
    TransVarOutput.append(TransVarQuote);
}