
@Override
public final <T extends AccountancyEntry> T add(T accountancyEntry) {

    Assert.notNull(accountancyEntry, "Accountancy entry must not be null!");

    // Ensure businessTime is not null
    if (businessTime == null) {
        throw new IllegalStateException("Business time must be set before adding an accountancy entry.");
    }

    // Ensure repository is not null
    if (repository == null) {
        throw new IllegalStateException("Repository must be set before adding an accountancy entry.");
    }

    // Set date if not already set
    if (!accountancyEntry.hasDate()) {
        accountancyEntry.setDate(businessTime.getTime());
    }

    // Check for duplicate entries
    if (repository.existsById(accountancyEntry.getId())) {
        throw new IllegalArgumentException("An accountancy entry with the same ID already exists.");
    }

    // Save the accountancy entry to the repository
    return repository.save(accountancyEntry);
}