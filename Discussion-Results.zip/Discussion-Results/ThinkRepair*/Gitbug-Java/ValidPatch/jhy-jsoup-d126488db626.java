
private String consumeSubQuery() {
    StringBuilder sq = StringUtil.borrowBuilder();
    while (!tq.isEmpty()) {
        if (tq.matches("(")) {
            sq.append("(").append(tq.chompBalanced('(', ')')).append(")");
        } else if (tq.matches("[")) {
            sq.append("[").append(tq.chompBalanced('[', ']')).append("]");
        } else if (tq.matchesAny(Combinators)) {
            if (sq.length() > 0) {
                break; // Stop consuming if a combinator is found and we have a valid subquery
            } else {
                sq.append(tq.consume()); // Consume the combinator if the subquery is empty
            }
        } else {
            sq.append(tq.consume());
        }
    }
    return StringUtil.releaseBuilder(sq);
}