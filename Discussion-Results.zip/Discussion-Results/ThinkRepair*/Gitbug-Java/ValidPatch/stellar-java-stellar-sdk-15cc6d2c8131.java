
@Override
public boolean equals(Object object) {
    if (this == object) {
        return true;
    }
    if (!(object instanceof KeyPair)) {
        return false;
    }

    KeyPair other = (KeyPair) object;
    // Check if both private keys are null or both are non-null and equal
    boolean privateKeyEqual = (this.mPrivateKey == null) ? (other.mPrivateKey == null) : this.mPrivateKey.equals(other.mPrivateKey);
    // Check if both public keys are null or both are non-null and equal
    boolean publicKeyEqual = (this.mPublicKey == null) ? (other.mPublicKey == null) : this.mPublicKey.equals(other.mPublicKey);

    return privateKeyEqual && publicKeyEqual;
}