
public String getString(String key, String defaultValue) {
    if (attributes.containsKey(key)) {
        Object value = attributes.get(key); // Fixed Line
        return value != null ? value.toString() : null;
    } else {
        return defaultValue;
    }
}