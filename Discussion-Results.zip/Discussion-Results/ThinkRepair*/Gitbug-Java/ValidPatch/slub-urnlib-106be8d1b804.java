
private String initialToString() {
    StringBuilder sb = new StringBuilder();
    
    if (!resolutionParameters.isEmpty()) {
        sb.append("?+");
        boolean firstPair = true;
        for (Map.Entry<String, String> kv : resolutionParameters.entrySet()) {
            if (!firstPair) {
                sb.append('&'); // Add '&' between key-value pairs
            }
            sb.append(kv.getKey()).append('=').append(kv.getValue());
            firstPair = false;
        }
    }
    
    if (!queryParameters.isEmpty()) {
        sb.append("?=");
        boolean firstPair = true;
        for (Map.Entry<String, String> kv : queryParameters.entrySet()) {
            if (!firstPair) {
                sb.append('&'); // Add '&' between key-value pairs
            }
            sb.append(kv.getKey()).append('=').append(kv.getValue());
            firstPair = false;
        }
    }
    
    if (!fragment.isEmpty()) {
        sb.append('#').append(fragment);
    }
    
    return sb.toString();
}