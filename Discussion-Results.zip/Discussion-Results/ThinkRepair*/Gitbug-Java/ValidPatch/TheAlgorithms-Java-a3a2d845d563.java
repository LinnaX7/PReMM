
public boolean isArmstrong(int number) {
    if (number < 0) {
        return false; // Armstrong numbers are non-negative
    }

    // Convert the number to a string to count the number of digits
    String numberStr = Integer.toString(number);
    int numDigits = numberStr.length();

    // Initialize sum and a copy of the number
    long sum = 0;
    long tempNumber = number;

    // Calculate the sum of digits each raised to the power of numDigits
    while (tempNumber > 0) {
        long digit = tempNumber % 10;
        sum += Math.pow(digit, numDigits);
        tempNumber /= 10;
    }

    // Check if the sum is equal to the original number
    return sum == number;
}