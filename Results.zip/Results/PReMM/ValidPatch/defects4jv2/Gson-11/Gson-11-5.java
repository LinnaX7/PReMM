public Number read(JsonReader in) throws IOException {
  JsonToken jsonToken = in.peek();
  switch (jsonToken) {
  case NULL:
    in.nextNull();
    return null;
  case NUMBER:
    String numberStr = in.nextString();
    try {
      return Integer.parseInt(numberStr);
    } catch (NumberFormatException e) {
      return new LazilyParsedNumber(numberStr);
    }
  case STRING:
    String str = in.nextString();
    try {
      return Integer.parseInt(str);
    } catch (NumberFormatException e) {
      return new LazilyParsedNumber(str);
    }
  default:
    throw new JsonSyntaxException("Expecting number, got: " + jsonToken);
  }
}