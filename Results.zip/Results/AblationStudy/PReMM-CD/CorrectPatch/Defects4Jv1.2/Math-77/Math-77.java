public double getLInfNorm() {
    double max = 0;
    Iterator iter = entries.iterator();
    while (iter.hasNext()) {
        iter.advance();
        double absValue = Math.abs(iter.value());
        if (absValue > max) {
            max = absValue;
        }
    }
    return max;
}@Override
public double getLInfNorm() {
    double max = 0;
    for (double a : data) {
        double absValue = Math.abs(a);
        if (absValue > max) {
            max = absValue;
        }
    }
    return max;
}