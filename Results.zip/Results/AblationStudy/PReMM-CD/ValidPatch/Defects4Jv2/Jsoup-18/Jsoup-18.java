CharacterReader(String input) {
    Validate.notNull(input);

    this.input = input.replace("\r\n", "\n").replace("\r", "\n");
    this.length = this.input.length();
}String consumeToEnd() {
    String data = input.substring(pos, input.length());
    pos = input.length();
    return data;
}