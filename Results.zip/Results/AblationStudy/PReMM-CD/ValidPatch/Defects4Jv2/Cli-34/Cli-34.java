private static void reset()
{
    description = null;
    argName = null;
    longopt = null;
    type = String.class; // Set a default type
    required = false;
    numberOfArgs = Option.UNINITIALIZED;
    optionalArg = false;
    valuesep = (char) 0;
}