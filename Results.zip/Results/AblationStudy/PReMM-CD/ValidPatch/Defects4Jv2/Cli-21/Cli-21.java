public boolean looksLikeOption(final String trigger) {
    // this is a reentrant call

    for (final Iterator<String> i = prefixes.iterator(); i.hasNext();) {
        final String prefix = i.next();

        if (trigger.startsWith(prefix)) {
            // Check if the trigger is just a prefix followed by a number
            if (trigger.matches("^-\\d+")) {
                return false;
            }
            return true;
        }
    }
    return false;
}private boolean looksLikeOption(final WriteableCommandLine commandLine, final String trigger) {
    return commandLine.looksLikeOption(trigger);
}