private static ZipLong unixTimeToZipLong(long l) {
    final long MAX_TIME_SECONDS = 0x7FFFFFFFL; // 2^31 - 1
    if (l > MAX_TIME_SECONDS) {
        throw new IllegalArgumentException("X5455 timestamps must fit in a signed 32 bit integer: " + l);
    }
    return new ZipLong(l);
}