public ZipArchiveEntry(String name) {
    super(name);
    // Ensure that the name is not null
    if (name == null) {
        throw new IllegalArgumentException("Name cannot be null");
    }
    this.name = name;
}public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }
    ZipArchiveEntry other = (ZipArchiveEntry) obj;
    if (name == null) {
        if (other.name != null) {
            return false;
        }
    } else if (!name.equals(other.name)) {
        return false;
    }
    return true;
}