    public DocumentType(String name, String publicId, String systemId, String baseUri) {
        super(baseUri);

        // Allow empty or null name
        if (name != null && !name.isEmpty()) {
            attr("name", name);
        }
        attr("publicId", publicId);
        attr("systemId", systemId);
    }