public static Number createNumber(String str)
{
    try
    {
        // Check if the string contains a decimal point
        if (str.contains(".")) {
            return Double.parseDouble(str);
        } else {
            // Use NumberUtils.createNumber for other cases
            return org.apache.commons.lang.math.NumberUtils.createNumber(str);
        }
    }
    catch (NumberFormatException nfe)
    {
        System.err.println(nfe.getMessage());
    }

    return null;
}
