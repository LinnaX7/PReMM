
@Override
public KeyDeserializer createKeyDeserializer(DeserializationContext ctxt,
        JavaType type)
    throws JsonMappingException
{
    final DeserializationConfig config = ctxt.getConfig();
    KeyDeserializer deser = null;

    if (_factoryConfig.hasKeyDeserializers()) {
        BeanDescription beanDesc = config.introspectClassAnnotations(type.getRawClass());
        for (KeyDeserializers d : _factoryConfig.keyDeserializers()) {
            deser = d.findKeyDeserializer(type, config, beanDesc);
            if (deser != null) {
                break;
            }
        }
    }

    // Check if a custom KeyDeserializer is provided by a BeanDeserializerModifier
    if (deser == null && _factoryConfig.hasDeserializerModifiers()) {
        for (BeanDeserializerModifier mod : _factoryConfig.deserializerModifiers()) {
            KeyDeserializer customDeser = mod.modifyKeyDeserializer(config, type, null);
            if (customDeser != null) {
                deser = customDeser;
                break;
            }
        }
    }

    // Fallback to default KeyDeserializer if no custom one is found
    if (deser == null) {
        if (type.isEnumType()) {
            deser = _createEnumKeyDeserializer(ctxt, type);
        } else {
            deser = StdKeyDeserializers.findStringBasedKeyDeserializer(config, type);
        }
    }

    // Post-processing
    if (deser != null && _factoryConfig.hasDeserializerModifiers()) {
        for (BeanDeserializerModifier mod : _factoryConfig.deserializerModifiers()) {
            deser = mod.modifyKeyDeserializer(config, type, deser);
        }
    }

    return deser;
}