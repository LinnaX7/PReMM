    public void removeIgnoreCase(String key) {
        Validate.notEmpty(key);
        if (attributes == null)
            return;
        Iterator<Map.Entry<String, Attribute>> it = attributes.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Attribute> entry = it.next();
            if (entry.getKey().equalsIgnoreCase(key)) {
                it.remove();
            }
        }
    }