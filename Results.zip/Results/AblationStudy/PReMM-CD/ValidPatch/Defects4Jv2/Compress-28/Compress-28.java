    @Override
    public int read(byte[] buf, int offset, int numToRead) throws IOException {
        int totalRead = 0;

        if (hasHitEOF || entryOffset >= entrySize) {
            return -1;
        }

        if (currEntry == null) {
            throw new IllegalStateException("No current tar entry");
        }

        numToRead = Math.min(numToRead, available());

        while (numToRead > 0 && !hasHitEOF) {
            int read = is.read(buf, offset, numToRead);
            if (read == -1) {
                hasHitEOF = true;
                if (entryOffset < entrySize) {
                    throw new IOException("Truncated tar entry");
                }
                break;
            }
            totalRead += read;
            numToRead -= read;
            offset += read;
            entryOffset += read;
            count(read);
        }

        return totalRead == 0 && hasHitEOF ? -1 : totalRead;
    }