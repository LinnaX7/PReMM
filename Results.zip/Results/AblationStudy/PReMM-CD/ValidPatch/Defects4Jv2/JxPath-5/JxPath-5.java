private int compareNodePointers(
    NodePointer p1,
    int depth1,
    NodePointer p2,
    int depth2) 
{
    if (p1 == null && p2 == null) {
        return 0;
    }

    if (depth1 < depth2) {
        int r = compareNodePointers(p1, depth1, p2.getParent(), depth2 - 1);
        return r == 0 ? -1 : r;
    }
    if (depth1 > depth2) {
        int r = compareNodePointers(p1.getParent(), depth1 - 1, p2, depth2);
        return r == 0 ? 1 : r;
    }

    if (p1 != null && p2 != null && p1.equals(p2)) {
        return 0;
    }

    if (depth1 == 1) {
        if (p1 == null || p2 == null || !areFromSameTree(p1, p2)) {
            // Handle the case where one is a variable and the other is a node
            if (p1 instanceof VariablePointer && p2 instanceof NodePointer) {
                return -1; // Variable comes before node
            }
            if (p2 instanceof VariablePointer && p1 instanceof NodePointer) {
                return 1; // Node comes before variable
            }
            return p1 == null ? -1 : 1;
        }
    }

    int r = compareNodePointers(p1.getParent(), depth1 - 1, p2.getParent(), depth2 - 1);
    if (r != 0) {
        return r;
    }

    return p1.getParent().compareChildNodePointers(p1, p2);
}

private boolean areFromSameTree(NodePointer p1, NodePointer p2) {
    NodePointer root1 = p1;
    NodePointer root2 = p2;
    while (root1.getParent() != null) {
        root1 = root1.getParent();
    }
    while (root2.getParent() != null) {
        root2 = root2.getParent();
    }
    return root1.equals(root2);
}