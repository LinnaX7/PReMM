    @Override
    public DefaultPrettyPrinter createInstance() {
        throw new IllegalStateException("Subclass " + getClass().getName() + " does not override createInstance() method");
    }