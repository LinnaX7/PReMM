public int compareTo(Fraction object) {
    long nOd = (long) getNumerator() * (long) object.getDenominator();
    long dOn = (long) object.getNumerator() * (long) getDenominator();
    return (nOd < dOn) ? -1 : ((nOd > dOn) ? +1 : 0);
}