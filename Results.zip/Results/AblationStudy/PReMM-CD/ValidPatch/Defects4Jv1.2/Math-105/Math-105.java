public double getSumSquaredErrors() {
    double result = sumYY - (sumXY * sumXY) / sumXX;
    return Math.max(result, 0.0);
}