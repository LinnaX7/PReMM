public void removeValue(int index) {
    this.keys.remove(index);
    this.values.remove(index);
    rebuildIndex();
}public void removeValue(Comparable key) {
    int index = getIndex(key);
    if (index < 0) {
        throw new UnknownKeyException("Key not found: " + key);
    }
    removeValue(index);
}public void removeColumn(Comparable columnKey) {
    if (!this.columnKeys.contains(columnKey)) {
        throw new UnknownKeyException("Column key not found: " + columnKey);
    }
    Iterator iterator = this.rows.iterator();
    while (iterator.hasNext()) {
        DefaultKeyedValues rowData = (DefaultKeyedValues) iterator.next();
        if (rowData.getIndex(columnKey) >= 0) {
            rowData.removeValue(columnKey);
        }
    }
    this.columnKeys.remove(columnKey);
}