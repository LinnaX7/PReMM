        @Override
        public void appendTo(StringBuffer buffer, Calendar calendar) {
            TimeZone calendarTimeZone = calendar.getTimeZone();
            if (calendarTimeZone.useDaylightTime()
                    && calendarTimeZone.inDaylightTime(calendar.getTime())) {
                buffer.append(getTimeZoneDisplay(calendarTimeZone, true, mStyle, mLocale));
            } else {
                buffer.append(getTimeZoneDisplay(calendarTimeZone, false, mStyle, mLocale));
            }
        }