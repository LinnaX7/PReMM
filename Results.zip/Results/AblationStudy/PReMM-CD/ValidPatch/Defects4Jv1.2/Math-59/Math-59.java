public static float max(final float a, final float b) {
    if (Float.isNaN(a) || Float.isNaN(b)) {
        return Float.NaN;
    }
    if (a == Float.POSITIVE_INFINITY || b == Float.NEGATIVE_INFINITY) {
        return a;
    }
    if (b == Float.POSITIVE_INFINITY || a == Float.NEGATIVE_INFINITY) {
        return b;
    }
    return (a > b) ? a : b;
}