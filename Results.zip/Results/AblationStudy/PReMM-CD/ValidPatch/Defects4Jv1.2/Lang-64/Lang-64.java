public int compareTo(Object other) {
    if (other == null) {
        throw new NullPointerException("The 'other' parameter cannot be null");
    }
    if (other.getClass() != this.getClass()) {
        throw new ClassCastException("Cannot compare different enum types");
    }
    ValuedEnum otherEnum = (ValuedEnum) other;
    return Integer.compare(iValue, otherEnum.iValue);
}