public StringBuffer format(Calendar calendar, StringBuffer buf) {
    if (mTimeZoneForced) {
        // Clone the calendar to avoid modifying the original
        Calendar clonedCalendar = (Calendar) calendar.clone();
        // Set the time zone to the forced time zone
        clonedCalendar.setTimeZone(mTimeZone);
        // Adjust the time to the correct time in the new time zone
        clonedCalendar.setTimeInMillis(calendar.getTimeInMillis());
        calendar = clonedCalendar;
    }
    // Apply the formatting rules
    return applyRules(calendar, buf);
}