public Object clone() throws CloneNotSupportedException {
    if (getItemCount() == 0) {
        return new TimeSeries(this.getKey());
    }
    Object clone = createCopy(0, getItemCount() - 1);
    return clone;
}