public boolean isSupportLowerBoundInclusive() {
    return false;
}public boolean isSupportUpperBoundInclusive() {
    return true;
}