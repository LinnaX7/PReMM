public boolean equals(Object other) {
    if (this == other) {
        return true;
    }
    if (other == null || getClass() != other.getClass()) {
        return false;
    }
    Complex rhs = (Complex) other;
    if (rhs.isNaN()) {
        return this.isNaN();
    }
    double thisReal = real;
    double thisImaginary = imaginary;
    double otherReal = rhs.getReal();
    double otherImaginary = rhs.getImaginary();
    return (thisReal == otherReal || (Double.isNaN(thisReal) && Double.isNaN(otherReal)))
            && (thisImaginary == otherImaginary || (Double.isNaN(thisImaginary) && Double.isNaN(otherImaginary)));
}