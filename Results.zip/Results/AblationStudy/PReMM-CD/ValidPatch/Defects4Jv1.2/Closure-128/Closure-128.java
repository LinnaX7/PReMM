static boolean isSimpleNumber(String s) {
  int len = s.length();
  if (len == 0) return false;

  // Check for valid hexadecimal number
  if (s.startsWith("0x", 0) || s.startsWith("0X", 0)) {
    if (len < 3) return false;
    for (int index = 2; index < len; index++) {
      char c = s.charAt(index);
      if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) {
        return false;
      }
    }
    return false; // Hexadecimal numbers are not simple numbers
  }

  // Check for valid octal number
  if (s.startsWith("0", 0) && len > 1) {
    for (int index = 1; index < len; index++) {
      char c = s.charAt(index);
      if (c < '0' || c > '7') {
        return false;
      }
    }
    return false; // Octal numbers are not simple numbers
  }

  // Check for valid decimal number with leading dot
  if (s.startsWith(".", 0)) {
    if (len < 2) return false;
    for (int index = 1; index < len; index++) {
      char c = s.charAt(index);
      if (c < '0' || c > '9') {
        return false;
      }
    }
    return true;
  }

  // Check for valid decimal number
  if (s.charAt(0) == '0' && len > 1) {
    return false; // Leading zero is not a simple number
  }

  for (int index = 0; index < len; index++) {
    char c = s.charAt(index);
    if (c == '.') {
      if (index == 0 || index == len - 1) {
        return false;
      }
      continue;
    }
    if (c < '0' || c > '9') {
      return false;
    }
  }
  return true;
}