public double solve(double min, double max) throws MaxIterationsExceededException, FunctionEvaluationException {
    clearResult();
    verifyInterval(min, max);
    
    double ret = Double.NaN;
    
    double yMin = f.value(min);
    double yMax = f.value(max);
    
    // Verify bracketing
    double sign = yMin * yMax;
    if (sign > 0) {
        // check if either value is close to a zero
        if (Math.abs(yMin) < this.getFunctionValueAccuracy()) {
            return min;
        } else if (Math.abs(yMax) < this.getFunctionValueAccuracy()) {
            return max;
        } else {
            throw new IllegalArgumentException("Function values at endpoints do not have different signs. Endpoints: [" + min + "," + max + "] Values: [" + yMin + "," + yMax + "]");
        }
    } else if (sign == 0) {
        // one of the endpoints is a root
        if (yMin == 0) {
            return min;
        } else {
            return max;
        }
    } else {
        // solve using only the first endpoint as initial guess
        ret = solve(min, yMin, max, yMax, min, yMin);
    }
    
    return ret;
}