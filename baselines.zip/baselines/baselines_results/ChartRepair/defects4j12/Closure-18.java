if (options.dependencyOptions.needsManagement() &&
        (options.closurePass || !inputs.isEmpty())
    ) {