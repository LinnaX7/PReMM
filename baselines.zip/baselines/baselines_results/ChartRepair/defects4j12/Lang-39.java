if (replacementList[i] == null) {
    continue;
} else {
    searchList[i] = StringUtils.defaultString(searchList[i]);
}