if (last == NUMBER_CHAR_DIGIT && (value != Long.MIN_VALUE || negative)
      && (value != 0 || !negative) && fitsInLong) {