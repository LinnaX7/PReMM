if (_hasSegments) {
    return contentsAsArray();
}