// copying root name lookup is disabled as of [dataformat-xml#282]
_rootNameLookup = new XmlRootNameLookup();