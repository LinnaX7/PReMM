// fixed line
if (offset < length-seq.length()+1) {