if (parent.isDelProp() || gramps.isDelProp()) {
    return false;
}