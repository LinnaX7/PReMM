String param;
try {
    param = params.getParameter(0);
} catch (CmdLineException e) {
    param = null;
}