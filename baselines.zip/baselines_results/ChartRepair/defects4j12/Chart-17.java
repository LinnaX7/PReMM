public Object clone() throws CloneNotSupportedException {
    TimeSeries clone = (TimeSeries) super.clone();
    clone.data = (List) ObjectUtilities.deepClone(this.data);
    return clone;
}
