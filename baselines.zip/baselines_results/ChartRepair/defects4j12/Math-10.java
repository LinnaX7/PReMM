if(Double.isNaN(result[resultOffset])) {
    result[resultOffset] = FastMath.atan2(y[yOffset], x[xOffset]);
}