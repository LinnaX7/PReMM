if (!(v instanceof Comparable)) {
    throw new IllegalArgumentException("The object being added is not comparable");
}